/** Automatically generated file. DO NOT MODIFY */
package fly.SinaWeibo.ui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}