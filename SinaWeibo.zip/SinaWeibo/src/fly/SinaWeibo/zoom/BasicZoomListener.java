package fly.SinaWeibo.zoom;

import android.view.MotionEvent;
import android.view.View;

/**
 * Simple on touch listener for zoom view
 */
public class BasicZoomListener implements View.OnTouchListener
{
	private BasicZoomControl mZoomControl;//Zoom control to manipulate 	
	private float mX; //X-coordinate of previously handled touch event 
	private float mY;//Y-coordinate of previously handled touch event 

	/**
	 * Sets the zoom control to manipulate
	 * @param control Zoom control
	 */
	public void setZoomControl(BasicZoomControl control)
	{
		mZoomControl = control;
	}

	// implements View.OnTouchListener
	public boolean onTouch(View v, MotionEvent event)
	{
		final int action = event.getAction();
		final float x = event.getX();
		final float y = event.getY();
		switch (action)
		{
			case MotionEvent.ACTION_DOWN:
				 mX = x;
				 mY = y;
				 break;
			case MotionEvent.ACTION_MOVE:
				 final float dx = (x - mX) / v.getWidth();
				 final float dy = (y - mY) / v.getHeight();
				 mZoomControl.pan(-dx, -dy);
				 mX = x;
				 mY = y;
				 break;
		}
		return true;
	}
}
