package fly.SinaWeibo.zoom;

import java.util.Observable;
import java.util.Observer;

/**
 * The BasicZoomControl is responsible for controlling a ZoomState. It makes
 * sure that pan movement follows the finger, that limits are satisfied and that
 * we can zoom into specific positions.
 * In order to implement these control mechanisms access to certain content and
 * view state data is required which is made possible through the
 * ZoomContentViewState.
 */
public class BasicZoomControl implements Observer
{
	private static final float MIN_ZOOM = 0.1f;//Minimum zoom level limit 
	private static final float MAX_ZOOM = 16;//Maximum zoom level limit
	private final ZoomState mState = new ZoomState();//Zoom state under control
	private AspectQuotient mAspectQuotient;//Object holding aspect quotient of view and content 

	/**
	 * Set reference object holding aspect quotient
	 * @param aspectQuotient  Object holding aspect quotient
	 */
	public void setAspectQuotient(AspectQuotient aspectQuotient)
	{
		if (mAspectQuotient != null)
		{
			mAspectQuotient.deleteObserver(this);
		}
		mAspectQuotient = aspectQuotient;
		mAspectQuotient.addObserver(this);
	}

	/**
	 * Get zoom state being controlled
	 * @return The zoom state
	 */
	public ZoomState getZoomState()
	{
		return mState;
	}

	/**
	 * Zoom
	 * @param f Factor of zoom to apply
	 * @param x X-coordinate of invariant position
	 * @param y Y-coordinate of invariant position
	 */
	public void zoom(float f)
	{
		mState.setZoom(mState.getZoom() * f);
		limitZoom();
		mState.notifyObservers();
	}

	/**
	 * Pan
	 * @param dx  Amount to pan in x-dimension
	 * @param dy  Amount to pan in y-dimension
	 */
	public void pan(float dx, float dy)
	{
		final float aspectQuotient = mAspectQuotient.get();
		mState.setPanX(mState.getPanX() + dx / mState.getZoomX(aspectQuotient));
		mState.setPanY(mState.getPanY() + dy / mState.getZoomY(aspectQuotient));
		limitPan();
		mState.notifyObservers();
	}

	/**
	 * Help function to figure out max delta of pan from center position.
	 * @param zoom Zoom value
	 * @return Max delta of pan
	 */
	private float getMaxPanDelta(float zoom)
	{
		return Math.max(0f, .5f * ((zoom - 1) / zoom));
	}

	/**
	 * Force zoom to stay within limits
	 */
	private void limitZoom()
	{
		if (mState.getZoom() < MIN_ZOOM)
		{
			mState.setZoom(MIN_ZOOM);
		}
		else if (mState.getZoom() > MAX_ZOOM)
		{
			mState.setZoom(MAX_ZOOM);
		}
	}

	/**
	 * Force pan to stay within limits
	 */
	private void limitPan()
	{
		final float aspectQuotient = mAspectQuotient.get();
		final float zoomX = mState.getZoomX(aspectQuotient);
		final float zoomY = mState.getZoomY(aspectQuotient);
		final float panMinX = .5f - getMaxPanDelta(zoomX);
		final float panMaxX = .5f + getMaxPanDelta(zoomX);
		final float panMinY = .5f - getMaxPanDelta(zoomY);
		final float panMaxY = .5f + getMaxPanDelta(zoomY);
		if (mState.getPanX() < panMinX)
		{
			mState.setPanX(panMinX);
		}
		if (mState.getPanX() > panMaxX)
		{
			mState.setPanX(panMaxX);
		}
		if (mState.getPanY() < panMinY)
		{
			mState.setPanY(panMinY);
		}
		if (mState.getPanY() > panMaxY)
		{
			mState.setPanY(panMaxY);
		}
	}

	// Observable interface implementation
	public void update(Observable observable, Object data)
	{
		limitZoom();
		limitPan();
	}
}
