package fly.SinaWeibo.bean;

import android.graphics.drawable.Drawable;

public class UserInfo
{
	private Long id;
	private String userId;
	private String userName;
	private String accessToken;
	private String expireIn;
	private Drawable userIcon;
    private String userIconPath;
    
	

	public UserInfo(String userId, String userName, String accessToken, String expireIn)
	{
		this.userId = userId;
		this.userName = userName;
		this.accessToken = accessToken;
		this.expireIn = expireIn;
	}

	public UserInfo(String userId, String accessToken, String expireIn)
	{
		this.userId = userId;
		this.accessToken = accessToken;
		this.expireIn = expireIn;
	}

	public UserInfo()
	{
		super();
	}

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public String getUserId()
	{
		return userId;
	}

	public void setUserId(String userId)
	{
		this.userId = userId;
	}

	public String getUserName()
	{
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public String getToken()
	{
		return accessToken;
	}

	public void setToken(String token)
	{
		this.accessToken = token;
	}

	public Drawable getUserIcon()
	{
		return userIcon;
	}

	public void setUserIcon(Drawable userIcon)
	{
		this.userIcon = userIcon;
	}

	public String getExpireIn()
	{
		return expireIn;
	}

	public void setExpireIn(String expireIn)
	{
		this.expireIn = expireIn;
	}

	public String getUserIconPath()
	{
		return userIconPath;
	}

	public void setUserIconPath(String userIconPath)
	{
		this.userIconPath = userIconPath;
	}
	@Override
	public String toString()
	{
		return "UserInfo [id=" + id + ", userId=" + userId + ", userName=" + userName + ", accessToken=" + accessToken + ", expireIn=" + expireIn + ", userIcon=" + userIcon + "]";
	}
}
