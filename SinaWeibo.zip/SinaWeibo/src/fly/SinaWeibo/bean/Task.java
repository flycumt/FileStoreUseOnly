package fly.SinaWeibo.bean;

import java.util.Map;

public class Task
{
	private int taskID;// ����ID
	private Map<String, Object> taskParams;// �������
	public Task(int taskId, Map<String, Object> taskParams)
	{
		this.taskID = taskId;
		this.taskParams = taskParams;
	}

	public int getTaskID()
	{
		return taskID;
	}

	public void setTaskID(int taskId)
	{
		this.taskID = taskId;
	}

	public Map<String, Object> getTaskParams()
	{
		return taskParams;
	}

	public void setTaskParams(Map<String, Object> taskParams)
	{
		this.taskParams = taskParams;
	}
}
