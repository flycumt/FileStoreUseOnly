package fly.SinaWeibo.bean;

import java.util.Arrays;

public class Result
{
	private String[] types;
	private String formatted_address;
	private Geometry geometry;

	public String getFormatted_address()
	{
		return formatted_address;
	}

	public void setFormatted_address(String formattedAddress)
	{
		formatted_address = formattedAddress;
	}

	public String[] getTypes()
	{
		return types;
	}

	public void setTypes(String[] types)
	{
		this.types = types;
	}

	public Geometry getGeometry()
	{
		return geometry;
	}

	public void setGeometry(Geometry geometry)
	{
		this.geometry = geometry;
	}

	@Override
	public String toString()
	{
		return "Result [types=" + Arrays.toString(types) + ", formatted_address=" + formatted_address + ", geometry=" + geometry + "]";
	}

}
