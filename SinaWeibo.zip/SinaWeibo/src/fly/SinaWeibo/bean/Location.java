package fly.SinaWeibo.bean;

public class Location
{
	private Position location;
	private String access_token;
	
	public Position getLocation()
	{
		return location;
	}
	public void setLocation(Position location)
	{
		this.location = location;
	}
	public String getAccess_token()
	{
		return access_token;
	}
	public void setAccess_token(String access_token)
	{
		this.access_token = access_token;
	}
}
