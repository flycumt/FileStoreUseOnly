package fly.SinaWeibo.db;

public class DBInfo
{
		public static final String DB_NAME="MySinaWeibo.db"; //���ݿ�����	
		public static final int    DB_VERSION=1;	     // ���ݿ�汾
		public static final String DB_TABLE_NAME="user";//����
		public static final String DB_TABLE="CREATE TABLE IF NOT EXISTS " + DB_TABLE_NAME + " (_id INTEGER PRIMARY KEY AUTOINCREMENT,userId varchar, userName varchar, access_Token varchar,expireIn varchar,userIconPath varchar)";//Ҫ�������ݱ���SQL���
		public static final String DB_DROP_TABLE="DROP TABLE IF EXISTS " + DB_TABLE_NAME; //ɾ����
//		public static final String DB_UPDATE_TABLE="ALTER TABLE "+DB_TABLE_NAME+" DELETE/ADD columnname type";//�������ݱ�
		public static final String ID = "_id";         //����
		public static final String USER_ID = "userId";
		public static final String USER_NAME = "userName";
		public static final String ACCESS_TOKEN = "access_Token";
		public static final String EXPIRE_IN = "expireIn";
		public static final String USER_HEAD_PATH = "userIconPath";
}
