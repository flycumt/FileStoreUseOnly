package fly.SinaWeibo.logic;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;

import weibo4j.Comments;
import weibo4j.Favorite;
import weibo4j.Friendships;
import weibo4j.Search;
import weibo4j.Timeline;
import weibo4j.Trend;
import weibo4j.Users;
import weibo4j.Weibo;
import weibo4j.http.AccessToken;
import weibo4j.http.ImageItem;
import weibo4j.model.CommentWapper;
import weibo4j.model.Favorites;
import weibo4j.model.Paging;
import weibo4j.model.Status;
import weibo4j.model.StatusWapper;
import weibo4j.model.Trends;
import weibo4j.model.User;
import weibo4j.model.UserTrend;
import weibo4j.model.UserWapper;
import weibo4j.model.WeiboException;
import weibo4j.org.json.JSONArray;
import weibo4j.org.json.JSONObject;
import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.bean.Location;
import fly.SinaWeibo.service.UserDBService;
import fly.SinaWeibo.service.UserPreference;
import fly.SinaWeibo.ui.IWeibo;
import fly.SinaWeibo.utils.FileUtils;
import fly.SinaWeibo.utils.GetIconUtil;
import fly.SinaWeibo.utils.LocationUtil;
import fly.SinaWeibo.utils.OAuthUtil;
import fly.SinaWeibo.utils.StreamUtil;
import fly.SinaWeibo.utils.WebViewDBUtil;

public class MainService extends Service implements Runnable
{
	public static User nowUser;//��ǰ�û�
	public static ArrayList<Activity> activityList = new ArrayList<Activity>();// ��������Activity
	public static ArrayList<Task> allTask = new ArrayList<Task>();//�������е�����
	public List<Status> statusList;//����΢���б�
	public boolean isrun = true;
	public AccessToken accessToken;
	public static final String headSavePath="SinaWeibo/userImage";
	public static String nowUserId;//��ǰ�û�UID
	public static List<UserTrend> userTrends;//�û��Ļ����б�
	public static List<UserTrend> otherUserTrendsList;
	public static List<Trends> trendsList; //���Ż���
	public static final int TEXT=0;         //����΢�������ͣ����ı�
	public static final int TEXT_IMAGE=1;   //����΢�������ͣ��ı�+ͼƬ
	public static final int TEXT_LOCATION=2;//����΢�������ͣ��ı�+����λ��
	public static final int TEXT_IMAGE_LOCATION=3;//����΢�������ͣ��ı�+����λ��+ͼƬ
	public static long totalStatusNumber;//�û���ҳ��΢������
	private UserDBService userService;
	private UserPreference userPreference;
	private Weibo weibo;
	private Timeline timeline;
	private Friendships friendships;
	private Trend trend;
	private Paging paging;
	private String WeiboID;
	private StatusWapper statusWapper;
	private UserWapper userWapper;
	private Comments comments;
	private CommentWapper commentWapper;
	private Favorite favorite;
	private Search search;
	private Users users;
	private String uid;
	@Override
	public IBinder onBind(Intent intent)
	{
		return null;
	}
	
	@Override
	public void onCreate()
	{
		super.onCreate();
		userService=new UserDBService(this);
		userPreference=new UserPreference(this);
		weibo=new Weibo();
		timeline = new Timeline();
		friendships = new Friendships();
		trend = new Trend();
		comments = new Comments();
		favorite = new Favorite();
		search = new Search();
		users = new Users();
		isrun = true;
		new Thread(this).start();
	}
	
	@Override
	public void run()
	{
		while (isrun)
		{
			Task lastTask = null;
			synchronized (allTask)
			{
				if (allTask.size() > 0)
				{
					lastTask = allTask.get(0);// ȡ����
					doTask(lastTask);// ִ������
				}
			}
			try
			{
				Thread.sleep(1000);
			}
			catch (Exception e){}
		}
	}
	
	/**
	 *  ִ������
	 * @param task
	 */
	public void doTask(Task task)
	{
		Message message = hand.obtainMessage();
		message.what = task.getTaskID();
		Map<String, Object> taskParams= task.getTaskParams();
		try
		{
			switch (task.getTaskID())
			{
				case TaskID.GET_AUTHORIZ_URL://��ȡ��Ȩ��ַ
					 String authorizURL=null;
					 while(authorizURL==null)
					 {
					   authorizURL=OAuthUtil.getAuthorizationURL();
					 }
					 message.obj=authorizURL;
					 break;
				case TaskID.GET_ACCESS_TOKEN://��ȡAccessToken
					 String AuthorizationCode=(String) taskParams.get("AuthorizationCode");
					 while(accessToken==null)
					 {
						accessToken=OAuthUtil.getAccessToken(AuthorizationCode);
					 }
					 message.obj = accessToken;
					 break;
				case TaskID.CLEAR_WEBVIEW_CACHE://���WebView���ݿ⻺���ļ�
					 WebViewDBUtil.clearWebCache();
					 break;
				case TaskID.GET_USER_HEAD_ICON://��ȡ�û�ͷ����ǳ�
					 new getIconThread().start();
					 break;
			    case TaskID.GET_USER_HOME_TIMELINE://��ȡ�û���ҳ΢��
			    	 weibo.setToken(userService.getAccessTokenById(nowUserId));
			    	 statusWapper = timeline.getHomeTimeline();
			    	 if(statusWapper!=null)
			    	 {
				    	 totalStatusNumber=statusWapper.getTotalNumber();
				    	 statusList=statusWapper.getStatuses();
			    	 }
			    	 addTask(new Task(TaskID.GET_HOT_TOPIC, null));
			    	 message.obj=statusList;
			    	 break;
			    case TaskID.GET_USER_INFO://��ȡ�û�������Ϣ
			    	 if(nowUser==null)
			    	 {
				        nowUser = users.showUserById(nowUserId);
				        addTask(new Task(TaskID.GET_USER_HEAD_ICON, null));//��ȡ�û�ͷ������
			    	 }
			    	 if(userTrends==null)
				        userTrends=trend.getTrends(nowUserId);
				     message.obj=nowUser;
			    	 break;
			    case TaskID.RELOAD_USER_INFO://���¼����û�������Ϣ
			    	 nowUser = users.showUserById(nowUserId);
			    	 userTrends=trend.getTrends(nowUserId);
			    	 addTask(new Task(TaskID.GET_USER_HEAD_ICON, null));
			    	 message.obj=nowUser;
			    	 break;
			    case TaskID.GET_REFRESH_WEIBODATA://ˢ��΢��
			    	 statusWapper=timeline.getHomeTimeline();
			    	 if(statusWapper!=null)
			    	 {
			    		 statusList=statusWapper.getStatuses();
			    		 totalStatusNumber=statusWapper.getTotalNumber();
			    	 }
			    	 message.obj=statusList;
			    	 break;
			    case TaskID.GET_MORE_WEIBODATA://��ȡ����΢��
			    	 paging=(Paging) taskParams.get("Paging");
			    	 statusWapper = timeline.getHomeTimeline(0, 0, paging);
			    	 if(statusWapper!=null)
			    	 {
			    	  List<Status> moreStatusList=statusWapper.getStatuses();
			    	  message.obj=moreStatusList;
			    	 }
			    	 break;
			    case TaskID.NEW_WEIBO_TASK://����΢��
			    	 String status=(String) taskParams.get("Status");
			    	 int type=(Integer) taskParams.get("Type");
			    	 message.obj = false;
			    	 switch (type)
					 {
						case TEXT:
							 timeline.UpdateStatus(status);
							 message.obj = true;
						     break;
						case TEXT_IMAGE:
							 String path=(String) taskParams.get("photoPath");
							 byte[] content= StreamUtil.read(new FileInputStream(new File(path)));
							 ImageItem picItem=new ImageItem("pic",content);//�˴���һ������������"pic",�����ܳɹ�
						     timeline.UploadStatus(status, picItem);
							 message.obj = true;
					         break;
						case TEXT_LOCATION:
							 double[] location=(double[])taskParams.get("Location");
						     timeline.UpdateStatus(status, (float) location[0], (float) location[1], "[{}]");
							 message.obj = true;
					         break;
						case TEXT_IMAGE_LOCATION:
							 ImageItem item1=(ImageItem) taskParams.get("ImageItem");
							 double[] location1=(double[])taskParams.get("Location");
					         timeline.UploadStatus(status, item1,(float) location1[0], (float) location1[1]);
					         message.obj = true;
				             break;
					 }
			    	 break;
			    case TaskID.GET_HOT_TOPIC://��ȡ���Ż���
			    	 if(trendsList==null)
			    	 trendsList=trend.getTrendsDaily();
			    	 if(nowUser==null)
						addTask(new Task(TaskID.GET_USER_INFO, null));//��ȡ�û�������Ϣ
			    	 else
			    		addTask(new Task(TaskID.GET_USER_HEAD_ICON, null));//��ȡ�û�ͷ������
			    	 if(userTrends==null)
				        userTrends=trend.getTrends(nowUserId);
			    	 break;
			    case TaskID.GET_USER_ADDRESS://��ȡ�û���ַ
			    	 String address=null;
			    	 if(taskParams!=null&&!taskParams.isEmpty())
			    	 {
			    		 double latitude=(Double) taskParams.get("Latitude");
			    		 double longitude=(Double) taskParams.get("Longitude");
			    		 address=LocationUtil.getAddress(latitude, longitude);
			    	 }
			    	 message.obj=address;
			    	 break;
			    case TaskID.REPOST_WEIBO_TASK://ת��΢��
			    	 WeiboID=(String) taskParams.get("WeiboID");
			    	 Integer asComment=(Integer) taskParams.get("AsComment");
			    	 Boolean hasSub=(Boolean) taskParams.get("hasSub");
			    	 String reStatus="";
			    	 message.obj=false;
			    	 if(hasSub)
			    	   reStatus=(String) taskParams.get("Status");
			    	 if(WeiboID!=null&&!WeiboID.equals(""))
			    	    timeline.Repost(WeiboID, reStatus, asComment);
			    	 message.obj=true;
			    	 break;
			    case TaskID.COMMENT_WEIBO_TASK://����΢��
			    	 WeiboID=(String) taskParams.get("WeiboID");
			    	 String comment=(String) taskParams.get("Status");
			    	 message.obj=false;
			    	 if(WeiboID!=null&&!WeiboID.equals(""))
			    	    comments.createComment(comment, WeiboID);
			    	 message.obj=true;
			    	 break;
			    case TaskID.CREATE_FAVORITES_INSEARCH:
			    case TaskID.CREATE_FAVORITES_INMSG:
			    case TaskID.CREATE_FAVORITES_INDETAIL:
			    case TaskID.CREATE_FAVORITES_INUSERWEIBO:
			    case TaskID.CREATE_FAVORITES_TASK://�ղ�΢��
			    	 WeiboID=(String) taskParams.get("WeiboID");
			    	 message.obj=false;
			    	 if(WeiboID!=null&&!WeiboID.equals(""))
			    		favorite.createFavorites(WeiboID);
			    	 message.obj=true;
			    	 break;
			    case TaskID.GET_MORE_REPOST_LIST:
			    case TaskID.GET_WEIBO_REPOST_LIST://��ȡָ��΢����ת���б�
			    	 paging=(Paging) taskParams.get("Paging");
			    	 WeiboID=(String) taskParams.get("WeiboID");
			    	 if(WeiboID!=null&&!WeiboID.equals(""))
			    		statusWapper=timeline.getRepostTimeline(WeiboID, paging);
			    	 if(statusWapper!=null)
			    	    message.obj=statusWapper.getStatuses();
			    	 break;
			    case TaskID.GET_MORE_COMMENT_LIST:
			    case TaskID.GET_WEIBO_COMMENT_LIST://��ȡָ��΢���������б�
			    	 paging=(Paging) taskParams.get("Paging");
			    	 WeiboID=(String) taskParams.get("WeiboID");
			    	 commentWapper=comments.getCommentById(WeiboID, paging, 0);
			    	 if(commentWapper!=null)
			    		message.obj=commentWapper.getComments();
			    	 break;
			    case TaskID.REFRESH_USER_FRIENDS://ˢ�¹�ע�б�
			    case TaskID.GET_USER_FRIENDS://��ȡ�û���ע�б�
			    	 paging=(Paging) taskParams.get("Paging");
			    	 uid=(String) taskParams.get("uid");
			    	 userWapper=friendships.getFriendsByID(uid, paging);
			    	 List<User> userList=userWapper.getUsers();
			    	 message.obj=userList;
			    	 break;
			    case TaskID.CREATE_FRIENDS_TASK://��עĳ��
			    	 uid=(String) taskParams.get("uid");
			    	 message.obj=false;
			    	 if(uid!=null)
			    	   friendships.createFriendshipsById(uid);
			    	 else
			    	 {
			    	   String uname=(String) taskParams.get("uname");
			    	   friendships.createFriendshipsByName(uname);
			    	 }
			    	 message.obj=true;
			    	 break;
			    case TaskID.DELETE_FRIENDS_TASK://ȡ����עĳ��
			    	 uid=(String) taskParams.get("uid");
			    	 message.obj=false;
			    	 if(uid!=null)
			    	 friendships.destroyFriendshipsDestroyById(uid);
			    	 else
			    	 {
			    		 String uname=(String) taskParams.get("uname");
			    		 friendships.destroyFriendshipsDestroyByName(uname);
			    	 }
			    	 message.obj=true;
			    	 break;
			    case TaskID.GET_MORE_MYWEIBO:
			    case TaskID.REFRESH_MY_WEIBO:
			    case TaskID.GET_MY_WEIBO://��ȡ�û�������΢��
			    	 paging=(Paging) taskParams.get("Paging");
			    	 uid=(String) taskParams.get("uid");
			    	 statusWapper=timeline.getUserTimelineByUid(uid, paging, 0, 0);
			    	 if(statusWapper!=null)
			    		 message.obj=statusWapper.getStatuses();
			    	 break;
			    case TaskID.DELETE_MY_WEIBO://ɾ��һ��΢��
			    	 WeiboID=(String) taskParams.get("WeiboID");
			    	 message.obj=false;
			    	 timeline.Destroy(WeiboID);
			    	 message.obj=true;
			    	 break;
			    case TaskID.REFRESH_USER_FOLLOWERS:
			    case TaskID.GET_USER_FOLLOWERS://��ȡ�û���˿�б�
			    	 paging=(Paging) taskParams.get("Paging");
			    	 uid=(String) taskParams.get("uid");
			    	 userWapper=friendships.getFollowersById(uid, paging);
			    	 if(userWapper!=null)
			    		 message.obj=userWapper.getUsers();
			    	 break;
			    case TaskID.GET_USER_TRENDS://��ȡ�û������б�
			    	 paging=(Paging) taskParams.get("Paging");
			    	 uid=(String) taskParams.get("uid");
			    	 message.obj=trend.getTrends(uid, paging);
			    	 break;
			    case TaskID.REFRESH_MY_FAVOURITES:
			    case TaskID.GET_MORE_FAVOURITES:
			    case TaskID.GET_MY_FAVOURITES://��ȡ��¼�û����ղ��б�
			    	 List<Favorites> list=favorite.getFavorites();
			    	 List<Status> statusList=new ArrayList<Status>();
			    	 if(list!=null&&!list.isEmpty())
			    	 for (Favorites favorites : list)
					 {
			    		 statusList.add(favorites.getStatus());
					 }
			    	 message.obj=statusList;
			    	 break;
			    case TaskID.DELETE_MY_FAVOURITES://ɾ��һ���ղ�
			    	 WeiboID=(String) taskParams.get("WeiboID");
			    	 message.obj=false;
			    	 favorite.destroyFavorites(WeiboID);
			    	 message.obj=true;
			    	 break;
			    case TaskID.GET_OTHER_USERINFO://��ȡ�����û�����
			    	 int code=(Integer) taskParams.get("code");
			    	 if(code==0)
					 {
			    		 String uname=(String) taskParams.get("userName");
			    		 User user=new Users().showUserByScreenName(uname);
			    		 message.obj=user;
			    		 message.arg1=0;
			    		 if(user!=null)
						 {
			    			 otherUserTrendsList=trend.getTrends(user.getId());
			    			 if (otherUserTrendsList!=null&&!otherUserTrendsList.isEmpty())
			    				 message.arg1=otherUserTrendsList.size();
						 }
					 }
			    	 else if(code==1)
					 {
			    		 uid=(String) taskParams.get("uid");
			    		 otherUserTrendsList=trend.getTrends(uid);
			    		 message.obj=0;
			    		 message.arg1=0;
			    		 if (otherUserTrendsList!=null&&!otherUserTrendsList.isEmpty())
			    			 message.obj=otherUserTrendsList.size();
					 }
			    	 break;
			    case TaskID.REFRESH_OTHER_USERINFO://���»�ȡ�����û�����
			    	 uid=(String) taskParams.get("uid");
			    	 User user=users.showUserById(uid);
			    	 message.obj=user;
		    		 message.arg1=0;
		    		 if(user!=null)
					 {
		    			 List<UserTrend> trendsList=trend.getTrends(uid);
		    			 if (trendsList!=null&&!trendsList.isEmpty())
		    				 message.arg1=trendsList.size();
					 }
			    	 break;
			    case TaskID.CREATE_FOLLOW_TRENDS://��עĳ����
			    	 String trend_name=(String) taskParams.get("trend_name");
			    	 message.obj=false;
			    	 trend.trendsFollow(trend_name);
			    	 message.obj=true;
			    	 break;
			    case TaskID.GET_MORE_COMMENTWEIBO:
			    case TaskID.REFRESH_MENTION_STATUS:
			    case TaskID.GET_MENTION_STATUS://��ȡ@�ҵ�΢��
			    	 paging=(Paging) taskParams.get("Paging");
			    	 statusWapper=timeline.getMentions(paging, 0, 0, 0);
			    	 if(statusWapper!=null)
			    	 {
			    	    message.obj=statusWapper.getStatuses();
			    	    message.arg1=(int)statusWapper.getTotalNumber();
			    	 }
			    	 break;
			    case TaskID.GET_MORE_COMMENT_TOME:
			    case TaskID.GET_COMMENTS_TOME://��ȡ���յ��������б�
			    	 paging=(Paging) taskParams.get("Paging");
			    	 commentWapper=comments.getCommentToMe(paging, 0, 0);
			    	 if(commentWapper!=null)
			    	 {
			    		 message.obj=commentWapper.getComments();
			    		 message.arg1=(int)commentWapper.getTotalNumber();
			    	 }
			    	 break;
			    case TaskID.REPLY_COMMENT_TASK://�ظ�һ������
			    	 WeiboID=(String) taskParams.get("WeiboID");
			    	 String CommentID=(String) taskParams.get("CommentID");
			    	 String commentText=(String) taskParams.get("Status");
			    	 message.obj=false;
			    	 comments.replyComment(CommentID, WeiboID, commentText, 0, 0);
			    	 message.obj=true;
			    	 break;
			    case TaskID.SEARCH_USER_SUGGESTIONS://�����û�
			    	 String q=(String) taskParams.get("searchKey");
			    	 JSONArray jsonArray=search.searchSuggestionsUsers(q);
			    	 List<User> usList=new ArrayList<User>();
			    	 for (int i = 0; i < jsonArray.length(); i++)
			    	 {
			    		JSONObject jsonObject=jsonArray.getJSONObject(i);
			    		String screen_name=jsonObject.getString("screen_name");
			    		User us;
			    		try
			    		{
			    		 us=users.showUserByScreenName(screen_name);
			    		}
			    		catch (WeiboException e) 
			    		{
							continue;
						}
			    		if(us!=null)usList.add(us);
			       	 }
			    	 message.obj=usList;
			    	 break;
			    case TaskID.GET_MORE_SEARCHWEIBO:
			    case TaskID.REFRESH_SEARCH_STATUS:
			    case TaskID.SEARCH_WEIBO_BYTOPIC://����΢��
			    	 String topic=(String) taskParams.get("searchKey");
			    	 int page=(Integer) taskParams.get("page");
			    	 int count=(Integer) taskParams.get("count");
			    	 statusWapper=search.searchStatusByTopics(topic, count, page);
			    	 if(statusWapper!=null)
			    	 {
			    	  message.obj=statusWapper.getStatuses();
			    	  message.arg1=(int)statusWapper.getTotalNumber();
			    	 }
			    	 break;
			    case TaskID.GET_USER_LOCATION://��ȡ�û�λ������
			    	 String point=LocationUtil.requestTelLocation(getApplicationContext());
			    	 if(point.length()>2)
			    	 {
				    	 Gson gson = new Gson();
				    	 Location location=gson.fromJson(point, Location.class);
				    	 message.obj=location.getLocation();
			    	 }
			    	 break;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		hand.sendMessage(message);// ���͸���UI����Ϣ�����߳�
		allTask.remove(task);// ִ��������
	}
	/**
	 *  ����UI
	 */
	private Handler hand = new Handler()
	{
		@Override
		public void handleMessage(Message msg) 
		{
			super.handleMessage(msg);
			switch (msg.what) //ˢ�¸�Activity
			{
				case TaskID.GET_AUTHORIZ_URL:
					 IWeibo webViewActivity = (IWeibo) getActivityByName("WebViewActivity");
					 webViewActivity.refresh(msg.obj);
					 break;
				case TaskID.GET_ACCESS_TOKEN:
					 IWeibo loginActivity = (IWeibo) getActivityByName("LoginActivity");
					 loginActivity.refresh(msg.what,msg.obj);
					 break;
				case TaskID.CREATE_FAVORITES_TASK:
				case TaskID.GET_MORE_WEIBODATA:
				case TaskID.GET_REFRESH_WEIBODATA:
				case TaskID.GET_USER_HOME_TIMELINE:
					 IWeibo homeActivity = (IWeibo) getActivityByName("HomeActivity");
					 homeActivity.refresh(msg.what,msg.obj);
			    	 break;
				case TaskID.GET_USER_LOCATION:
				case TaskID.REPLY_COMMENT_TASK:
				case TaskID.COMMENT_WEIBO_TASK:
				case TaskID.REPOST_WEIBO_TASK:
				case TaskID.GET_USER_ADDRESS:
				case TaskID.NEW_WEIBO_TASK:
					 IWeibo newWeiboActivity = (IWeibo) getActivityByName("NewWeiboActivity");
					 if(newWeiboActivity!=null)
					    newWeiboActivity.refresh(msg.what,msg.obj);
					 break;
				case TaskID.CREATE_FOLLOW_TRENDS:
				case TaskID.CREATE_FAVORITES_INDETAIL:
				case TaskID.GET_MORE_COMMENT_LIST:
				case TaskID.GET_WEIBO_COMMENT_LIST:
				case TaskID.GET_MORE_REPOST_LIST:
				case TaskID.GET_WEIBO_REPOST_LIST:
					 IWeibo weiboInfoActivity = (IWeibo) getActivityByName("WeiboInfoActivity");
					 if(weiboInfoActivity!=null)
					 weiboInfoActivity.refresh(msg.what,msg.obj);
					 break;
				case TaskID.RELOAD_USER_INFO:
				case TaskID.GET_USER_INFO:
					 IWeibo infoActivity = (IWeibo) getActivityByName("InfoActivity");
					 if(infoActivity!=null)
					    infoActivity.refresh(msg.what,msg.obj);
					 break;
				case TaskID.REFRESH_USER_FRIENDS:
				case TaskID.GET_USER_FRIENDS:
					 IWeibo friendsActivity = (IWeibo) getActivityByName("FriendsActivity");
					 if(friendsActivity!=null)
					 friendsActivity.refresh(msg.what,msg.obj);
					 break;
				case TaskID.DELETE_FRIENDS_TASK:
				case TaskID.CREATE_FRIENDS_TASK:
					 IWeibo userInfoActivity = (IWeibo) getActivityByName("UserInfoActivity");
					 IWeibo friendsActivity2 = (IWeibo) getActivityByName("FriendsActivity");
					 IWeibo followersActivity2 = (IWeibo) getActivityByName("FollowersActivity");
					 IWeibo searchActivity2 = (IWeibo) getActivityByName("SearchActivity");
					 if(friendsActivity2!=null)
					    friendsActivity2.refresh(msg.what,msg.obj);
					 else if(followersActivity2!=null)
						followersActivity2.refresh(msg.what,msg.obj);
					 else if(userInfoActivity!=null)
						userInfoActivity.refresh(msg.what,msg.obj);
					 else if(searchActivity2!=null)
						searchActivity2.refresh(msg.what,msg.obj);
					 break;
				case TaskID.DELETE_MY_WEIBO:
				case TaskID.GET_MORE_MYWEIBO:
				case TaskID.REFRESH_MY_WEIBO:
				case TaskID.GET_MY_WEIBO:
				case TaskID.CREATE_FAVORITES_INUSERWEIBO:
					 IWeibo myWeiboActivity = (IWeibo) getActivityByName("MyWeiboActivity");
					 if(myWeiboActivity!=null)
					    myWeiboActivity.refresh(msg.what,msg.obj);
					 break;
				case TaskID.REFRESH_USER_FOLLOWERS:
			    case TaskID.GET_USER_FOLLOWERS:
			    	 IWeibo followersActivity = (IWeibo) getActivityByName("FollowersActivity");
			    	 if(followersActivity!=null)
			    	    followersActivity.refresh(msg.what,msg.obj);
					 break;
			    case TaskID.GET_USER_TRENDS:
			    	 IWeibo trendsActivity = (IWeibo) getActivityByName("TrendsActivity");
			    	 if(trendsActivity!=null)
			    	    trendsActivity.refresh(msg.what,msg.obj);
					 break;
			    case TaskID.REFRESH_MY_FAVOURITES:
			    case TaskID.DELETE_MY_FAVOURITES:
			    case TaskID.GET_MORE_FAVOURITES:
			    case TaskID.GET_MY_FAVOURITES:
			    	 IWeibo favsActivity = (IWeibo) getActivityByName("FavouritesActivity");
			    	 if(favsActivity!=null)
			    	    favsActivity.refresh(msg.what,msg.obj);
					 break;
			    case TaskID.REFRESH_OTHER_USERINFO:
			    case TaskID.GET_OTHER_USERINFO:
			    	 IWeibo userInFoActivity = (IWeibo) getActivityByName("UserInfoActivity");
			    	 if(userInFoActivity!=null)
			    	    userInFoActivity.refresh(msg.what,msg.obj,msg.arg1);
			    	 break;
			    case TaskID.CREATE_FAVORITES_INMSG:
			    case TaskID.GET_MORE_COMMENT_TOME:
			    case TaskID.GET_COMMENTS_TOME:
			    case TaskID.GET_MORE_COMMENTWEIBO:
			    case TaskID.REFRESH_MENTION_STATUS:
			    case TaskID.GET_MENTION_STATUS:
			    	 IWeibo msgActivity = (IWeibo) getActivityByName("MSGActivity");
			    	 msgActivity.refresh(msg.what,msg.obj,msg.arg1);
			    	 break;
			    case TaskID.GET_MORE_SEARCHWEIBO:
			    case TaskID.CREATE_FAVORITES_INSEARCH:
			    case TaskID.REFRESH_SEARCH_STATUS:
			    case TaskID.SEARCH_WEIBO_BYTOPIC:
			    case TaskID.SEARCH_USER_SUGGESTIONS:
			    	 IWeibo searchActivity = (IWeibo) getActivityByName("SearchActivity");
			    	 searchActivity.refresh(msg.what,msg.obj,msg.arg1);
			    	 break;
			}
		}

	};
	class getIconThread extends Thread
	{
		@Override
		public void run()
		{
			 if(nowUser!=null)
			 {
				 URL userIconUrl=nowUser.getAvatarLargeURL();
				 userService.updateUserInfo(nowUserId+"",nowUser.getScreenName(), userIconUrl.toString());//�����ǳƺ�ͷ���ַ�����ݿ�
				 saveUserIcon(userIconUrl,nowUserId);
			 }
		}
	}
	
	@Override
	public void onDestroy()
	{
		isrun = false;
		super.onDestroy();
	}
	
	/**
	 *  ��������
	 * @param task
	 */
	public static void addTask(Task task)
	{
		allTask.add(task);
	}
	
	/**
	 * ����Activity���󵽼�����
	 * @param activity
	 */
	public static void addActivity(Activity activity)
	{
		activityList.add(activity);
	}
	
	/**
	 * �Ӽ�����ͨ��name��ȡActivity����
	 * @param name
	 * @return Activity
	 */
	public static Activity getActivityByName(String name)
	{
		Activity targetActivity=null;
		for (Activity activity : activityList)
		{
			if (activity.getClass().getName().indexOf(name) >= 0)
			{
				targetActivity=activity;
			}
		}
		return targetActivity;
	}
	public static void removeActivityByName(String name)
	{
		int i=0;
		List<Integer> tempIndex=new ArrayList<Integer>();
		for (Activity activity : MainService.activityList)
		{
			if (activity.getClass().getName().indexOf(name) >= 0)
			{
				tempIndex.add(i);
			}
			i++;
		}
		for (Integer index : tempIndex)
		{
			MainService.activityList.remove(index);
		}
	}
	public static void removeActivity(Activity activity)
	{
		if (MainService.activityList.contains(activity))
		{
			MainService.activityList.remove(activity);
		}
	}
	/**
	 * �����û�ͷ��SD��
	 * @param userIconPath
	 */
	public void saveUserIcon(URL userIconUrl,String userId)
	{
		byte[] data=null;
		String filename=userId+".jpg";
		try
		{
			data = GetIconUtil.getImage(userIconUrl);//����ͼƬ
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		FileUtils fileUtils=new FileUtils();
		if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))//�ж�SD���Ƿ���ڣ����ҿ��Զ�д
		{
			if(data!=null)
			{
				File file=fileUtils.save2SD(headSavePath,filename, data);//����ͷ��
			    String path=file.getAbsolutePath();//��ȡͷ��ı���·��
			    if(path.endsWith(".jpg"))//�������ɹ��򷵻ص�·����Ȼ��.jpg��β
			    {
			    	userPreference.saveUserIconSDPath(userId, path);//�����û�ͷ��ı���·��
			    }
			}
		}
	}
}