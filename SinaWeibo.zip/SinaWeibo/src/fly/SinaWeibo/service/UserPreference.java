package fly.SinaWeibo.service;

import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class UserPreference
{
	private Context context;

	public UserPreference(Context context)
	{
		this.context = context;
	}

	/**
	 * �����û����ò����Լ������Ϣ
	 * @param userAccount �û��˺�
	 * @param userId      �û�ID
	 * @param isAuthrized �û��Ƿ�����Ȩ
	 * @param isAutoLogin �û��Ƿ��Զ���¼
	 */
	public void savePreferences(String userAccount,String userId, boolean isAuthrized,boolean isAutoLogin,boolean isRememberMe)
	{
		SharedPreferences preferences = context.getSharedPreferences(userAccount, Context.MODE_PRIVATE);// ��userAccount��ΪҪ����ƫ�ò�����xml�ļ�������
		Editor editor = preferences.edit();
		editor.putString("userAccount", userAccount);
		editor.putString("userId", userId);
		editor.putBoolean("isAuthrized", isAuthrized);
		editor.putBoolean("isAutoLogin", isAutoLogin);
		editor.putBoolean("isRememberMe", isRememberMe);
		editor.commit();
	}

	/**
	 * ��ȡ�û��������ò���
	 * @return Map<String, Object>
	 */
	public Map<String, Object> getPreferences(String userAccount)
	{
		Map<String, Object> params = new HashMap<String, Object>();
		SharedPreferences preferences = context.getSharedPreferences(userAccount, Context.MODE_PRIVATE);
		params.put("userAccount", preferences.getString("userAccount", ""));
		params.put("userId", preferences.getString("userId", ""));
		params.put("isAuthrized", preferences.getBoolean("isAuthrized", false));
		params.put("isAutoLogin", preferences.getBoolean("isAutoLogin", false));
		params.put("isRememberMe", preferences.getBoolean("isRememberMe", false));
		return params;
	}
	
	/**
	 * ���汾�ε�¼�û��˺�
	 * @param userAccount
	 */
	public void saveLastUser(String userAccount)
	{
		SharedPreferences preferences = context.getSharedPreferences("LastUser", Context.MODE_PRIVATE);
		Editor editor = preferences.edit();
		editor.putString("lastUser", userAccount);
		editor.commit();
	}
	
	/**
	 * ��ȡ�ϴε�¼�û��˺�
	 * @return userAccount
	 */
	public String getLastUser()
	{
		String userAccount;
		SharedPreferences preferences = context.getSharedPreferences("LastUser", Context.MODE_PRIVATE);
		userAccount=preferences.getString("lastUser", "");
		return userAccount;
	}
	
	/**
	 * �����û���Ȩʱ��ʱ��
	 * @param userId
	 * @param authrizedTime
	 */
	public void saveUserAuthrizedTime(String userId,String userAccount,String authrizedTime)
	{
		SharedPreferences preferences = context.getSharedPreferences(userId, Context.MODE_PRIVATE);	
		Editor editor = preferences.edit();
		editor.putString("UserAccount", userAccount);
		editor.putString("AuthrizedTime", authrizedTime);
		editor.commit();
	}
	
	/**
	 * ��ȡ�û���Ȩʱ��ʱ��
	 * @param userId
	 * @return String
	 */
	public String getUserAuthrizedTime(String userId)
	{
		SharedPreferences preferences = context.getSharedPreferences(userId, Context.MODE_PRIVATE);
		return preferences.getString("AuthrizedTime", "");
	}
	/**
	 * �����û���ID��ȡ�û��˺�
	 * @param userId
	 * @return String
	 */
	public String getUserAccount(String userId)
	{
		SharedPreferences preferences = context.getSharedPreferences(userId, Context.MODE_PRIVATE);
		return preferences.getString("UserAccount", "");
	}
	/**
	 * �����û�ͷ����SD���ϵı���·��
	 * @param userId
	 * @param userIconSDPath
	 */
	public void saveUserIconSDPath(String userId,String userIconSDPath)
	{
		SharedPreferences preferences = context.getSharedPreferences(userId, Context.MODE_PRIVATE);	
		Editor editor = preferences.edit();
		editor.putString("UserIconSDPath", userIconSDPath);
		editor.commit();
	}
	/**
	 * ��ȡ�û�ͷ����SD���ϵı���·��
	 * @param userId
	 * @return String
	 */
	public String getUserIconSDPath(String userId)
	{
		SharedPreferences preferences = context.getSharedPreferences(userId, Context.MODE_PRIVATE);	
		return preferences.getString("UserIconSDPath", null);
	}
	
	/**
	 * �����˺��Ƿ񱻴������б���ɾ��
	 * @param userAccount
	 */
	public void saveUserDel(String userAccount,boolean isRemoved)
	{
		SharedPreferences preferences = context.getSharedPreferences("UserDeleteList", Context.MODE_PRIVATE);	
		Editor editor = preferences.edit();
		editor.putBoolean(userAccount, isRemoved);
		editor.commit();
	}
	
	/**
	 * ��ȡ�û��������б�ɾ�����˺�
	 * @return boolean
	 */
	public boolean getUserDelList(String userAccount)
	{
		SharedPreferences preferences = context.getSharedPreferences("UserDeleteList", Context.MODE_PRIVATE);	
	    return preferences.getBoolean(userAccount, false);
	}
}
