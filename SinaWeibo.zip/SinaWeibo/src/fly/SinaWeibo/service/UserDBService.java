package fly.SinaWeibo.service;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import fly.SinaWeibo.bean.UserInfo;
import fly.SinaWeibo.db.DBInfo;
import fly.SinaWeibo.db.DatabaseHelper;

public class UserDBService
{
	private DatabaseHelper dbHelper;

	public UserDBService(Context context)
	{
		dbHelper = new DatabaseHelper(context);
	}

	/**
	 * �����û���Ȩ��Ϣ
	 * @param user
	 */
	public void insertUserInfo(UserInfo user)
	{
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		ContentValues values = new ContentValues(4);
		values.put(DBInfo.USER_ID, user.getUserId());
		values.put(DBInfo.USER_NAME, user.getUserName());
		values.put(DBInfo.ACCESS_TOKEN, user.getToken());
		values.put(DBInfo.EXPIRE_IN, user.getExpireIn());
		db.insert(DBInfo.DB_TABLE_NAME, null, values);
		db.close();
	}

	/**
	 * �����û�ID��ȡĳ���û�����
	 * @param userId
	 * @return UserInfo
	 */
	public UserInfo getUserInfoByUserId(String userId)
	{
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		UserInfo userInfo = null;
		Cursor cursor = db.query(DBInfo.DB_TABLE_NAME, new String[]{DBInfo.ID, DBInfo.USER_NAME, DBInfo.ACCESS_TOKEN, DBInfo.EXPIRE_IN,DBInfo.USER_HEAD_PATH}, DBInfo.USER_ID+"=?", new String[]{userId}, null, null, null);
		if (cursor.moveToFirst())
		{			
			Long id = cursor.getLong(cursor.getColumnIndex(DBInfo.ID));
			String userName = cursor.getString(cursor.getColumnIndex(DBInfo.USER_NAME));
			String accessToken = cursor.getString(cursor.getColumnIndex(DBInfo.ACCESS_TOKEN));
			String expireIn = cursor.getString(cursor.getColumnIndex(DBInfo.EXPIRE_IN));
			String userIconPath = cursor.getString(cursor.getColumnIndex(DBInfo.USER_HEAD_PATH));
			userInfo = new UserInfo();
			userInfo.setId(id);
			userInfo.setUserId(userId);
			userInfo.setUserName(userName);
			userInfo.setToken(accessToken);
			userInfo.setExpireIn(expireIn);
			userInfo.setUserIconPath(userIconPath);
		}
		cursor.close();
		db.close();
		return userInfo;
	}

	/**
	 * ��ȡ���е��û�����
	 * @return List<UserInfo>
	 */
	public List<UserInfo> getAllUsers()
	{
		SQLiteDatabase db = this.dbHelper.getReadableDatabase();
		List<UserInfo> users = null;
		String[] columns = { DBInfo.ID, DBInfo.USER_ID, DBInfo.USER_NAME, DBInfo.ACCESS_TOKEN, DBInfo.EXPIRE_IN,DBInfo.USER_HEAD_PATH};
		Cursor cursor = db.query(DBInfo.DB_TABLE_NAME, columns, null, null, null, null, null);
		if (cursor!= null&&cursor.getCount() > 0)
		{
			users = new ArrayList<UserInfo>(cursor.getCount());
			UserInfo userInfo = null;
			while (cursor.moveToNext())
			{
				Long id = cursor.getLong(cursor.getColumnIndex(DBInfo.ID));
				String userId = cursor.getString(cursor.getColumnIndex(DBInfo.USER_ID));
				String userName = cursor.getString(cursor.getColumnIndex(DBInfo.USER_NAME));
				String accesstoken = cursor.getString(cursor.getColumnIndex(DBInfo.ACCESS_TOKEN));
				String expireIn = cursor.getString(cursor.getColumnIndex(DBInfo.EXPIRE_IN));	
				String userIconPath = cursor.getString(cursor.getColumnIndex(DBInfo.USER_HEAD_PATH));
				userInfo = new UserInfo();
				userInfo.setId(id);
				userInfo.setUserId(userId);
				userInfo.setUserName(userName);
				userInfo.setToken(accesstoken);
				userInfo.setExpireIn(expireIn);
				userInfo.setUserIconPath(userIconPath);
				users.add(userInfo);
			}
		}
		cursor.close();
		db.close();
		return users;
	}

	/**
	 * �����û�AccessToken��Ϣ
	 * @param user
	 */
	public void updateUserInfo(UserInfo user)
	{
		SQLiteDatabase db = this.dbHelper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(DBInfo.ACCESS_TOKEN, user.getToken());
		values.put(DBInfo.EXPIRE_IN, user.getExpireIn());
		db.update(DBInfo.DB_TABLE_NAME, values, DBInfo.USER_ID + "=?", new String[]{user.getUserId()});
		db.close();
	}

	/**
	 * �����û�ͷ���ַ���û��ǳ�
	 * @param userId
	 * @param userName
	 * @param userIconPath
	 */
	public void updateUserInfo(String userId, String userName,String userIconPath)
	{
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(DBInfo.USER_NAME, userName);
		values.put(DBInfo.USER_HEAD_PATH,userIconPath);
		db.update(DBInfo.DB_TABLE_NAME, values, DBInfo.USER_ID + "=?", new String[]{userId});
		db.close();
//		values.put(DBInfo.USER_ICON, userIconByte);
//		ByteArrayOutputStream os = new ByteArrayOutputStream();
//		userIcon.compress(CompressFormat.PNG, 100, os);//��userIconѹ����PNG���ͣ�osд��ѹ�����ݵ������
//		values.put(DBInfo.USER_ICON, os.toByteArray());		      		
	}
	/**
	 * �����û�ID��ȡ�û�ͷ���ַ
	 * @param userId
	 * @return userIconPath
	 */
	public String getUserIconById(String userId)
	{
		SQLiteDatabase db = this.dbHelper.getReadableDatabase();
		Cursor cursor = db.query(DBInfo.DB_TABLE_NAME, new String[]{DBInfo.USER_HEAD_PATH}, DBInfo.USER_ID+"=?", new String[]{userId}, null, null, null);
		String userIconPath=null;
		if(cursor.moveToFirst())
		{
			userIconPath = cursor.getString(cursor.getColumnIndex(DBInfo.USER_HEAD_PATH));
		}
		cursor.close();
		db.close();
		return userIconPath;
	}
	/**
	 * �����û�ID��ȡ�û�AccessToken����Ч��
	 * @param userId
	 * @return userExpireIn
	 */
	public String getUserExpireInById(String userId)
	{
		SQLiteDatabase db = this.dbHelper.getReadableDatabase();
		Cursor cursor = db.query(DBInfo.DB_TABLE_NAME, new String[]{DBInfo.EXPIRE_IN}, DBInfo.USER_ID+"=?", new String[]{userId}, null, null, null);
		String userExpireIn=null;
		if(cursor.moveToFirst())
		{
			userExpireIn = cursor.getString(cursor.getColumnIndex(DBInfo.EXPIRE_IN));
		}
		cursor.close();
		db.close();
		return userExpireIn;
	}
	/**
	 * �����û�IDȡ���û���AccessToken
	 * @param userId
	 * @return accessToken
	 */
	public String getAccessTokenById(String userId)
	{
		SQLiteDatabase db = this.dbHelper.getReadableDatabase();
		Cursor cursor = db.query(DBInfo.DB_TABLE_NAME, new String[]{DBInfo.ACCESS_TOKEN}, DBInfo.USER_ID+"=?", new String[]{userId}, null, null, null);
		String accessToken=null;
		if(cursor.moveToFirst())
		{
			accessToken = cursor.getString(cursor.getColumnIndex(DBInfo.ACCESS_TOKEN));
		}
		cursor.close();
		db.close();
		return accessToken;
	}
	/**
	 * �����û�IDȡ���û����ǳ�
	 * @param userId
	 * @return userName
	 */
	public String getUserNameById(String userId)
	{
		SQLiteDatabase db = this.dbHelper.getReadableDatabase();
		Cursor cursor = db.query(DBInfo.DB_TABLE_NAME, new String[]{DBInfo.USER_NAME}, DBInfo.USER_ID+"=?", new String[]{userId}, null, null, null);
		String userName=null;
		if(cursor.moveToFirst())
		{
			userName = cursor.getString(cursor.getColumnIndex(DBInfo.USER_NAME));
		}
		cursor.close();
		db.close();
		return userName;
	}
}
