package fly.SinaWeibo.ui;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import fly.SinaWeibo.adapter.AsyncImageLoader;
import fly.SinaWeibo.adapter.AsyncImageLoader.ImageCallback;
import fly.SinaWeibo.utils.FileUtils;
import fly.SinaWeibo.widget.TouchImageView;

public class ImageActivity extends Activity implements IWeibo
{
	private String url;
	private AsyncImageLoader asyncImageLoader;
	private TouchImageView ZoomView;
	private Bitmap bitmap;
//	private BasicZoomListener ZoomListener;
//	private BasicZoomControl ZoomControl;
//	private ZoomControls zoomCtrltools;
	private Button backButton;
	private Button saveButton;
	private Dialog progressDialog;
	private GestureDetector mGestureDetector;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.image);
		url=getIntent().getStringExtra("Url");
		init();
	}
	@Override
	public void init()
	{
		asyncImageLoader=new AsyncImageLoader();
//		ZoomControl = new BasicZoomControl();
//		ZoomListener = new BasicZoomListener();
//		ZoomListener.setZoomControl(ZoomControl);
		backButton=(Button) findViewById(R.id.returnBtn);
        saveButton=(Button) findViewById(R.id.saveBtn);
        saveButton.setEnabled(false);
        backButton.setOnClickListener(new ButtonListener());
        saveButton.setOnClickListener(new ButtonListener());
//		zoomCtrltools = (ZoomControls) findViewById(R.id.zoomCtrl);
//        zoomCtrltools.setClickable(false);
        ZoomView=(TouchImageView)findViewById(R.id.pic);
        ZoomView.setOnTouchListener(mOntouchListener);
        mGestureDetector = new GestureDetector(this, mGestureListener);
        ZoomView.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.loading_preview));
        if(url!=null&&!url.equals(""))
        {
        	 Drawable drawable=AsyncImageLoader.getDrawable(url);
        	 if(drawable==null)
        	 {
        		showProgressDialog("���ڼ���......");
        	    asyncImageLoader.loadDrawable(url, ZoomView, true, new imageCallback());
        	 }
        	 else
        	 {
        		 bitmap=drawableToBitmap(drawable);
        		 ZoomView.setImageBitmap(bitmap);
//        	     zoomCtrltools.setClickable(true);
        	     saveButton.setEnabled(true);
        	 }
        }
//        ZoomView.setZoomState(ZoomControl.getZoomState());
//	    ZoomView.setOnTouchListener(ZoomListener);
//        ZoomControl.setAspectQuotient(ZoomView.getAspectQuotient());
//        resetZoomState();
//        zoomCtrltools.setOnZoomInClickListener(new OnClickListener()
//		{
//			@Override
//			public void onClick(View view)
//			{
//				ZoomControl.zoom(1.25f);
//			}
//		});
//        zoomCtrltools.setOnZoomOutClickListener(new OnClickListener()
//		{
//			@Override
//			public void onClick(View v)
//			{
//				ZoomControl.zoom(0.75f);
//			}
//		});
	}
//	 private void resetZoomState()
//     {
//     	  ZoomControl.getZoomState().setPanX(0.5f);
//          ZoomControl.getZoomState().setPanY(0.5f);
//          ZoomControl.getZoomState().setZoom(1f);
//          ZoomControl.getZoomState().notifyObservers();
//     }
     
     public Bitmap drawableToBitmap(Drawable drawable) 
     {
         Bitmap bitmap = ((BitmapDrawable)drawable).getBitmap(); 
         return bitmap;
      }
   class ButtonListener implements OnClickListener
   {
		@Override
		public void onClick(View v)
		{
		 	switch(v.getId())
			{
				case R.id.returnBtn:
			    	 finish();
					 break;
				case R.id.saveBtn:
					 if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
					 {
						showProgressDialog("���ڱ���......");
						new SaveThread().start();
					 }
					 else
						 Toast.makeText(ImageActivity.this, "SD������", Toast.LENGTH_SHORT).show();
					 break;
			}
		}
   }
   private Handler handler=new Handler()
   {
		@Override
		public void handleMessage(Message msg)
		{
			progressDialog.dismiss();
			String path=(String) msg.obj;
			if(path!=null)
				Toast.makeText(ImageActivity.this, "�ѱ��浽"+path, Toast.LENGTH_SHORT).show(); 
			 else
				Toast.makeText(ImageActivity.this, "����ʧ��!", Toast.LENGTH_SHORT).show(); 
		}
   };
   class SaveThread extends Thread
   {
		@Override
		public void run()
		{
			 FileUtils fileUtils=new FileUtils();
			 String path=fileUtils.saveImage2SD(bitmap, "SinaWeibo/picture", System.currentTimeMillis()+".png");
			 Message msg=handler.obtainMessage();
			 msg.obj=path;
			 handler.sendMessage(msg);
		}
   }
    /**
	 *  ͼƬ�첽����
	 */
	class imageCallback implements ImageCallback
	{
		@Override
		public void imageLoaded(ImageView imageView, Drawable drawable)
		{
		  progressDialog.dismiss();
		  if(drawable!=null)
		   {
			 bitmap=drawableToBitmap(drawable);
			 ZoomView.setImageBitmap(bitmap);
//			 ZoomControl.setAspectQuotient(ZoomView.getAspectQuotient());
//		     resetZoomState();
//		     zoomCtrltools.setClickable(true);
		     saveButton.setEnabled(true);
		   }
		}
	}
	public void showProgressDialog(String info)//��ʾ�Զ��������
	{
        View digView = getLayoutInflater().inflate(R.layout.progress_load_translucent, null);
        TextView textView=(TextView) digView.findViewById(R.id.progress_load_text);
        textView.setText(info);
        progressDialog = new Dialog(this, R.style.dialog_style2);
		progressDialog.setContentView(digView);
        progressDialog.show();
	}
	@Override
	public void refresh(Object... param)
	{}
	
	private OnTouchListener mOntouchListener = new OnTouchListener()
	{
		@Override
		public boolean onTouch(View v, MotionEvent event)
		{
			// TODO Auto-generated method stub
			mGestureDetector.onTouchEvent(event);
			return false;
		}
	};
	
	private GestureDetector.SimpleOnGestureListener mGestureListener =
			new GestureDetector.SimpleOnGestureListener(){
		public boolean onSingleTapConfirmed(android.view.MotionEvent e) {
			finish();
			return super.onSingleTapConfirmed(e);
		};
	};
}
