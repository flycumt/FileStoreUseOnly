package fly.SinaWeibo.ui;

import weibo4j.model.User;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import fly.SinaWeibo.adapter.AsyncImageLoader;
import fly.SinaWeibo.adapter.AsyncImageLoader.ImageCallback;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;
import fly.SinaWeibo.service.UserDBService;
import fly.SinaWeibo.service.UserPreference;
import fly.SinaWeibo.utils.FileUtils;
import fly.SinaWeibo.utils.GetIconUtil;
import fly.SinaWeibo.utils.ImageUtil;

public class InfoActivity extends Activity implements IWeibo
{
	private View titleView;
	private View attentionView;
	private View weiboView;
	private View fansView;
	private View topicView;
	private View favView;
	private View blacklistView;
	private Button newButton;
	private Button refreshButton;
	private Button editButton;
	private ImageView userIcon;
	private ImageView maleImage;
	private ImageView femaleImage;
	private ImageView vipImage;
	private TextView nameText;
	private TextView addressText;
	private TextView accountText;
	private TextView introText;
	private TextView attentionText;
	private TextView weiboText;
	private TextView fansText;
	private TextView topicText;
	private TextView favText;
	private TextView titleText;
	private Dialog progressDialog;
	private User nowUser;
	private UserPreference userPreference;
	private UserDBService userService;
	private Drawable drawable;
	private String userAccount;
	private AsyncImageLoader asyncImageLoader;
	private int totalAttentionPage=1;
	private int totalWeiboPage=1;
	private int totalFollowersPage=1;
	private int totalTrendsPage=1;
	private int totalFavsPage=1;
	private int totalAttentionNum;
	private int totalWeiboNum;
	private int totalFollowersNum;
	private int totalTrendsNum;
	private int totalFavsNum;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.info);
		MainService.addActivity(this);
		SysApplication.getInstance().addActivity(this);
		MainService.addTask(new Task(TaskID.GET_USER_INFO, null));
		userPreference=new UserPreference(this);
		userService=new UserDBService(this);
		asyncImageLoader=new AsyncImageLoader();
		init();
	}
	
	@Override
	public void init()
	{
		showProgressDialog("���ڼ���......");
		attentionView=findViewById(R.id.myinfo_attention_layout);
		weiboView=findViewById(R.id.myinfo_weibo_layout);
		fansView=findViewById(R.id.myinfo_fans_layout);
		topicView=findViewById(R.id.myinfo_topic_layout);
		favView=findViewById(R.id.myinfo_fav_layout);
		blacklistView=findViewById(R.id.myinfo_black_list_layout);
		titleView=findViewById(R.id.myinfo_title_bar);
		newButton=(Button) titleView.findViewById(R.id.title_bt_left);
		refreshButton=(Button) titleView.findViewById(R.id.title_bt_right);
		editButton=(Button)findViewById(R.id.myinfo_edit_bt);
		userIcon=(ImageView) findViewById(R.id.myinfo_icon);
		maleImage=(ImageView) findViewById(R.id.myinfo_male_image);
		femaleImage=(ImageView) findViewById(R.id.myinfo_female_image);
		vipImage=(ImageView) findViewById(R.id.myinfo_v);
		nameText=(TextView) findViewById(R.id.myinfo_name);
		addressText=(TextView) findViewById(R.id.myinfo_address);
		accountText=(TextView) findViewById(R.id.myinfo_account);
		introText=(TextView) findViewById(R.id.myinfo_intro);
		attentionText=(TextView) findViewById(R.id.myinfo_attention);
		weiboText=(TextView) findViewById(R.id.myinfo_weibo);
		fansText=(TextView) findViewById(R.id.myinfo_fans);
		topicText=(TextView) findViewById(R.id.myinfo_topic);
		favText=(TextView) findViewById(R.id.myinfo_fav);
		titleText=(TextView) titleView.findViewById(R.id.title_textView);
		titleText.setText("�ҵ�����");
		String path=userPreference.getUserIconSDPath(MainService.nowUserId);
		if(path!=null)
		{
			drawable=GetIconUtil.getDrawImageFromSD(path);
			if(drawable!=null)
			   userIcon.setImageDrawable(drawable);
		}
		nameText.setText(userService.getUserNameById(MainService.nowUserId));
		userAccount=userPreference.getUserAccount(MainService.nowUserId);
		if(!userAccount.equals(""))
			accountText.setText(userAccount);
		attentionView.setOnClickListener(clickListener);
		weiboView.setOnClickListener(clickListener);
		fansView.setOnClickListener(clickListener);
		topicView.setOnClickListener(clickListener);
		favView.setOnClickListener(clickListener);
		blacklistView.setOnClickListener(clickListener);
		editButton.setOnClickListener(clickListener);
		newButton.setOnClickListener(clickListener);
		refreshButton.setOnClickListener(clickListener);
	}

	@Override
	public void refresh(Object... param)
	{
		int taskId=(Integer) param[0];
        switch(taskId)
		{
			case TaskID.RELOAD_USER_INFO:
			case TaskID.GET_USER_INFO:
				 progressDialog.dismiss();
				 if(param[1]!=null)
				    nowUser=(User)param[1];
				 if(nowUser!=null)
				 {
					 if(drawable==null)
						asyncImageLoader.loadDrawable(nowUser.getAvatarLarge(), userIcon, false, new imageCallback());
					 if(nowUser.getVerified())
						 vipImage.setVisibility(View.VISIBLE);
					 if(nowUser.getGender().equals("f"))
					 {
						 maleImage.setVisibility(View.GONE);
						 femaleImage.setVisibility(View.VISIBLE);
					 }
					 addressText.setText(nowUser.getLocation());
					 introText.setText(nowUser.getDescription());
					 totalAttentionNum=nowUser.getFriendsCount();
					 totalAttentionPage=totalAttentionNum%20==0?totalAttentionNum/20:totalAttentionNum/20+1;
					 totalWeiboNum=nowUser.getStatusesCount();
					 totalWeiboPage=totalWeiboNum%20==0?totalWeiboNum/20:totalWeiboNum/20+1;
					 totalFollowersNum=nowUser.getFollowersCount();
					 totalFollowersPage=totalFollowersNum%50==0?totalFollowersNum/50:totalFollowersNum/50+1;
					 totalFavsNum=nowUser.getFavouritesCount();
					 totalFavsPage=totalFavsNum%20==0?totalFavsNum/20:totalFavsNum/20+1;
					 attentionText.setText(totalAttentionNum+"");
					 weiboText.setText(totalWeiboNum+"");
					 fansText.setText(totalFollowersNum+"");
					 if(MainService.userTrends!=null)
					 {
						totalTrendsNum=MainService.userTrends.size();
						totalTrendsPage=totalTrendsNum%20==0?totalTrendsNum/20:totalTrendsNum/20+1;
					    topicText.setText(totalTrendsNum+"");
					 }
					 favText.setText(totalFavsNum+"");
				 }
				 break;
		}
	}
	private OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			Intent intent;
			switch(v.getId())
			{
				case R.id.title_bt_right://ˢ��
					 showProgressDialog("���ڸ���......");
					 MainService.addTask(new Task(TaskID.RELOAD_USER_INFO, null));
					 break;
				case R.id.title_bt_left://����΢��
					 intent=new Intent(InfoActivity.this, NewWeiboActivity.class);
				     intent.putExtra("Type", "����");
					 startActivity(intent);
					 break;
				case R.id.myinfo_edit_bt://�༭
					 //δ�ҵ���Ӧ�ӿ�......�ݲ�֧��...
					 Toast.makeText(InfoActivity.this, "�ݲ�֧��...", Toast.LENGTH_SHORT).show();
					 break;
				case R.id.myinfo_attention_layout://�ҵĹ�ע
					 if(totalAttentionNum>0)
					 {
						 intent=new Intent(InfoActivity.this, FriendsActivity.class);
					     intent.putExtra("totalPage", totalAttentionPage);
					     intent.putExtra("uid",nowUser.getId());
						 startActivity(intent);
					 }
					 break;
				case R.id.myinfo_weibo_layout://�ҵ�΢��
					 if(totalWeiboNum>0)
					 {
						 intent=new Intent(InfoActivity.this, MyWeiboActivity.class);
					     intent.putExtra("totalWeiboPage", totalWeiboPage);
					     intent.putExtra("uid",nowUser.getId());
						 startActivity(intent);
					 }
					 break;
				case R.id.myinfo_fans_layout://�ҵķ�˿
					 if(totalFollowersNum>0)
					 {
						 intent=new Intent(InfoActivity.this, FollowersActivity.class);
					     intent.putExtra("totalPage", totalFollowersPage);
					     intent.putExtra("uid",nowUser.getId());
						 startActivity(intent);
					 }
					 break;
				case R.id.myinfo_topic_layout://�ҵĻ���
					 if(totalTrendsNum>0)
					 {
						 intent=new Intent(InfoActivity.this, TrendsActivity.class);
					     intent.putExtra("totalPage", totalTrendsPage);
					     intent.putExtra("uid",nowUser.getId());
						 startActivity(intent);
					 }
					 break;
				case R.id.myinfo_fav_layout://�ҵ��ղ�
					 if(totalFavsNum>0)
					 {
						 intent=new Intent(InfoActivity.this, FavouritesActivity.class);
					     intent.putExtra("totalPage", totalFavsPage);
						 startActivity(intent);
					 }
					 break;
				case R.id.myinfo_black_list_layout://�ҵĺ�����
					 //δ�ҵ���Ӧ�ӿ�......�ݲ�֧��
					 break;
			}
		}
	}; 
	
	public void saveUserIcon(Drawable drawable)
	{
		String filename=MainService.nowUserId+".jpg";
		Bitmap bitmap=ImageUtil.drawableToBitmap(drawable);
		if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))//�ж�SD���Ƿ���ڣ����ҿ��Զ�д
		{
			String path=new FileUtils().saveImage2SD(bitmap, MainService.headSavePath, filename);//����ͷ��
		    if(path.endsWith(".jpg"))//�������ɹ��򷵻ص�·����Ȼ��.jpg��β
		       userPreference.saveUserIconSDPath(MainService.nowUserId, path);//�����û�ͷ��ı���·��
		}
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu)//����Menu�˵�
    {
    	menu.add(1, 1, 0, "����").setIcon(R.drawable.setting);
		menu.add(1, 2, 1, "�˺Ź���").setIcon(R.drawable.account);
		menu.add(1, 3, 2, "�ٷ�΢��").setIcon(R.drawable.official);
		menu.add(2, 4, 3, "���").setIcon(R.drawable.comment);
		menu.add(2, 5, 4, "����").setIcon(R.drawable.about);
		menu.add(2, 6, 5, "�˳�").setIcon(R.drawable.exit);
    	return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
    	switch (item.getItemId())
		{
			case 1://����
				  break;
			case 2://�˺Ź���
				  break;
			case 3://�ٷ�΢��
				  break;
			case 4://���
				  break;
			case 5://����
				  break;
			case 6://�˳�
				  SysApplication.getInstance().exitConfirmDialog(this);
				  break;
		}
    	return super.onOptionsItemSelected(item);
    }
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode==KeyEvent.KEYCODE_BACK)
		{
			SysApplication.getInstance().exitConfirmDialog(this);
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	public void showProgressDialog(String info)//��ʾ�Զ��������
	{
        View digView = getLayoutInflater().inflate(R.layout.progress_load_translucent, null);
        TextView textView=(TextView) digView.findViewById(R.id.progress_load_text);
        textView.setText(info);
        progressDialog = new Dialog(this, R.style.dialog_style2);
		progressDialog.setContentView(digView);
        progressDialog.show();
	}
	class imageCallback implements ImageCallback
	{
		@Override
		public void imageLoaded(ImageView imageView, Drawable imageDrawable)
		{
		  if(imageDrawable!=null)
		   {
			 imageView.setImageDrawable(imageDrawable);
			 new SaveIconThead(imageDrawable).start();
		   }
		}
	}
	class SaveIconThead extends Thread
	{
		private Drawable drawable;
		public SaveIconThead(Drawable drawable)
		{
			this.drawable = drawable;
		}
		@Override
		public void run()
		{
			saveUserIcon(drawable);
		}
	}
}
