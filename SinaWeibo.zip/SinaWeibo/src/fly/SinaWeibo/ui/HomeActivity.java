package fly.SinaWeibo.ui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import weibo4j.model.Paging;
import weibo4j.model.Status;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.util.Log;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import fly.SinaWeibo.adapter.WeiboListAdapter;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;
import fly.SinaWeibo.service.UserDBService;
import fly.SinaWeibo.utils.EmotionUtil;
import fly.SinaWeibo.utils.WeiboParseUtil;
import fly.SinaWeibo.widget.PullToRefreshListView;
import fly.SinaWeibo.widget.PullToRefreshListView.OnRefreshListener;

public class HomeActivity extends Activity implements IWeibo
{
	public PullToRefreshListView weiboListView;
	public View progressView;
	public TextView titleText;
	public Button newWeiboButton;
	public Button refreshButton;
	public Dialog progressDialog;
	public static List<Status> statusList;
	public WeiboListAdapter weiboAdapter;
	public List<Map<Integer,Boolean>> containList;
	public List<Map<Integer,SpannableString>> highlightList;
	public List<Map<Integer,List<HashMap<String, String>>>> emotionDataList;
	public UserDBService userService;
	public static int page=1;
	public static int totalPage;
	public boolean moreItemClicked=false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);
		MainService.addActivity(this);
		SysApplication.getInstance().addActivity(this);
		init();
	}

	@Override
	public void init()
	{
		weiboListView=(PullToRefreshListView) findViewById(R.id.home_listview);
		weiboListView.setOnRefreshListener(new WeiboRefreshListener());
		weiboListView.setOnItemClickListener(new WeiboClickListener());
		registerForContextMenu(weiboListView);//ע�������Ĳ˵�
		progressView=findViewById(R.id.progress);
		String userId=MainService.nowUserId;
		MainService.addTask(new Task(TaskID.GET_USER_HOME_TIMELINE,null));//��ȡ��ҳ
		View view=findViewById(R.id.home_title_bar);
		titleText=(TextView) view.findViewById(R.id.title_textView);
		userService=new UserDBService(this);
		String userName=userService.getUserNameById(userId);
		titleText.setText(userName==null?"":userName);
		newWeiboButton=(Button) view.findViewById(R.id.title_bt_left);
		newWeiboButton.setOnClickListener(new NewWeiboListener());
		refreshButton=(Button) view.findViewById(R.id.title_bt_right);
		refreshButton.setOnClickListener(new RefreshButtonListener());
		newWeiboButton.setEnabled(false);
		refreshButton.setEnabled(false);
		containList=new ArrayList<Map<Integer,Boolean>>();
		highlightList=new ArrayList<Map<Integer,SpannableString>>();
		emotionDataList=new ArrayList<Map<Integer,List<HashMap<String,String>>>>();
		new EmotionUtil(this);
	}
	
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo)//���������Ĳ˵�
    {
    	super.onCreateContextMenu(menu, v, menuInfo);
    	AdapterContextMenuInfo weiboInfo=(AdapterContextMenuInfo)menuInfo;
    	if(weiboInfo.id!=-1)
    	{
	    	menu.setHeaderTitle("΢������");
	    	menu.add(1, 1, 1, "  ת��");
	    	menu.add(1, 2, 2, "  ����");
	    	menu.add(1, 3, 3, "  �ղ�");
	    	menu.add(1, 4, 4, "  �鿴");
    	}
    }
    
    @Override
    public boolean onContextItemSelected(MenuItem item)//ѡ�������Ĳ˵�
    {
    	AdapterContextMenuInfo weiboInfo=(AdapterContextMenuInfo)item.getMenuInfo();
    	Intent intent;
    	switch (item.getItemId())
		{
			case 1://ת��
				   intent=new Intent(this, NewWeiboActivity.class);
				   intent.putExtra("Type", "ת��");
				   Status status=statusList.get(weiboInfo.position-1);
				   if(status.getRetweetedStatus()!=null)
				   {
					   intent.putExtra("hasSub", true);
					   intent.putExtra("status", status.getText());
				   }
				   else
					   intent.putExtra("hasSub", false);
				   intent.putExtra("WeiboID", weiboInfo.id+"");
				   startActivity(intent);//��������΢������
				   break;
			case 2://����
				   intent=new Intent(this, NewWeiboActivity.class);
				   intent.putExtra("Type", "����");
				   intent.putExtra("WeiboID", weiboInfo.id+"");
				   startActivity(intent);
				   break;
			case 3://�ղ�
				   Map<String, Object> taskParams=new HashMap<String, Object>();
				   taskParams.put("WeiboID", weiboInfo.id+"");
				   MainService.addTask(new Task(TaskID.CREATE_FAVORITES_TASK, taskParams));
				   break;
			case 4://�鿴
				   intent=new Intent(this, WeiboInfoActivity.class);
				   intent.putExtra("position", weiboInfo.position-1);
				   intent.putExtra("WeiboID", weiboInfo.id+"");
				   intent.putExtra("StartCode", 0);
				   startActivity(intent);
				   break;
		}
    	return super.onContextItemSelected(item);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu)//����Menu�˵�
    {
    	menu.add(1, 1, 0, "����").setIcon(R.drawable.setting);
		menu.add(1, 2, 1, "�˺Ź���").setIcon(R.drawable.account);
		menu.add(1, 3, 2, "�ٷ�΢��").setIcon(R.drawable.official);
		menu.add(2, 4, 3, "���").setIcon(R.drawable.comment);
		menu.add(2, 5, 4, "����").setIcon(R.drawable.about);
		menu.add(2, 6, 5, "�˳�").setIcon(R.drawable.exit);
    	return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
    	switch (item.getItemId())
		{
			case 1://����
				  break;
			case 2://�˺Ź���
				  break;
			case 3://�ٷ�΢��
				  break;
			case 4://���
				  break;
			case 5://����
				  break;
			case 6://�˳�
				  SysApplication.getInstance().exitConfirmDialog(this);
				  break;
		}
    	return super.onOptionsItemSelected(item);
    }
	@SuppressWarnings("unchecked")
	@Override
	public void refresh(Object... param)
	{
		int taskID=(Integer) param[0];
        switch (taskID)
		{
			case TaskID.GET_USER_HOME_TIMELINE:
				 if(param[1]!=null)
				 {
				    statusList=(List<Status>) param[1];
				    if(!statusList.isEmpty())
				    {
					 page=1;
					 parseStatus(statusList,page);
					 weiboAdapter=new WeiboListAdapter(this, statusList,containList,highlightList,emotionDataList,R.layout.home_list_item);
					 weiboListView.setAdapter(weiboAdapter);
					 if(titleText.getText().toString().equals(""))
					   if(MainService.nowUser!=null)
						  titleText.setText(MainService.nowUser.getScreenName());
					 newWeiboButton.setEnabled(true);
					 refreshButton.setEnabled(true);
					 moreItemClicked=false;
					 totalPage=(int)(MainService.totalStatusNumber%20==0?MainService.totalStatusNumber/20:MainService.totalStatusNumber/20+1);
				   }
			     }
				 progressView.setVisibility(View.GONE);
				 break;
			case TaskID.GET_REFRESH_WEIBODATA:
				 String updateTime="�������:" +new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()).substring(5, 16);
				 weiboListView.onRefreshComplete(updateTime);
				 if(param[1]!=null)
				 {
				    statusList=(List<Status>) param[1];
				    if(!statusList.isEmpty())
				    {
					 page=1;
					 totalPage=(int)(MainService.totalStatusNumber%20==0?MainService.totalStatusNumber/20:MainService.totalStatusNumber/20+1);
					 parseStatus(statusList,page);
					 weiboAdapter=new WeiboListAdapter(this, statusList,containList,highlightList,emotionDataList,R.layout.home_list_item);
					 weiboListView.setAdapter(weiboAdapter);
					 newWeiboButton.setEnabled(true);
					 refreshButton.setEnabled(true);
					 moreItemClicked=false;
				    }
			     }
				 if(progressDialog!=null)
					 if(progressDialog.isShowing())
						progressDialog.dismiss();
				 break;
			case TaskID.GET_MORE_WEIBODATA:
				 if(param[1]!=null)
				 {
					 List<Status> moreStatusList=(List<Status>) param[1];
					 if(moreStatusList==null||moreStatusList.isEmpty())
					 {
					   weiboAdapter.noMore();
					 }
					 else
					 {
					  for(Status status : moreStatusList)
					      statusList.add(status);
					  parseStatus(moreStatusList,page);
					  weiboAdapter.updateData(statusList,containList,highlightList,emotionDataList);
					  moreItemClicked=false;
					 }
				 }
				 break;
			case TaskID.CREATE_FAVORITES_TASK:
				 boolean success=(Boolean) param[1];
				 Toast.makeText(this, success?"�ղسɹ���":"�ղ�ʧ�ܣ�", Toast.LENGTH_SHORT).show();
				 break;
		}
	}
    
	public void parseStatus(List<Status> statusList,int page)//����΢��
	{
		 int i=0;
		 if(page>1)i=(page-1)*20;//page:1[0-19] page:2[20-39] page:3[40-59] page:4[60-79] page:5[80-99].......		   
		 containList.clear();
		 highlightList.clear();
		 emotionDataList.clear();
		 Map<Integer,Boolean> contentPicMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subcontentMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subcontentPicMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> emotionMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subemotionMap=new HashMap<Integer,Boolean>();
		 Map<Integer,SpannableString> highlightMap=new HashMap<Integer, SpannableString>();
		 Map<Integer,SpannableString> subhighlightMap=new HashMap<Integer, SpannableString>();
		 Map<Integer,List<HashMap<String,String>>> emotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
		 Map<Integer,List<HashMap<String,String>>> subemotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
		 if(statusList!=null&&!statusList.isEmpty())
		 for (Status status : statusList)
		 {
			String contentPicUrl=status.getBmiddlePic();
			String statusText=status.getText();
			if(contentPicUrl!=null&&!contentPicUrl.equals(""))//΢���������Ƿ���ͼƬ
			   contentPicMap.put(i, true);
			else
			   contentPicMap.put(i, false);
			highlightMap.put(i, new WeiboParseUtil(statusText).getHighLight());//΢�����ĸ�������
			if(EmotionUtil.hasEmotion(statusText))//΢���������Ƿ��б���
			{
				emotionMap.put(i, true);
				emotionDataMap.put(i,EmotionUtil.getEmotionData());
			}
			else
				emotionMap.put(i, false);
			if(status.getRetweetedStatus()!=null)//�Ƿ���ת������
			{
				subcontentMap.put(i, true);
				String subContentPicUrl=status.getRetweetedStatus().getBmiddlePic();
				String subStatusText=status.getRetweetedStatus().getText();
				if(subContentPicUrl!=null&&!subContentPicUrl.equals(""))//ת���������Ƿ���ͼƬ
				   subcontentPicMap.put(i, true);
				else
				   subcontentPicMap.put(i, false);
				subhighlightMap.put(i, new WeiboParseUtil(subStatusText).getHighLight());//ת�����ݸ�������
				if(EmotionUtil.hasEmotion(subStatusText))//ת���������Ƿ��б���
				{
					subemotionMap.put(i, true);
					subemotionDataMap.put(i, EmotionUtil.getEmotionData());
				}
				else
					subemotionMap.put(i, false);
			}
			else
				subcontentMap.put(i, false);
			containList.add(contentPicMap);
			containList.add(subcontentMap);
			containList.add(subcontentPicMap);
			containList.add(emotionMap);
			containList.add(subemotionMap);
			highlightList.add(highlightMap);
			highlightList.add(subhighlightMap);
			emotionDataList.add(emotionDataMap);
			emotionDataList.add(subemotionDataMap);
			i++;
		 }
	}
	private class WeiboRefreshListener implements OnRefreshListener//��������ˢ��
	{
		@Override
		public void onRefresh()
		{
			getRefreshData();
		}
	}
	private class RefreshButtonListener implements OnClickListener//����ˢ�°�ť
	{
		@Override
		public void onClick(View v)
		{
			showProgressDialog(HomeActivity.this.getString(R.string.refreshing));//��ʾ�Զ��������
			getRefreshData();
		}
	}
	private class WeiboClickListener implements OnItemClickListener//����΢������¼�
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			Log.e("AAA", "onItemClick");
			if(id==-1)//��ȡ����΢��
			{
				if(!moreItemClicked)
				{
					page++;
					if(page<=totalPage)
					{
						view.findViewById(R.id.moreText).setVisibility(View.GONE);
						view.findViewById(R.id.more_weibo_layout).setVisibility(View.VISIBLE);
						Map<String, Object> taskParams =new HashMap<String, Object>();
						taskParams.put("Paging", new Paging(page, 20));
						MainService.addTask(new Task(TaskID.GET_MORE_WEIBODATA, taskParams));
					}
					else
					{
						weiboAdapter.noMore();
					}
					moreItemClicked=true;
				}
			}
			else
			{
			   Intent intent=new Intent(HomeActivity.this, WeiboInfoActivity.class);
			   intent.putExtra("position", position-1);
			   intent.putExtra("WeiboID",id+"");
			   intent.putExtra("StartCode", 0);
			   startActivity(intent);
			}
		}
	}
	private class NewWeiboListener implements OnClickListener //��������΢����ť
	{
		@Override
		public void onClick(View v)
		{
			Intent intent=new Intent(HomeActivity.this, NewWeiboActivity.class);
		    intent.putExtra("Type", "����");
			startActivity(intent);//��������΢������
		}
	}
	
	public void getRefreshData()//��ȡˢ������
	{
		Task getRefreshWeibo=new Task(TaskID.GET_REFRESH_WEIBODATA, null);
		MainService.addTask(getRefreshWeibo);
		newWeiboButton.setEnabled(false);
		refreshButton.setEnabled(false);
	}
	public void showProgressDialog(String info)//��ʾ�Զ��������
	{
        View digView = getLayoutInflater().inflate(R.layout.progress_load_translucent, null);
        TextView textView=(TextView) digView.findViewById(R.id.progress_load_text);
        textView.setText(info);
        progressDialog = new Dialog(this, R.style.dialog_style2);
		progressDialog.setContentView(digView);
		progressDialog.setCancelable(false);
        progressDialog.show();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode==KeyEvent.KEYCODE_BACK)
		{
			SysApplication.getInstance().exitConfirmDialog(this);
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
