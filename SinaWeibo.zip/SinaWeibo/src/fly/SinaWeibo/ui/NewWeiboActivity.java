package fly.SinaWeibo.ui;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import weibo4j.model.Status;
import weibo4j.model.Trend;
import weibo4j.model.Trends;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import fly.SinaWeibo.adapter.AtAdapter;
import fly.SinaWeibo.adapter.TopicAdapter;
import fly.SinaWeibo.bean.Position;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;
import fly.SinaWeibo.utils.EmotionUtil;
import fly.SinaWeibo.utils.FileUtils;
import fly.SinaWeibo.utils.WeiboParseUtil;

public class NewWeiboActivity extends Activity implements IWeibo
{
	private Button backButton;
	private Button sendButton;
	private ImageButton topicButton;
	private ImageButton locationButton;
	private ImageButton pictureButton;
	private ImageButton atButton;
	private ImageButton faceButton;
	private ImageView photoView;
	private GridView  gridView;
	private View  delwordView;
	private View  progressView;
	private EditText weiboText;
	private TextView limitText;
	private TextView locationText;
	private TextView titleText;
	private CheckBox checkBox;
	private Dialog progressDialog;
    private int type=0;
    private static final int LIMIT_WORD=140;
    private TopicAdapter topicAdapter;
    private AtAdapter atAdapter;
    private List<String> topiclist;
    private List<String> namelist;
    private PopupWindow popupWindow;
    private double[] location;
    private boolean hasPicture=false;
    private boolean hasSub=false;
    private boolean faceSet=false;
    private boolean registed=false;
    private boolean gotlocation=false;
    private boolean addLocation=false;
    private LocationManager locationManager;
    private Location currentLocation;
    private long startTime;
    private static final int PICK_PHOTO_FROM_GALLERY = 105;
    private static final int TAKE_PHOTO_FROM_CAMERA = 106;
    private File currentPhotoFile;
    private String photoPath;
    private String operateType;
    private String WeiboID;
    private String CommentID;
    private String temp="";
    public  static Bitmap bitmapCache;
    private Integer asComment=0;
    private InputMethodManager inputMethodManager;
    private List<Map<String,Integer>> emotionList;
    private MyLocationListener myLocationListener;
    private Thread locationThread;
    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.new_weibo);
    	MainService.addActivity(this);
    	operateType=getIntent().getStringExtra("Type");
		init();
    }
	
	@Override
	public void init()
	{
		backButton=(Button) findViewById(R.id.btn_new_weibo_back);
		backButton.setOnClickListener(new BackButtonListener());
		sendButton=(Button) findViewById(R.id.btn_weibo_new);
		sendButton.setOnClickListener(new SendButtonListener());
		topicButton=(ImageButton) findViewById(R.id.ib_insert_topic);
		topicButton.setOnClickListener(new TopicButtonListener());
		atButton=(ImageButton) findViewById(R.id.ib_insert_at);
		atButton.setOnClickListener(new AtButtonListener());
		faceButton=(ImageButton) findViewById(R.id.ib_face_keyboard);
		faceButton.setOnClickListener(new FaceButtonListener());
		locationButton=(ImageButton) findViewById(R.id.ib_insert_location);
		locationButton.setOnClickListener(new LocateListener());
		pictureButton=(ImageButton) findViewById(R.id.ib_insert_pic);
		pictureButton.setOnClickListener(new PictureListener());
		photoView=(ImageView) findViewById(R.id.iv_insertpic);
		photoView.setOnClickListener(new PictureListener());
		gridView=(GridView) findViewById(R.id.grid_view);
		gridView.setOnItemClickListener(new GridViewClickListener());
		delwordView=findViewById(R.id.text_limit_unit);
		delwordView.setOnClickListener(new DelwordListener());
		progressView=findViewById(R.id.location_progress_view);
		weiboText=(EditText) findViewById(R.id.edit_weibo_text);
		weiboText.addTextChangedListener(new TextChangedListener());
		weiboText.setOnTouchListener(new EditTextTouchListener());
		limitText=(TextView) findViewById(R.id.tv_text_limit);
		titleText=(TextView) findViewById(R.id.txt_weibo_title);
		locationText=(TextView) findViewById(R.id.tv_location);
		locationText.setOnClickListener(new LocationDetailListener());
		checkBox=(CheckBox) findViewById(R.id.as_comment_or_post);
		checkBox.setOnCheckedChangeListener(new CheckedChangeListener());
		if(operateType!=null&&!operateType.equals(""))
		{
			if(operateType.equals("ת��"))
			{
				titleText.setText("ת��΢��");
				checkBox.setText("ͬʱ��Ϊ���۷���");
				checkBox.setVisibility(View.VISIBLE);
				WeiboID=getIntent().getStringExtra("WeiboID");
				hasSub=getIntent().getBooleanExtra("hasSub", false);
				if(hasSub)
				{
					weiboText.setText(new WeiboParseUtil(" "+getIntent().getStringExtra("status")).getHighLight());
					weiboText.setSelection(0, 1);
				}
			}
			if(operateType.equals("����"))
			{
			   titleText.setText("��������");
			   WeiboID=getIntent().getStringExtra("WeiboID");
			}
			if(operateType.equals("�ظ�����"))
			{
			   titleText.setText("�ظ�����");
			   WeiboID=getIntent().getStringExtra("WeiboID");
			   CommentID=getIntent().getStringExtra("CommentID");
			}
			if(operateType.equals("����"))
			{
				String uname=getIntent().getStringExtra("uname");
				if(uname!=null)
				   weiboText.setText("@"+uname+" ");
			}
		}
		inputMethodManager= (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
		emotionList=new ArrayList<Map<String,Integer>>();
	}
    private class BackButtonListener implements OnClickListener//�������ذ�ť
    {
		@Override
		public void onClick(View v)
		{
			MainService.removeActivityByName("NewWeiboActivity");
			finish();
		}
    }
    
    private class SendButtonListener implements OnClickListener//�������Ͱ�ť
    {
		@Override
		public void onClick(View v)
		{
			String str="���ڷ���.....";
			Map<String, Object> taskParams = new HashMap<String, Object>();
			type=MainService.TEXT;
			String status=weiboText.getText().toString();
			if(operateType.equals("����"))
			{
			  if(!TextUtils.isEmpty(status) && countWords(status)<=140)
			  {
					showProgressDialog(str);
					if(hasPicture)
					{
						if(location==null)
					       type=MainService.TEXT_IMAGE;
						else
						{
						   type=MainService.TEXT_IMAGE_LOCATION;
						   taskParams.put("Location", location);
						}
						taskParams.put("photoPath", photoPath);
					}
					else 
					{
						if (location==null)
							type=MainService.TEXT;
						else
						{
							type=MainService.TEXT_LOCATION;
							taskParams.put("Location", location);
						}
					}
					taskParams.put("Status", status);
					taskParams.put("Type", type);
					taskParams.put("addLocation", addLocation);
					Task task = new Task(TaskID.NEW_WEIBO_TASK, taskParams);
					MainService.addTask(task);
			   }
			   else if(countWords(status)>140)
				       showToast("���ݳ�����������!", Toast.LENGTH_SHORT);
			   else if(TextUtils.isEmpty(status))
				       showToast("����Ϊ��!", Toast.LENGTH_SHORT);
			}
			if(operateType.equals("ת��"))
			{
			  if(countWords(status)<=140)
			  {
				showProgressDialog(str);
				taskParams.put("WeiboID",WeiboID);
			    taskParams.put("hasSub", hasSub);
			    taskParams.put("Status", status);//���ӵ�ת������
				taskParams.put("AsComment", asComment);
				MainService.addTask(new Task(TaskID.REPOST_WEIBO_TASK, taskParams));
			  }
			  else if(status.length()>140)
				      showToast("���ݳ�����������!", Toast.LENGTH_SHORT);
			}
			if(operateType.equals("����"))
			{ 
				if(countWords(status)<=140)
			    {
					showProgressDialog(str);
					taskParams.put("WeiboID",WeiboID);
					taskParams.put("Status", status);
					MainService.addTask(new Task(TaskID.COMMENT_WEIBO_TASK, taskParams));
			    }
				else if(countWords(status)>140)
					   showToast("���ݳ�����������!", Toast.LENGTH_SHORT);
				else if(TextUtils.isEmpty(status))
					   showToast("����Ϊ��!", Toast.LENGTH_SHORT);
			}
			if(operateType.equals("�ظ�����"))
			{
				if(countWords(status)<=140)
			    {
					showProgressDialog(str);
					taskParams.put("WeiboID",WeiboID);
					taskParams.put("CommentID",CommentID);
					taskParams.put("Status", status);
					MainService.addTask(new Task(TaskID.REPLY_COMMENT_TASK, taskParams));
			    }
				else if(countWords(status)>140)
					   showToast("���ݳ�����������!", Toast.LENGTH_SHORT);
				else if(TextUtils.isEmpty(status))
					   showToast("����Ϊ��!", Toast.LENGTH_SHORT);
			}
		}
    }
    private class TextChangedListener implements TextWatcher//�����༭��
    {
		@Override
		public void afterTextChanged(Editable s)
		{
			
			String text=s.toString();
			int count=countWords(text);
			if(count>140)
			{
			   limitText.setText("0");
			   weiboText.setText(temp);
			}
			else
			{
			   limitText.setText((LIMIT_WORD-count)+"");
			   temp=text;
			}
		}
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after){}
		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count){}
    }
    //ͳ������
    public int countWords(String str)
	{
		float len = 0;
		for (int i = 0; i < str.length(); i++)
		{
			int temp = (int) str.charAt(i);
			if (temp > 0 && temp < 127)
				len += 0.5;
			else
				len++;
		}
		return Math.round(len);
	}
    private class EditTextTouchListener implements OnTouchListener
    {
		@Override
		public boolean onTouch(View v, MotionEvent event)
		{
			if(gridView.getVisibility()==View.VISIBLE)//����EditText����gridView�ɼ���������Ϊ���ɼ�������������
			{
			   gridView.setVisibility(View.GONE);
			   faceButton.setImageDrawable(getResources().getDrawable(R.drawable.btn_insert_face));
			   inputMethodManager.showSoftInput(weiboText, 0);//��ʾ������
			}
			return false;
		}
    }
    private class DelwordListener implements OnClickListener//����ɾ�����ְ�ť
    {
		@Override
		public void onClick(View v)
		{
			if(countWords(weiboText.getText().toString())>0)
			   showConfirmDialog();
		}
    }
    public void showConfirmDialog()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("ע��");
		builder.setMessage("ȷ��������֣�");
		builder.setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int which)
			{
				dialog.dismiss();
				weiboText.setText("");
			}
		});
		builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener()
		{
			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				dialog.cancel();
			}
		});
		AlertDialog alertDialog=builder.create();
		alertDialog.show();// ��ʾ�Ի���
	}
    private class TopicButtonListener implements OnClickListener //�������ⰴť
    {
		@Override
		public void onClick(View v)
		{
			Editable edit = weiboText.getEditableText();
			edit.insert(weiboText.getSelectionStart(), "#�����뻰������#");// �������λ�ò�������
			weiboText.setSelection(weiboText.getSelectionStart()-8, weiboText.getSelectionStart()-1);//����ѡ��
			if(MainService.trendsList!=null&&!MainService.trendsList.isEmpty())//��ȡ��������
			{
				if(topiclist==null||topiclist.isEmpty())
				{
					topiclist=new ArrayList<String>();
					for (int i = 0; i < MainService.trendsList.size(); i++)
					{
						Trends trends=MainService.trendsList.get(i);
						Trend[] trend=trends.getTrends();
						for (int j = 0; j < trend.length; j++)
						{
							topiclist.add(trend[j].getName());
						}
					}
				}
			    topicAdapter=new TopicAdapter(NewWeiboActivity.this,topiclist,R.layout.topic_at_item);
			    showListView(topicAdapter,weiboText,true);	//��ʾ�����б�
			}
		}
    }
    private class AtButtonListener implements OnClickListener//����@��ť
    {
		@Override
		public void onClick(View v)
		{
			Editable edit = weiboText.getEditableText();
			edit.insert(weiboText.getSelectionStart(),"@�������û���");// �������λ�ò�������
			weiboText.setSelection(weiboText.getSelectionStart()-6, weiboText.getSelectionStart());//����ѡ��
			if(HomeActivity.statusList!=null&&!HomeActivity.statusList.isEmpty())//��ȡ�û��б�
			{
				if(namelist==null||namelist.isEmpty())
				{
					namelist=new ArrayList<String>();
					for(Status status : HomeActivity.statusList)
					{
						String name=status.getUser().getScreenName();
						if(!namelist.contains(name))
							namelist.add(name);
					}
				}
				atAdapter=new AtAdapter(NewWeiboActivity.this,namelist,R.layout.topic_at_item);
			    showListView(atAdapter,weiboText,false);	//��ʾ�û����б�
			}
		}
    }
    class FaceButtonListener implements OnClickListener//����face��ť
    {
		@Override
		public void onClick(View v)
		{
			if(gridView.getVisibility()==View.GONE)
			{
				if(!faceSet)
					setGridView();
				faceButton.setImageDrawable(getResources().getDrawable(R.drawable.btn_insert_keyboard));
				gridView.setVisibility(View.VISIBLE);
				inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);//����������
			}
			else
			{
				gridView.setVisibility(View.GONE);
				faceButton.setImageDrawable(getResources().getDrawable(R.drawable.btn_insert_face));
				inputMethodManager.showSoftInput(weiboText, 0);//��ʾ������
			}
		}
    }
    class GridViewClickListener implements OnItemClickListener
    {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			String phrase=EmotionUtil.emotionStr[position];
			Editable edit = weiboText.getEditableText();
			int start=weiboText.getSelectionStart();//ȡ�ù����ʼλ��
			edit.insert(start,phrase);// �������λ�ò�������
			int end=weiboText.getSelectionStart();//ȡ�ò������ֺ�����ʼλ��
			SpannableString spannableString=new SpannableString(weiboText.getText());
			weiboText.setText(setEmotion(spannableString,start,end,position));//���ñ���
			weiboText.setSelection(end);//���ù��λ��
			switch(position)
			{
				case 61:
				case 65:
				case 66:
					   Toast.makeText(NewWeiboActivity.this, phrase.substring(4, phrase.length()-1), Toast.LENGTH_SHORT).show();
					   break;
				case 67:
					   Toast.makeText(NewWeiboActivity.this, phrase.substring(2, phrase.length()-1), Toast.LENGTH_SHORT).show();
				case 68:
				case 69:
					   Toast.makeText(NewWeiboActivity.this, phrase.substring(3, phrase.length()-1), Toast.LENGTH_SHORT).show();
					   break;
				default:
					   Toast.makeText(NewWeiboActivity.this, phrase.substring(1, phrase.length()-1), Toast.LENGTH_SHORT).show();
					   break;
			}
		}
    }
    //����
    private SpannableString setEmotion(SpannableString spannableString,int start,int end,int position)
	{
    	int id=R.drawable.face01;
    	id+=position;
		Drawable drawable = getResources().getDrawable(id);
		if(drawable!=null)
		{
			drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
			ImageSpan imgSpan = new ImageSpan(drawable);
			spannableString.setSpan(imgSpan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		}
		return spannableString;
	}
    
    //���ñ���ͼƬ��GridView
	public void setGridView()
	{
		int id=R.drawable.face01;
		for (int i = 0; i < 82; i++)
		{
			Map<String,Integer> map=new HashMap<String, Integer>();
			map.put("face", id);
			emotionList.add(map);
			id++;
		}
		SimpleAdapter adapter=new SimpleAdapter(NewWeiboActivity.this, emotionList, R.layout.gridview_item, new String[]{"face"}, new int[]{R.id.emotion_view});
		gridView.setAdapter(adapter);
		faceSet=true;
	}
    public void showListView(ListAdapter adapter,View view,boolean isTopic)//��ʾ�б�
	{
		ListView listView=new ListView(NewWeiboActivity.this);
		listView.setAdapter(adapter);
		if(isTopic)
		  listView.setOnItemClickListener(new TopicItemClickListener());
		else
		  listView.setOnItemClickListener(new AtItemClickListener());
		listView.setBackgroundResource(R.drawable.Translucent_half);
		listView.setCacheColorHint(0);
		popupWindow = new PopupWindow(listView, view.getWidth(), LayoutParams.WRAP_CONTENT);
		popupWindow.setFocusable(true);
		popupWindow.setBackgroundDrawable(new BitmapDrawable());//���õ����Ļ��������ʱȡ��PopupWindow��ʾ
		if(!popupWindow.isShowing())
		    popupWindow.showAsDropDown(view);
		else
			popupWindow.dismiss();
	}
    class TopicItemClickListener implements OnItemClickListener
    {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			popupWindow.dismiss();
			String topic=topiclist.get(position);
		    weiboText.getEditableText().replace(weiboText.getSelectionStart(), weiboText.getSelectionEnd(),topic);
		    weiboText.setSelection(weiboText.getSelectionEnd()+1);//���ù��λ��
		}
    }
    class AtItemClickListener implements OnItemClickListener
    {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			popupWindow.dismiss();
			String name=namelist.get(position);
			Editable edit = weiboText.getEditableText();
		    edit.replace(weiboText.getSelectionStart(), weiboText.getSelectionEnd(),name+" ");// �������λ�ò�������
		    weiboText.setSelection(weiboText.getSelectionEnd());//���ù��λ��
		}
    }
    private Handler handler=new Handler()
    {
		@Override
		public void handleMessage(Message msg)
		{
		  if(location!=null)
		  {
			Map<String, Object> taskParams = new HashMap<String, Object>();
			taskParams.put("Latitude", location[0]);
			taskParams.put("Longitude", location[1]);
			MainService.addTask(new Task(TaskID.GET_USER_ADDRESS, taskParams));
		  }
		  else
		  {
			progressView.setVisibility(View.GONE);
			showToast("��ȡλ��ʧ�ܣ����Ժ����ԣ�", Toast.LENGTH_SHORT);
			gotlocation=false;
		  }
		  super.handleMessage(msg);
		}
    	
    };
	
    private class  LocateListener implements OnClickListener
    {
		@Override
		public void onClick(View v)
		{
			if(gotlocation)
			{
				AlertDialog.Builder builder=new AlertDialog.Builder(NewWeiboActivity.this);
				builder.setTitle("��ʾ��Ϣ");
			    builder.setMessage("ɾ��λ����Ϣ��");
				builder.setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener()
				{			
					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						dialog.cancel();
						locationText.setVisibility(View.GONE);
						addLocation=false;
						gotlocation=false;
						if(registed)
						{
							locationManager.removeUpdates(myLocationListener);
							registed=false;
						}
					}
				});
				builder.setNegativeButton(R.string.cancel, null);
				AlertDialog alertDialog=builder.create();
				alertDialog.show();		
			}
			else
			{
				if(progressView.getVisibility()!=View.VISIBLE)
				{
					progressView.setVisibility(View.VISIBLE);
					if(locationText.getVisibility()==View.VISIBLE)
					{
						locationText.setVisibility(View.GONE);
					}
					addLocation=true;
					getLocation();
				}
			}
		}
    }
    private class PictureListener implements OnClickListener
    {
		@Override
		public void onClick(View v)
		{
			AlertDialog.Builder builder = new AlertDialog.Builder(NewWeiboActivity.this); 
			builder.setTitle("��ѡ��"); 
			if(v==pictureButton)
			{
				final CharSequence[] items = {"�ֻ����","�ֻ�����"};
				builder.setItems(items, new DialogInterface.OnClickListener() 
				{
					public void onClick(DialogInterface dialog, int item)
					{
						switch (item)
						{
							case 0:if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))//�ж�SD���ɶ�д
								      getPhoto();
								   else
									   showToast("SD������", Toast.LENGTH_LONG);
								   break;
							case 1:takephoto();
								   break;
						}
					}
				}); 
				builder.create().show();
			}
			if(v==photoView)
			{
				final CharSequence[] items = {"�鿴","ɾ��"};
				builder.setItems(items, new DialogInterface.OnClickListener() 
				{
					public void onClick(DialogInterface dialog, int item)
					{
						switch (item)
						{
							case 0:
								   startActivityForResult(new Intent(NewWeiboActivity.this,CheckPhotoActivity.class), 11);
								   break;
							case 1:
								   photoView.setVisibility(View.GONE);
								   hasPicture=false;
								   photoPath=null;
								   break;
						}
					}
				}); 
				builder.create().show();	
			}
		} 	
    }
   public void getPhoto()
   {
	   Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
	   intent.setType("image/*");
	   intent.putExtra("crop", "true");
	   intent.putExtra("aspectX", 1);
	   intent.putExtra("aspectY", 1);
	   intent.putExtra("outputX", 80);
	   intent.putExtra("outputY", 80);
	   intent.putExtra("return-data", true);
	   startActivityForResult(intent, PICK_PHOTO_FROM_GALLERY);
   }
   public void takephoto()
   {
		try
		{
			File file=new FileUtils().creatSDDir("DCIM/Camera");// ������Ƭ�Ĵ洢Ŀ¼
			currentPhotoFile = new File(file,System.currentTimeMillis()+".jpg");// �����յ���Ƭ�ļ�����
			Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);   
			intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(currentPhotoFile));   
			startActivityForResult(intent, TAKE_PHOTO_FROM_CAMERA);//�����������
		}
		catch (ActivityNotFoundException e)
		{
			showToast("û���ҵ��������", Toast.LENGTH_LONG);
		}

   }
   @Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
	   try
	   {
		   switch (requestCode)
		   {
			case PICK_PHOTO_FROM_GALLERY:
				 Bitmap photo = (Bitmap) data.getExtras().get("data");
				 bitmapCache=photo;
				 photoView.setImageBitmap(photo);//����Сͼ����ʾ
				 photoView.setVisibility(View.VISIBLE);
			     Uri uri = data.getData();
			     String URI=uri.toString();
			     if(URI.contains(".jpg"))
			    	photoPath = currentPhotoFile.getPath();
			     else
			     {
		             String[] projection = {MediaStore.Images.Media.DATA};
		             Cursor cursor = managedQuery(uri, projection, null, null, null);
		             int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);//����û�ѡ���ͼƬ������ֵ
		             cursor.moveToFirst(); //cursor������һ��
		             photoPath = cursor.getString(column_index);//��������ֵ��ȡͼƬ·��
			     }
	             if(photoPath!=null&&!photoPath.equals(""))
		            hasPicture=true;
	             else
	             {
	            	 hasPicture=false; 
	            	 photoPath=null;
	             }
				 break;
			case TAKE_PHOTO_FROM_CAMERA:
				 Intent intent = new Intent("com.android.camera.action.CROP");
				 intent.setDataAndType(Uri.fromFile(currentPhotoFile), "image/*");
				 intent.putExtra("crop", "true");
				 intent.putExtra("aspectX", 1);
				 intent.putExtra("aspectY", 1);
				 intent.putExtra("outputX", 80);
				 intent.putExtra("outputY", 80);
				 intent.putExtra("return-data", true);
				 startActivityForResult(intent, PICK_PHOTO_FROM_GALLERY);
				 break;
		   }
	   }
	   catch (Exception e) 
	   {
		e.printStackTrace();
		hasPicture=false; 
		photoPath=null;
	   }
	}
	@Override
	public void refresh(Object... param)
	{
		int taskID=(Integer) param[0];
		boolean success=false;
		switch(taskID)
		{
			case TaskID.NEW_WEIBO_TASK:
				 if(progressDialog.isShowing())
				    progressDialog.dismiss();
				 success=(Boolean) param[1];
				 showToast(success?"�����ɹ�!":"����ʧ��!", Toast.LENGTH_SHORT);
				 break;
			case TaskID.GET_USER_ADDRESS:
				 String address=(String) param[1];
				 progressView.setVisibility(View.GONE);
				 if(address!=null)
				 {
				  locationText.setText(address);
				  locationText.setVisibility(View.VISIBLE);
				  gotlocation=true;
				 }
				 else
				 {
				  locationText.setText("�޷���ȡ��ǰ��ַ");
				  locationText.setVisibility(View.VISIBLE); 
				  gotlocation=false;
				 }
				 locationManager.removeUpdates(myLocationListener);
				 registed=false;
				 break;
			case TaskID.REPOST_WEIBO_TASK:
				 if(progressDialog.isShowing())
				    progressDialog.dismiss();
				 success=(Boolean) param[1];
				 showToast(success?"ת���ɹ�!":"ת��ʧ��!", Toast.LENGTH_SHORT);
				 break;
			case TaskID.COMMENT_WEIBO_TASK:
				 if(progressDialog.isShowing())
				    progressDialog.dismiss();
				 success=(Boolean) param[1];
				 showToast(success?"���۳ɹ�!":"����ʧ��!", Toast.LENGTH_SHORT);
				 break;
			case TaskID.REPLY_COMMENT_TASK:
				 if(progressDialog.isShowing())
				    progressDialog.dismiss();
				 success=(Boolean) param[1];
				 showToast(success?"�ظ��ɹ�!":"�ظ�ʧ��!", Toast.LENGTH_SHORT);
				 break;
			case TaskID.GET_USER_LOCATION:
				 Position position=(Position) param[1];
				 if(position!=null)
				 {
					 location=new double[]{position.getLatitude(),position.getLongitude()};
					 Message msg=handler.obtainMessage();
					 handler.sendMessage(msg);
				 }
				 break;
		}
	}
	public void showProgressDialog(String info)//�Զ��������
	{
        View digView = getLayoutInflater().inflate(R.layout.progress_load_translucent, null);
        TextView textView=(TextView) digView.findViewById(R.id.progress_load_text);
        textView.setText(info);
        progressDialog = new Dialog(this, R.style.dialog_style2);
		progressDialog.setContentView(digView);
        progressDialog.show();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode==KeyEvent.KEYCODE_BACK)
		{
			if(popupWindow!=null)
			{
				if(popupWindow.isShowing())
				{
					popupWindow.dismiss();
					return true;
				}
				else
				{
					 MainService.removeActivityByName("NewWeiboActivity");
					 finish();
					 return false;
				}
			}
			else
			{
			 MainService.removeActivityByName("NewWeiboActivity");
			 finish();
			 return false;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	public void getLocation()
	{
		locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
		myLocationListener=new MyLocationListener();
		locationThread=new MyLocateThread();
		Criteria criteria = new Criteria();
		// ���ò�����õ�provider�Ĺ�������
		criteria.setAccuracy(Criteria.ACCURACY_COARSE);// �߾�ȷ
		criteria.setPowerRequirement(Criteria.POWER_LOW);// �ĵ�����
		criteria.setSpeedRequired(true);// �ٶȿ�
		criteria.setCostAllowed(true);
		criteria.setAltitudeRequired(false);// ����Ҫ����
		criteria.setBearingRequired(false);// ����Ҫ��λ��Ϣ
		String provider = locationManager.getBestProvider(criteria, true);// �����õ�provider���ڶ���������ָ�Ƿ�ֻ���ص�ǰ���ڼ���״̬��provider
		if (provider != null && !provider.equals(""))
		{
			currentLocation = locationManager.getLastKnownLocation(provider);
			if (currentLocation != null)
			{
				location=new double[] { currentLocation.getLatitude(), currentLocation.getLongitude() };
				Message msg=handler.obtainMessage();
				handler.sendMessage(msg);
			}
			else
			{
				if(!registed)
				{
					locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, myLocationListener);
					locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0,myLocationListener);
					locationThread.start();
					startTime=System.currentTimeMillis();
					registed=true;
				}
			}
		}
		else
		{
			if(!registed)
			{
				locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, myLocationListener);
				locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, myLocationListener);
				locationThread.start();
				startTime=System.currentTimeMillis();
				registed=true;
			}
		}
	}
	private class MyLocateThread extends Thread
	{
		@Override
		public void run()
		{
			while(currentLocation==null)
			{
				long currentTime=System.currentTimeMillis();
				int duration=(int)((currentTime-startTime)/1000);
				if(duration>10)break;
			}
			if(currentLocation!=null)
			{
			   NewWeiboActivity.this.location=new double[]{currentLocation.getLatitude(),currentLocation.getLongitude()};
			   Message msg=handler.obtainMessage();
			   handler.sendMessage(msg);
			}
			else
			{
				MainService.addTask(new Task(TaskID.GET_USER_LOCATION, null));
			}
		}
	}
	 private class MyLocationListener implements LocationListener
	{
		public void onLocationChanged(Location location)
		{
			currentLocation = location;
		}
		public void onProviderDisabled(String provider){}
		public void onProviderEnabled(String provider){}
		public void onStatusChanged(String provider, int status, Bundle extras){}
	}
	 class CheckedChangeListener implements OnCheckedChangeListener
	 {
		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
		{
			if(isChecked)
			  asComment=1;
			else
			  asComment=0;
		}
	 }
	class LocationDetailListener implements OnClickListener
	{
		@Override
		public void onClick(View v)
		{
			String address=locationText.getText().toString();
			if(address!=null&&!address.equals("")&&!address.equals(""))
			{
				AlertDialog.Builder builder=new AlertDialog.Builder(NewWeiboActivity.this);
				builder.setTitle("λ����Ϣ");
				if(location!=null)
				   builder.setMessage("��ǰλ�ã�"+address+"������������"+location[1]+"�ȣ�"+"��γ��"+location[0]+"�ȡ�");
				else
				   builder.setMessage("��ǰλ�ã�"+address+"������");
				builder.setNegativeButton("ȷ��", new DialogInterface.OnClickListener()
				{			
					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						dialog.cancel();
					}
				});
				AlertDialog alertDialog=builder.create();
				alertDialog.show();		
			}
		}
	}
	@Override
	protected void onDestroy()
	{
		if(registed)
		{
		   locationManager.removeUpdates(myLocationListener);
		   registed=false;
		}
		super.onDestroy();
	}	public void  showToast(String info,int duration)
    {
	 Toast.makeText(NewWeiboActivity.this, info, duration).show();
    }
}
