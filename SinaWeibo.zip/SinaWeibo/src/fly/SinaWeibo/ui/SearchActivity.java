package fly.SinaWeibo.ui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import weibo4j.model.Status;
import weibo4j.model.User;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableString;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.AdapterContextMenuInfo;
import fly.SinaWeibo.adapter.SearchUserAdapter;
import fly.SinaWeibo.adapter.WeiboListAdapter;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;
import fly.SinaWeibo.utils.EmotionUtil;
import fly.SinaWeibo.utils.WeiboParseUtil;
import fly.SinaWeibo.widget.PullToRefreshListView;
import fly.SinaWeibo.widget.PullToRefreshListView.OnRefreshListener;

public class SearchActivity extends Activity implements IWeibo
{
	private View searchWeiboView;
	private View searchPeopleView;
	private ImageView leftImageRadio;
	private ImageView rightImageRadio;
	private ListView userListView;
	private PullToRefreshListView weiboListView;
	private boolean leftClicked=true;
	private boolean rightClicked=false;
	private boolean searchPeople=false;
	private boolean searchWeibo=true;
	private boolean moreItemClicked=false;
	private ImageView searchButton;
	private EditText searchText;
	private int weiboPage=1;
	private int count=10;
	private int totalPage=1;
	private int position;
	private Dialog progressDialog;
	private List<User> userList;
	public  static List<Status> weiboList;
	private SearchUserAdapter userAdapter;
	private WeiboListAdapter weiboAdapter;
	private List<Map<Integer,Boolean>> containList;
	private List<Map<Integer,SpannableString>> highlightList;
	private List<Map<Integer,List<HashMap<String, String>>>> emotionDataList;
	private String searchKey;
	public static User searchedUser;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.search);
    	MainService.addActivity(this);
    	SysApplication.getInstance().addActivity(this);
    	init();
    }
	@Override
	public void init()
	{
		searchWeiboView=findViewById(R.id.search_weibo_view);
		searchPeopleView=findViewById(R.id.search_people_view);
		searchWeiboView.setOnClickListener(chooseListener);
		searchPeopleView.setOnClickListener(chooseListener);
		leftImageRadio=(ImageView) findViewById(R.id.search_left_radio);
		rightImageRadio=(ImageView) findViewById(R.id.search_right_radio);
		searchButton=(ImageView) findViewById(R.id.search_button);
		searchText=(EditText) findViewById(R.id.search_text);
		searchButton.setOnClickListener(new SearchListener());
		userListView=(ListView) findViewById(R.id.search_peopleList);
		userListView.setOnItemClickListener(new UserListViewClickListener());
		weiboListView=(PullToRefreshListView) findViewById(R.id.search_weiboList);
		weiboListView.setOnRefreshListener(new RefreshListener());
		registerForContextMenu(weiboListView);
		weiboListView.setOnItemClickListener(new ItemClickListener());
		containList=new ArrayList<Map<Integer,Boolean>>();
		highlightList=new ArrayList<Map<Integer,SpannableString>>();
		emotionDataList=new ArrayList<Map<Integer,List<HashMap<String,String>>>>();
		new EmotionUtil(this);
	}
	@Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo)//���������Ĳ˵�
    {
    	super.onCreateContextMenu(menu, v, menuInfo);
    	AdapterContextMenuInfo weiboInfo=(AdapterContextMenuInfo)menuInfo;
    	if(weiboInfo.id!=-1)
    	{
	    	menu.setHeaderTitle("΢������");
	    	menu.add(1, 1, 1, "  ת��");
	    	menu.add(1, 2, 2, "  ����");
	    	menu.add(1, 3, 3, "  �ղ�");
	    	menu.add(1, 4, 4, "  �鿴");
    	}
    }
    @Override
    public boolean onContextItemSelected(MenuItem item)//ѡ�������Ĳ˵�
    {
    	AdapterContextMenuInfo weiboInfo=(AdapterContextMenuInfo)item.getMenuInfo();
    	Intent intent;
    	switch (item.getItemId())
		{
			case 1://ת��
				   intent=new Intent(this, NewWeiboActivity.class);
				   intent.putExtra("Type", "ת��");
				   Status status=weiboList.get(weiboInfo.position-1);
				   if(status.getRetweetedStatus()!=null)
				   {
					   intent.putExtra("hasSub", true);
					   intent.putExtra("status", status.getText());
				   }
				   else
					   intent.putExtra("hasSub", false);
				   intent.putExtra("WeiboID", weiboInfo.id+"");
				   startActivity(intent);//��������΢������
				   break;
			case 2://����
				   intent=new Intent(this, NewWeiboActivity.class);
				   intent.putExtra("Type", "����");
				   intent.putExtra("WeiboID", weiboInfo.id+"");
				   startActivity(intent);
				   break;
			case 3://�ղ�
				   Map<String, Object> taskParams=new HashMap<String, Object>();
				   taskParams.put("WeiboID", weiboInfo.id+"");
				   MainService.addTask(new Task(TaskID.CREATE_FAVORITES_INSEARCH, taskParams));
				   break;
			case 4://�鿴
				   intent=new Intent(this, WeiboInfoActivity.class);
				   intent.putExtra("position", weiboInfo.position-1);
				   intent.putExtra("WeiboID", weiboInfo.id+"");
				   intent.putExtra("StartCode", 4);
				   startActivity(intent);
				   break;
		}
    	return super.onContextItemSelected(item);
    }
    private OnClickListener chooseListener = new OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			switch(view.getId())
			{
				case R.id.search_weibo_view:
					 searchText.setHint(R.string.search_weibo_hint);
					 userListView.setVisibility(View.GONE);
					 weiboListView.setVisibility(View.VISIBLE);
					 leftImageRadio.setImageDrawable(getResources().getDrawable(R.drawable.search_radio_sel));
					 leftClicked=true;
					 if(rightClicked)
						rightImageRadio.setImageDrawable(getResources().getDrawable(R.drawable.search_radio));
					 searchWeibo=true;
					 searchPeople=false;
					 break;
                case R.id.search_people_view:
                	 searchText.setHint(R.string.search_people_hint);
  	    		     weiboListView.setVisibility(View.GONE);
  	    		     userListView.setVisibility(View.VISIBLE);
                	 rightImageRadio.setImageDrawable(getResources().getDrawable(R.drawable.search_radio_sel));
                	 rightClicked=true;
                	 if(leftClicked)
                		leftImageRadio.setImageDrawable(getResources().getDrawable(R.drawable.search_radio));
                	 searchPeople=true;
                	 searchWeibo=false;
					 break;
			}
		}
	};
	class SearchListener implements OnClickListener
	{
		@Override
		public void onClick(View v)
		{
			searchKey=searchText.getText().toString();
			Map<String, Object> taskParams = new HashMap<String, Object>();
			taskParams.put("searchKey", searchKey);
			if(searchPeople)//����
			{
			   showProgressDialog("��������......");
			   MainService.addTask(new Task(TaskID.SEARCH_USER_SUGGESTIONS, taskParams));
			}
			if(searchWeibo)//��΢��
			{
			   showProgressDialog("��������......");
			   taskParams.put("page", weiboPage);
			   taskParams.put("count",count);
			   MainService.addTask(new Task(TaskID.SEARCH_WEIBO_BYTOPIC, taskParams));
			}
			
		}
	}
	@SuppressWarnings({"unchecked" })
	@Override
	public void refresh(Object... param)
	{
		int taskID=(Integer) param[0];
        switch (taskID)
		{
			 case TaskID.SEARCH_WEIBO_BYTOPIC://��΢��
				  progressDialog.dismiss();
				  if(param[1]!=null)
				  {
					weiboList=(List<Status>) param[1];
					if(!weiboList.isEmpty())
					{
						if(param[2]!=null)
						{
							int totalNum=(Integer) param[2];
							totalPage=totalNum%10==0?totalNum/10:totalNum/10+1;
						}
						parseStatus(weiboList,weiboPage);
						weiboAdapter=new WeiboListAdapter(this, weiboList,containList,highlightList,emotionDataList,R.layout.home_list_item);
						weiboListView.setAdapter(weiboAdapter);
					}
				  }
				  break;
			 case TaskID.REFRESH_SEARCH_STATUS:
				  String updateTime="�������:" +new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.CHINA).format(new Date()).substring(5, 16);
				  weiboListView.onRefreshComplete(updateTime);
				  if(param[1]!=null)
				  {
					weiboList=(List<Status>) param[1];
				    if(!weiboList.isEmpty())
				    {
			    	  if(param[2]!=null)
					  {
						int totalNum=(Integer) param[2];
						totalPage=totalNum%10==0?totalNum/10:totalNum/10+1;
					  }
				     weiboPage=1;
					 parseStatus(weiboList,weiboPage);
					 weiboAdapter=new WeiboListAdapter(this, weiboList,containList,highlightList,emotionDataList,R.layout.home_list_item);
					 weiboListView.setAdapter(weiboAdapter);
					 moreItemClicked=false;
				    }
				  }
				  if(progressDialog!=null)
					 if(progressDialog.isShowing())
						progressDialog.dismiss();
			 	  break;
			 case TaskID.GET_MORE_SEARCHWEIBO:
				  if(param[1]!=null)
				  {
					 List<Status> moreStatusList=(List<Status>) param[1];
					 if(moreStatusList==null||moreStatusList.isEmpty())
					 {
					   weiboAdapter.noMore();
					 }
					 else
					 {
					  for(Status status : moreStatusList)
					      weiboList.add(status);
					  parseStatus(moreStatusList,weiboPage);
					  weiboAdapter.updateData(weiboList,containList,highlightList,emotionDataList);
					  moreItemClicked=false;
					 }
				  }
				  break;
			 case TaskID.CREATE_FAVORITES_INSEARCH:
				  boolean success=(Boolean) param[1];
				  Toast.makeText(this, success?"�ղسɹ���":"�ղ�ʧ�ܣ�", Toast.LENGTH_SHORT).show();
				  break;
		     case TaskID.SEARCH_USER_SUGGESTIONS://���û�
		    	  progressDialog.dismiss();
		    	  userList= (List<User>) param[1];
		    	  if(userList!=null)
		    	  {
		    		  userAdapter=new SearchUserAdapter(this, userList, handler, R.layout.search_user_list_item);
		    		  userListView.setAdapter(userAdapter);
		    	  }
		    	  break;
		     case TaskID.CREATE_FRIENDS_TASK://��ע
				 boolean ok=(Boolean) param[1];
				 Toast.makeText(this,ok?"��ע�ɹ���":"��עʧ�ܣ�", Toast.LENGTH_SHORT).show();
				 if(ok)
				 {
					 SearchUserAdapter.attentionButtonCache.get(position).setVisibility(View.GONE);
					 SearchUserAdapter.unAttentionButtonCache.get(position).setVisibility(View.VISIBLE);
				 }
				 break;
			 case TaskID.DELETE_FRIENDS_TASK://ȡ����ע
				 boolean succeed=(Boolean) param[1];
				 Toast.makeText(this, succeed?"ȡ����ע�ɹ���":"����ʧ�ܣ�", Toast.LENGTH_SHORT).show();
				 if(succeed)
				 {
					 SearchUserAdapter.unAttentionButtonCache.get(position).setVisibility(View.GONE);
					 SearchUserAdapter.attentionButtonCache.get(position).setVisibility(View.VISIBLE);
				 }
				 break;
		}
	}
	private Handler handler = new Handler()
	{
		@Override
		public void handleMessage(Message msg)
		{
			String uid=(String) msg.obj;
			Map<String, Object> taskParams=new HashMap<String, Object>();
			position=msg.arg1;
			switch(msg.what)
			{
				case 1://��ע
				      taskParams.put("uid", uid);
				      MainService.addTask(new Task(TaskID.CREATE_FRIENDS_TASK, taskParams));
					  break;
				case 2://ȡ����ע
					  taskParams.put("uid", uid);
				      MainService.addTask(new Task(TaskID.DELETE_FRIENDS_TASK, taskParams));
					  break;
			}
		}
	};
	public void parseStatus(List<Status> statusList,int page)//����΢��
	{
		 int i=0;
		 if(page>1)i=(page-1)*10;//page:1[0-9] page:2[10-19] page:3[20-29] ......		   
		 containList.clear();
		 highlightList.clear();
		 emotionDataList.clear();
		 Map<Integer,Boolean> contentPicMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subcontentMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subcontentPicMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> emotionMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subemotionMap=new HashMap<Integer,Boolean>();
		 Map<Integer,SpannableString> highlightMap=new HashMap<Integer, SpannableString>();
		 Map<Integer,SpannableString> subhighlightMap=new HashMap<Integer, SpannableString>();
		 Map<Integer,List<HashMap<String,String>>> emotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
		 Map<Integer,List<HashMap<String,String>>> subemotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
		 if(statusList!=null&&!statusList.isEmpty())
		 for (Status status : statusList)
		 {
			String contentPicUrl=status.getBmiddlePic();
			String statusText=status.getText();
			if(contentPicUrl!=null&&!contentPicUrl.equals(""))//΢���������Ƿ���ͼƬ
			   contentPicMap.put(i, true);
			else
			   contentPicMap.put(i, false);
			highlightMap.put(i, new WeiboParseUtil(statusText).getHighLight());//΢�����ĸ�������
			if(EmotionUtil.hasEmotion(statusText))//΢���������Ƿ��б���
			{
				emotionMap.put(i, true);
				emotionDataMap.put(i,EmotionUtil.getEmotionData());
			}
			else
				emotionMap.put(i, false);
			if(status.getRetweetedStatus()!=null)//�Ƿ���ת������
			{
				subcontentMap.put(i, true);
				String subContentPicUrl=status.getRetweetedStatus().getBmiddlePic();
				String subStatusText=status.getRetweetedStatus().getText();
				if(subContentPicUrl!=null&&!subContentPicUrl.equals(""))//ת���������Ƿ���ͼƬ
				   subcontentPicMap.put(i, true);
				else
				   subcontentPicMap.put(i, false);
				subhighlightMap.put(i, new WeiboParseUtil(subStatusText).getHighLight());//ת�����ݸ�������
				if(EmotionUtil.hasEmotion(subStatusText))//ת���������Ƿ��б���
				{
					subemotionMap.put(i, true);
					subemotionDataMap.put(i, EmotionUtil.getEmotionData());
				}
				else
					subemotionMap.put(i, false);
			}
			else
				subcontentMap.put(i, false);
			containList.add(contentPicMap);
			containList.add(subcontentMap);
			containList.add(subcontentPicMap);
			containList.add(emotionMap);
			containList.add(subemotionMap);
			highlightList.add(highlightMap);
			highlightList.add(subhighlightMap);
			emotionDataList.add(emotionDataMap);
			emotionDataList.add(subemotionDataMap);
			i++;
		 }
	}
	class ItemClickListener implements OnItemClickListener
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			if(id==-1)//��ȡ����΢��
			{
				if(!moreItemClicked)
				{
					weiboPage++;
					if(weiboPage<=totalPage)
					{
						view.findViewById(R.id.moreText).setVisibility(View.GONE);
						view.findViewById(R.id.more_weibo_layout).setVisibility(View.VISIBLE);
						Map<String, Object> taskParams =new HashMap<String, Object>();
						taskParams.put("searchKey",searchKey);
						taskParams.put("page", weiboPage);
						taskParams.put("count",count);
						MainService.addTask(new Task(TaskID.GET_MORE_SEARCHWEIBO, taskParams));
					}
					else
					{
						weiboAdapter.noMore();
					}
					moreItemClicked=true;
				}
			}
			else
			{
			   Intent intent=new Intent(SearchActivity.this, WeiboInfoActivity.class);
			   intent.putExtra("position", position-1);
			   intent.putExtra("WeiboID",id+"");
			   intent.putExtra("StartCode", 4);
			   startActivity(intent);
			}			
		}
	}
	class UserListViewClickListener implements OnItemClickListener
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			searchedUser=userList.get(position);
			Intent intent=new Intent(SearchActivity.this,UserInfoActivity.class);
			intent.putExtra("UID", searchedUser.getId());
			intent.putExtra("flg", "fromSearch");
			startActivity(intent);
		}
	}
	class RefreshListener implements OnRefreshListener
	{
		@Override
		public void onRefresh()
		{
		   showProgressDialog("����ˢ��......");
		   Map<String, Object> taskParams=new HashMap<String, Object>();
		   taskParams.put("page", 1);
		   taskParams.put("count",count);
		   MainService.addTask(new Task(TaskID.SEARCH_WEIBO_BYTOPIC, taskParams));
		}
	}
	public void showProgressDialog(String info)//��ʾ�Զ��������
	{
        View digView = getLayoutInflater().inflate(R.layout.progress_load_translucent, null);
        TextView textView=(TextView) digView.findViewById(R.id.progress_load_text);
        textView.setText(info);
        progressDialog = new Dialog(this, R.style.dialog_style2);
		progressDialog.setContentView(digView);
        progressDialog.show();
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu)//����Menu�˵�
    {
    	menu.add(1, 1, 0, "����").setIcon(R.drawable.setting);
		menu.add(1, 2, 1, "�˺Ź���").setIcon(R.drawable.account);
		menu.add(1, 3, 2, "�ٷ�΢��").setIcon(R.drawable.official);
		menu.add(2, 4, 3, "���").setIcon(R.drawable.comment);
		menu.add(2, 5, 4, "����").setIcon(R.drawable.about);
		menu.add(2, 6, 5, "�˳�").setIcon(R.drawable.exit);
    	return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
    	switch (item.getItemId())
		{
			case 1://����
				  break;
			case 2://�˺Ź���
				  break;
			case 3://�ٷ�΢��
				  break;
			case 4://���
				  break;
			case 5://����
				  break;
			case 6://�˳�
				  SysApplication.getInstance().exitConfirmDialog(this);
				  break;
		}
    	return super.onOptionsItemSelected(item);
    }
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode==KeyEvent.KEYCODE_BACK)
		{
			SysApplication.getInstance().exitConfirmDialog(this);
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
