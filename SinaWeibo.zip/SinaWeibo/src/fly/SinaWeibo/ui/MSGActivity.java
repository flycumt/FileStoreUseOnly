package fly.SinaWeibo.ui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import weibo4j.model.Comment;
import weibo4j.model.Paging;
import weibo4j.model.Status;
import weibo4j.model.User;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableString;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import fly.SinaWeibo.adapter.CommentAdapter;
import fly.SinaWeibo.adapter.WeiboListAdapter;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;
import fly.SinaWeibo.utils.EmotionUtil;
import fly.SinaWeibo.utils.WeiboParseUtil;
import fly.SinaWeibo.widget.PullToRefreshListView;
import fly.SinaWeibo.widget.PullToRefreshListView.OnRefreshListener;

public class MSGActivity extends Activity implements IWeibo
{
	private RadioButton atButton;
	private RadioButton commentButton;
//	private RadioButton letterButton;
	private TextView letterText;
	private PullToRefreshListView atListView;
	private ListView commentListView;
	private WeiboListAdapter weiboListAdapter;
	private CommentAdapter commentAdapter;
	public  static List<Status> atStatusLsit;
	private List<Comment> commentList;
	private Dialog progressDialog;
	private int atPage=1;
	private int commentPage=1;
	private int totalAtPage=1;
	private int totalCommentPage=1;
	private List<Map<Integer,Boolean>> containList;
	private List<Map<Integer,SpannableString>> highlightList;
	private List<Map<Integer,List<HashMap<String, String>>>> emotionDataList;
	private Map<Integer,SpannableString> highLightMap;
	private Map<Integer,Boolean> hasEmotionMap;
	private Map<Integer,List<HashMap<String,String>>> emotionDataMap;
	private boolean moreAtItemClicked=false;
	private boolean moreCommentClicked=false;
	public static User commentUser;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.message);
    	MainService.addActivity(this);
    	SysApplication.getInstance().addActivity(this);
    	init();
    }
	
	@Override
	public void init()
	{
		atButton=(RadioButton) findViewById(R.id.msg_atme);
		commentButton=(RadioButton) findViewById(R.id.msg_comment);
//		letterButton=(RadioButton) findViewById(R.id.msg_letter);
		atListView=(PullToRefreshListView) findViewById(R.id.msg_atList);
		atListView.setOnRefreshListener(new WeiboRefreshListener());
		atListView.setOnItemClickListener(new WeiboClickListener());
		commentListView=(ListView) findViewById(R.id.msg_commentList);
		commentListView.setOnItemClickListener(new CommentClickListener());
		registerForContextMenu(atListView);
		registerForContextMenu(commentListView);
		letterText=(TextView) findViewById(R.id.msg_letterText);
		atButton.setOnCheckedChangeListener(radioButtonCheckedListener);
		commentButton.setOnCheckedChangeListener(radioButtonCheckedListener);
//		letterButton.setOnCheckedChangeListener(radioButtonCheckedListener);
		atButton.setChecked(true);
		containList=new ArrayList<Map<Integer,Boolean>>();
		highlightList=new ArrayList<Map<Integer,SpannableString>>();
		emotionDataList=new ArrayList<Map<Integer,List<HashMap<String,String>>>>();
		highLightMap=new HashMap<Integer, SpannableString>();
	    hasEmotionMap=new HashMap<Integer, Boolean>();
	    emotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
	    new EmotionUtil(this);
	}
	private OnCheckedChangeListener radioButtonCheckedListener =new OnCheckedChangeListener()
	{
		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
		{
			if(isChecked)
			{
				switch (buttonView.getId())
				{
					case R.id.msg_atme://@�ҵ�΢��
						 if(weiboListAdapter==null)
						 {
							 showProgressDialog("���ڼ���......");
							 Map<String, Object> taskParams=new HashMap<String, Object>();
							 taskParams.put("Paging", new Paging(atPage, 20));
							 MainService.addTask(new Task(TaskID.GET_MENTION_STATUS, taskParams));
						 }
						 else
						 {
							 atListView.setVisibility(View.VISIBLE);
							 commentListView.setVisibility(View.GONE);
							 letterText.setVisibility(View.GONE);
						 }
						 break;
					case R.id.msg_comment://���յ�������
					     atListView.setVisibility(View.GONE);
						 letterText.setVisibility(View.GONE);
						 if(commentAdapter==null)
						 {
							 showProgressDialog("���ڼ���......");
							 Map<String, Object> taskParams=new HashMap<String, Object>();
							 taskParams.put("Paging", new Paging(commentPage, 20));
							 MainService.addTask(new Task(TaskID.GET_COMMENTS_TOME, taskParams));
						 }
						 else
							 commentListView.setVisibility(View.VISIBLE);
					 break;
//				case R.id.msg_letter://���յ���˽��
//					 //δ�ҵ���Ӧ�ӿ�......�ݲ�֧��
//					 commentListView.setVisibility(View.GONE);
//					 atListView.setVisibility(View.GONE);
//					 letterText.setVisibility(View.VISIBLE);
//					 break;
			}
			}
		}
	};
	@Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo)//���������Ĳ˵�
    {
    	super.onCreateContextMenu(menu, v, menuInfo);
    	AdapterContextMenuInfo adapterInfo=(AdapterContextMenuInfo)menuInfo;
    	switch(v.getId())
		{
			case R.id.msg_atList:
				 if(adapterInfo.id!=-1)
		    	 {
			    	menu.setHeaderTitle("΢������");
			    	menu.add(1, 1, 1, "  ת��");
			    	menu.add(1, 2, 2, "  ����");
			    	menu.add(1, 3, 3, "  �ղ�");
			    	menu.add(1, 4, 4, "  �鿴");
		    	 }
				 break;
			case R.id.msg_commentList:
				 if(adapterInfo.id!=-1)
		    	 {
			    	menu.setHeaderTitle("����");
			    	menu.add(1, 5, 1, "  �ظ�����");
		    	 }
				 break;
		}
    }
	@Override
    public boolean onContextItemSelected(MenuItem item)//ѡ�������Ĳ˵�
    {
    	AdapterContextMenuInfo menuInfo=(AdapterContextMenuInfo)item.getMenuInfo();
    	Intent intent;
    	switch (item.getItemId())
		{
			case 1://ת��
				   intent=new Intent(this, NewWeiboActivity.class);
				   intent.putExtra("Type", "ת��");
				   Status status=atStatusLsit.get(menuInfo.position-1);
				   if(status.getRetweetedStatus()!=null)
				   {
					   intent.putExtra("hasSub", true);
					   intent.putExtra("status", status.getText());
				   }
				   else
					   intent.putExtra("hasSub", false);
				   intent.putExtra("WeiboID", menuInfo.id+"");
				   startActivity(intent);//��������΢������
				   break;
			case 2://����
				   intent=new Intent(this, NewWeiboActivity.class);
				   intent.putExtra("Type", "����");
				   intent.putExtra("WeiboID", menuInfo.id+"");
				   startActivity(intent);
				   break;
			case 3://�ղ�
				   Map<String, Object> taskParams=new HashMap<String, Object>();
				   taskParams.put("WeiboID", menuInfo.id+"");
				   MainService.addTask(new Task(TaskID.CREATE_FAVORITES_INMSG, taskParams));
				   break;
			case 4://�鿴
				   intent=new Intent(this, WeiboInfoActivity.class);
				   intent.putExtra("position", menuInfo.position-1);
				   intent.putExtra("WeiboID", menuInfo.id+"");
				   intent.putExtra("StartCode", 3);
				   startActivity(intent);
				   break;
			case 5://�ظ�����
				   Status comStatus=commentList.get(menuInfo.position).getStatus();
				   if(comStatus!=null)
				   {
					   intent=new Intent(this, NewWeiboActivity.class);
					   intent.putExtra("Type", "�ظ�����");
					   intent.putExtra("CommentID", menuInfo.id+"");
					   intent.putExtra("WeiboID", comStatus.getId()+"");
					   startActivity(intent);
				   }
				   else
					   Toast.makeText(MSGActivity.this, "������ˣ�", Toast.LENGTH_SHORT).show();
				   break;
		}
    	return super.onContextItemSelected(item);
    }
	@SuppressWarnings("unchecked")
	@Override
	public void refresh(Object... param)
	{
		int taskId=(Integer) param[0];
		switch(taskId)
		{
		    case TaskID.GET_MENTION_STATUS:
		    	 if(param[1]!=null)
		    	 {
		    	     atStatusLsit=(List<Status>) param[1];
			    	 if(!atStatusLsit.isEmpty())
			    	 {
				    	 parseStatus(atStatusLsit,atPage);
				    	 weiboListAdapter=new WeiboListAdapter(MSGActivity.this, atStatusLsit, containList, highlightList, emotionDataList, R.layout.home_list_item);
					     atListView.setAdapter(weiboListAdapter);
					     atListView.setVisibility(View.VISIBLE);
					     int totalAtNum =(Integer) param[2];
					     if(totalAtNum>0)
					        totalAtPage=totalAtNum%20==0?totalAtNum/20:totalAtNum/20+1;
			    	 }
		    	 }
		    	 progressDialog.dismiss();
			     break;
		    case TaskID.REFRESH_MENTION_STATUS:
		    	 String updateTime="�������:" +new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.CHINA).format(new Date()).substring(5, 16);
		    	 atListView.onRefreshComplete(updateTime);
		    	 if(param[1]!=null)
		    	 {
		    	    atStatusLsit=(List<Status>) param[1];
		    	    if(!atStatusLsit.isEmpty())
		    	    {
					 parseStatus(atStatusLsit,atPage);
					 weiboListAdapter=new WeiboListAdapter(this, atStatusLsit,containList,highlightList,emotionDataList,R.layout.home_list_item);
					 atListView.setAdapter(weiboListAdapter);
		    	    }
		    	 }
		    	 break;
		    case TaskID.GET_MORE_COMMENTWEIBO:
		    	 if(param[1]!=null)
				 {
					 List<Status> moreStatusList=(List<Status>) param[1];
					 if(moreStatusList==null||moreStatusList.isEmpty())
					 {
						 weiboListAdapter.noMore();
					 }
					 else
					 {
					  for(Status status : moreStatusList)
						  atStatusLsit.add(status);
					  parseStatus(moreStatusList,atPage);
					  weiboListAdapter.updateData(atStatusLsit,containList,highlightList,emotionDataList);
					  moreAtItemClicked=false;
					 }
				 }
		    	 break;
		    case TaskID.GET_COMMENTS_TOME:
		    	 if(param[1]!=null)
		    	 {
		    		 commentList=(List<Comment>) param[1];
			    	 if(!commentList.isEmpty())
			    	 {
				    	 parseComment(commentList, commentPage);
				    	 commentAdapter=new CommentAdapter(MSGActivity.this, commentList, highLightMap, hasEmotionMap, emotionDataMap, R.layout.weibo_detail_comment_item);
				    	 commentAdapter.setHandler(handler);
				    	 commentListView.setAdapter(commentAdapter);
						 commentListView.setVisibility(View.VISIBLE);
				    	 int totalComNum =(Integer) param[2];
					     if(totalComNum>0)
					        totalCommentPage=totalComNum%20==0?totalComNum/20:totalComNum/20+1;
			    	 }
		    	 }
		    	 progressDialog.dismiss();
		    	 break;
		    case TaskID.GET_MORE_COMMENT_TOME:
		    	 if(param[1]!=null)
			     {
					 List<Comment> moreCommentList=(List<Comment>) param[1];
					 if(moreCommentList==null||moreCommentList.isEmpty())
					 {
						commentAdapter.noMore();
					 }
					 else
					 {
					  for(Comment comment : moreCommentList)
						  commentList.add(comment);
					  parseComment(moreCommentList,commentPage);
					  commentAdapter.updateData(commentList, highLightMap,hasEmotionMap,emotionDataMap);
					  moreCommentClicked=false;
					 }
				 }
		    	 break;
		    case TaskID.CREATE_FAVORITES_INMSG:
		    	 boolean success=(Boolean) param[1];
				 Toast.makeText(this, success?"�ղسɹ���":"�ղ�ʧ�ܣ�", Toast.LENGTH_SHORT).show();
		    	 break;
		}
	}
	private class WeiboRefreshListener implements OnRefreshListener//��������ˢ��
	{
		@Override
		public void onRefresh()
		{
			 atPage=1;
			 Map<String, Object> taskParams=new HashMap<String, Object>();
			 taskParams.put("Paging", new Paging(atPage, 20));
			 MainService.addTask(new Task(TaskID.REFRESH_MENTION_STATUS, taskParams));
		}
	}
	private class WeiboClickListener implements OnItemClickListener//����΢������¼�
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			if(id==-1&&!moreAtItemClicked)//��ȡ����΢��
			{
				atPage++;
				if(atPage<=totalAtPage)
				{
					view.findViewById(R.id.moreText).setVisibility(View.GONE);
					view.findViewById(R.id.more_weibo_layout).setVisibility(View.VISIBLE);
					Map<String, Object> taskParams =new HashMap<String, Object>();
					taskParams.put("Paging", new Paging(atPage, 20));
					MainService.addTask(new Task(TaskID.GET_MORE_COMMENTWEIBO, taskParams));
				}
				else
				{
					weiboListAdapter.noMore();
				}
				moreAtItemClicked=true;
			}
			else
			{
			   Intent intent=new Intent(MSGActivity.this, WeiboInfoActivity.class);
			   intent.putExtra("position", position-1);
			   intent.putExtra("WeiboID",id+"");
			   intent.putExtra("StartCode", 3);
			   startActivity(intent);
			}
		}
	}
	class CommentClickListener implements OnItemClickListener
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			if(id==-1&&!moreCommentClicked)//��ȡ����
			{
				commentPage++;
				if(commentPage<=totalCommentPage)
				{
					view.findViewById(R.id.moreText2).setVisibility(View.GONE);
					view.findViewById(R.id.more_weibo_layout2).setVisibility(View.VISIBLE);
					Map<String, Object> taskParams =new HashMap<String, Object>();
					taskParams.put("Paging", new Paging(commentPage, 20));
					MainService.addTask(new Task(TaskID.GET_MORE_COMMENT_TOME, taskParams));
				}
				else
				{
					commentAdapter.noMore();
				}
				moreCommentClicked=true;
			}
			else
			{
			   Status comStatus=commentList.get(position).getStatus();
			   if(comStatus!=null)
			   {
				   Intent intent=new Intent(MSGActivity.this, NewWeiboActivity.class);
				   intent.putExtra("Type", "�ظ�����");
				   intent.putExtra("CommentID", id+"");
				   intent.putExtra("WeiboID", comStatus.getId()+"");
				   startActivity(intent);
			   }
			   else
				   Toast.makeText(MSGActivity.this, "������ˣ�", Toast.LENGTH_SHORT).show();
			}
		}
	}
	private Handler handler=new Handler()
	{
		@Override
		public void handleMessage(Message msg)
		{
			commentUser=(User) msg.obj;
			Intent intent=new Intent(MSGActivity.this,UserInfoActivity.class);
			intent.putExtra("UID", commentUser.getId());
			intent.putExtra("flg", "fromMSG");
			startActivity(intent);
		}
	};
	public void parseStatus(List<Status> statusList,int page)//����΢��
	{
		 int i=0;
		 if(page>1)i=(page-1)*20;//page:1[0-19] page:2[20-39] page:3[40-59] page:4[60-79] page:5[80-99].......		   
		 containList.clear();
		 highlightList.clear();
		 emotionDataList.clear();
		 Map<Integer,Boolean> contentPicMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subcontentMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subcontentPicMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> emotionMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subemotionMap=new HashMap<Integer,Boolean>();
		 Map<Integer,SpannableString> highlightMap=new HashMap<Integer, SpannableString>();
		 Map<Integer,SpannableString> subhighlightMap=new HashMap<Integer, SpannableString>();
		 Map<Integer,List<HashMap<String,String>>> emotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
		 Map<Integer,List<HashMap<String,String>>> subemotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
		 if(statusList!=null&&!statusList.isEmpty())
		 for (Status status : statusList)
		 {
			String contentPicUrl=status.getBmiddlePic();
			String statusText=status.getText();
			if(contentPicUrl!=null&&!contentPicUrl.equals(""))//΢���������Ƿ���ͼƬ
			   contentPicMap.put(i, true);
			else
			   contentPicMap.put(i, false);
			highlightMap.put(i, new WeiboParseUtil(statusText).getHighLight());//΢�����ĸ�������
			if(EmotionUtil.hasEmotion(statusText))//΢���������Ƿ��б���
			{
				emotionMap.put(i, true);
				emotionDataMap.put(i,EmotionUtil.getEmotionData());
			}
			else
				emotionMap.put(i, false);
			if(status.getRetweetedStatus()!=null)//�Ƿ���ת������
			{
				subcontentMap.put(i, true);
				String subContentPicUrl=status.getRetweetedStatus().getBmiddlePic();
				String subStatusText=status.getRetweetedStatus().getText();
				if(subContentPicUrl!=null&&!subContentPicUrl.equals(""))//ת���������Ƿ���ͼƬ
				   subcontentPicMap.put(i, true);
				else
				   subcontentPicMap.put(i, false);
				subhighlightMap.put(i, new WeiboParseUtil(subStatusText).getHighLight());//ת�����ݸ�������
				if(EmotionUtil.hasEmotion(subStatusText))//ת���������Ƿ��б���
				{
					subemotionMap.put(i, true);
					subemotionDataMap.put(i, EmotionUtil.getEmotionData());
				}
				else
					subemotionMap.put(i, false);
			}
			else
				subcontentMap.put(i, false);
			containList.add(contentPicMap);
			containList.add(subcontentMap);
			containList.add(subcontentPicMap);
			containList.add(emotionMap);
			containList.add(subemotionMap);
			highlightList.add(highlightMap);
			highlightList.add(subhighlightMap);
			emotionDataList.add(emotionDataMap);
			emotionDataList.add(subemotionDataMap);
			i++;
		 }
	}
	private void parseComment(List<Comment> commentList, int page)
	{
		int i=0;
		if(page>1)i=(page-1)*20;
		highLightMap.clear();
		hasEmotionMap.clear();
		emotionDataMap.clear();
		if(commentList!=null&&!commentList.isEmpty())
		for (Comment comment : commentList)
		{
			String commentText=comment.getText();
			highLightMap.put(i,  new WeiboParseUtil(commentText).getHighLight());
			if(EmotionUtil.hasEmotion(commentText))
			{
				hasEmotionMap.put(i, true);
				emotionDataMap.put(i, EmotionUtil.getEmotionData());
			}
			else
				hasEmotionMap.put(i, false);
			i++;
		}
	}
	public void showProgressDialog(String info)//��ʾ�Զ��������
	{
        View digView = getLayoutInflater().inflate(R.layout.progress_load_translucent, null);
        TextView textView=(TextView) digView.findViewById(R.id.progress_load_text);
        textView.setText(info);
        progressDialog = new Dialog(this, R.style.dialog_style2);
		progressDialog.setContentView(digView);
        progressDialog.show();
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu)//����Menu�˵�
    {
    	menu.add(1, 1, 0, "����").setIcon(R.drawable.setting);
		menu.add(1, 2, 1, "�˺Ź���").setIcon(R.drawable.account);
		menu.add(1, 3, 2, "�ٷ�΢��").setIcon(R.drawable.official);
		menu.add(2, 4, 3, "���").setIcon(R.drawable.comment);
		menu.add(2, 5, 4, "����").setIcon(R.drawable.about);
		menu.add(2, 6, 5, "�˳�").setIcon(R.drawable.exit);
    	return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
    	switch (item.getItemId())
		{
			case 1://����
				  break;
			case 2://�˺Ź���
				  break;
			case 3://�ٷ�΢��
				  break;
			case 4://���
				  break;
			case 5://����
				  break;
			case 6://�˳�
				  SysApplication.getInstance().exitConfirmDialog(this);
				  break;
		}
    	return super.onOptionsItemSelected(item);
    }
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode==KeyEvent.KEYCODE_BACK)
		{
			SysApplication.getInstance().exitConfirmDialog(this);
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
