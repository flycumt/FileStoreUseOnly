package fly.SinaWeibo.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class CheckPhotoActivity extends Activity
{
	private ImageView closeView;
	private ImageView photoView;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.check_photo);
		photoView=(ImageView) findViewById(R.id.photo_imageview);
		if(NewWeiboActivity.bitmapCache!=null)
			photoView.setImageBitmap(NewWeiboActivity.bitmapCache);
		else
			Toast.makeText(this, "error", Toast.LENGTH_LONG).show();
		closeView=(ImageView) findViewById(R.id.close_photoview);
		closeView.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				finish();
			}
		});
	}
}
