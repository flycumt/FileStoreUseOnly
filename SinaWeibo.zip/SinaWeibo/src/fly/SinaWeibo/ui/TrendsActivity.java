package fly.SinaWeibo.ui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import weibo4j.model.Paging;
import weibo4j.model.UserTrend;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import fly.SinaWeibo.adapter.TrendsAdapter;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;
public class TrendsActivity extends Activity implements IWeibo
{
	private int totalPage=1;
	private int nowPage=1;
	private View progressView;
	private TextView title;
	private Button backButton;
	private Button homeButton;
	private List<UserTrend> trendsList;
	private TrendsAdapter trendsAdapter;
	private ListView trendsListView;
	private boolean moreItemClicked=false;
	private String uid;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.trends);
		progressView=findViewById(R.id.progress_trends_load);
		MainService.addActivity(this);
		totalPage=getIntent().getIntExtra("totalPage", 1);
		uid=getIntent().getStringExtra("uid");
	    Map<String, Object> taskParams=new HashMap<String, Object>();
	    taskParams.put("Paging", new Paging(nowPage, 20));
	    taskParams.put("uid", uid);
	    MainService.addTask(new Task(TaskID.GET_USER_TRENDS, taskParams));
		init();
	}
	@Override
	public void init()
	{
		trendsListView=(ListView) findViewById(R.id.trends_listview);
		trendsListView.setOnItemClickListener(new ListItemClickListener());
		backButton=(Button) findViewById(R.id.btn_trends_back);
		homeButton=(Button) findViewById(R.id.btn_trends_home);
		backButton.setOnClickListener(ButtonListener);
		homeButton.setOnClickListener(ButtonListener);
		title=(TextView) findViewById(R.id.txt_trends_title);
		if(!uid.equals(MainService.nowUserId))
		   title.setText("�����б�");
	}

	@SuppressWarnings("unchecked")
	@Override
	public void refresh(Object... param)
	{
		int taskId=(Integer) param[0];
		switch(taskId)
		{
			case TaskID.GET_USER_TRENDS://��û����б�
				 if(nowPage==1)
				 {
				     progressView.setVisibility(View.GONE);
				     if(param[1]!=null)
				        trendsList=(List<UserTrend>) param[1];
				     trendsAdapter=new TrendsAdapter(this, trendsList, R.layout.trends_item);
					 trendsListView.setAdapter(trendsAdapter);
				 }
				 else
				 {
					 if(param[1]!=null)
					 {
						 List<UserTrend> list=(List<UserTrend>) param[1];
						 if(list!=null&&!list.isEmpty())
						 {
							 for (UserTrend userTrend : list)
							 {
								 trendsList.add(userTrend);
							 }
							 trendsAdapter.updateData(trendsList);
						 }
					 }
				 }
				 moreItemClicked=false;
				 break;
		}
	}
	private OnClickListener ButtonListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			switch(v.getId())
			{
				case R.id.btn_trends_back://����
					 MainService.removeActivity(TrendsActivity.this);
					 TrendsActivity.this.finish();
					 break;
				case R.id.btn_trends_home://������ҳ
					 MainService.removeActivityByName("TrendsActivity");
					 MainActivity.homeButton.setChecked(true);
					 startActivity(new Intent(TrendsActivity.this, MainActivity.class));
					 TrendsActivity.this.finish();
					 break;
			}
		}
	};
	class ListItemClickListener implements OnItemClickListener
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			if(id==-1&&!moreItemClicked)//��ȡ����
			{
				nowPage++;
				if(nowPage<=totalPage)
				{
					view.findViewById(R.id.moreText3).setVisibility(View.GONE);
					view.findViewById(R.id.more_friends_layout).setVisibility(View.VISIBLE);
					Map<String, Object> taskParams=new HashMap<String, Object>();
			        taskParams.put("Paging", new Paging(nowPage, 20));
			        taskParams.put("uid", uid);
				    MainService.addTask(new Task(TaskID.GET_USER_TRENDS, taskParams));
				}
				else
				{
					trendsAdapter.noMore();
				}
				moreItemClicked=true;
			}
		}
	}
    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if(event.getAction()==KeyEvent.ACTION_DOWN)
		{
			MainService.removeActivity(TrendsActivity.this);
			finish();
		}
		return super.onKeyDown(keyCode, event);
	}
}
