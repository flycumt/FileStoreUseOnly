package fly.SinaWeibo.ui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import weibo4j.model.Paging;
import weibo4j.model.Status;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import fly.SinaWeibo.adapter.WeiboListAdapter;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;
import fly.SinaWeibo.utils.EmotionUtil;
import fly.SinaWeibo.utils.WeiboParseUtil;
import fly.SinaWeibo.widget.PullToRefreshListView;
import fly.SinaWeibo.widget.PullToRefreshListView.OnRefreshListener;

public class MyWeiboActivity extends Activity implements IWeibo
{
	private Button backButton;
	private Button homeButton;
	private View progressView;
	private TextView title;
	private PullToRefreshListView myWeiboListView;
	private WeiboListAdapter myWeiboAdapter;
	private int totalWeiboPage=1;
	private int nowPage=1;
	public static List<Status> myStatusList;
	private List<Map<Integer,Boolean>> containList;
	private List<Map<Integer,SpannableString>> highlightList;
	private List<Map<Integer,List<HashMap<String, String>>>> emotionDataList;
	private boolean moreItemClicked=false;
	private String uid;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.myweibo);
		MainService.addActivity(this);
		totalWeiboPage=getIntent().getIntExtra("totalWeiboPage", 1);
		uid=getIntent().getStringExtra("uid");
		Map<String, Object> taskParams=new HashMap<String, Object>();
	    taskParams.put("Paging", new Paging(nowPage, 20));
	    taskParams.put("uid", uid);
	    MainService.addTask(new Task(TaskID.GET_MY_WEIBO, taskParams));
		init();
	}
	@Override
	public void init()
	{
		progressView=findViewById(R.id.progress_myweibo_load);
		myWeiboListView=(PullToRefreshListView) findViewById(R.id.myweibo_listview);
		myWeiboListView.setOnItemClickListener(new ListItemClickListener());
		myWeiboListView.setOnRefreshListener(new PullRefreshListener());
		registerForContextMenu(myWeiboListView);//ע�������Ĳ˵�
		backButton=(Button) findViewById(R.id.btn_myweibo_back);
		homeButton=(Button) findViewById(R.id.btn_myweibo_home);
		backButton.setOnClickListener(ButtonListener);
		homeButton.setOnClickListener(ButtonListener);
		containList=new ArrayList<Map<Integer,Boolean>>();
		highlightList=new ArrayList<Map<Integer,SpannableString>>();
		emotionDataList=new ArrayList<Map<Integer,List<HashMap<String,String>>>>();
		new EmotionUtil(this);
		title=(TextView) findViewById(R.id.txt_myweibo_title);
		if(!uid.equals(MainService.nowUserId))
		  title.setText("΢���б�");
	}
	class ListItemClickListener implements OnItemClickListener
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			if(id==-1)//��ȡ����΢��
			{
				if(!moreItemClicked)
				{
					nowPage++;
					if(nowPage<=totalWeiboPage)
					{
						view.findViewById(R.id.moreText).setVisibility(View.GONE);
						view.findViewById(R.id.more_weibo_layout).setVisibility(View.VISIBLE);
						Map<String, Object> taskParams =new HashMap<String, Object>();
						Paging paging=new Paging(nowPage, 20);
						taskParams.put("Paging", paging);
						taskParams.put("uid", uid);
						MainService.addTask(new Task(TaskID.GET_MORE_MYWEIBO, taskParams));
					}
					else
					{
						myWeiboAdapter.noMore();
					}
					moreItemClicked=true;
				}
			}
			else
			{
			   Intent intent=new Intent(MyWeiboActivity.this, WeiboInfoActivity.class);
			   intent.putExtra("position", position-1);
			   intent.putExtra("WeiboID",id+"");
			   intent.putExtra("StartCode", 1);
			   startActivity(intent);
			}
		}
	}
	class PullRefreshListener implements OnRefreshListener
	{
		@Override
		public void onRefresh()
		{
			getRefreshData();
		}
	}
	private OnClickListener ButtonListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			switch(v.getId())
			{
				case R.id.btn_myweibo_back://����
					 MainService.removeActivity(MyWeiboActivity.this);
					 finish();
					 break;
				case R.id.btn_myweibo_home://������ҳ
					 MainService.removeActivityByName("MyWeiboActivity");
					 MainActivity.homeButton.setChecked(true);
					 startActivity(new Intent(MyWeiboActivity.this, MainActivity.class));
					 finish();
					 break;
			}
		}
	};
	@SuppressWarnings("unchecked")
	@Override
	public void refresh(Object... param)
	{
		int taskId=(Integer) param[0];
		switch(taskId)
		{
			case TaskID.GET_MY_WEIBO:
				 if(param[1]!=null)
				 {
				    myStatusList=(List<Status>) param[1];
				    if(!myStatusList.isEmpty())
				    {
					 parseStatus(myStatusList,nowPage);
					 myWeiboAdapter=new WeiboListAdapter(this, myStatusList,containList,highlightList,emotionDataList,R.layout.home_list_item);
					 myWeiboListView.setAdapter(myWeiboAdapter);
					 progressView.setVisibility(View.GONE);
				    }
			     }
				 break;
			case TaskID.REFRESH_MY_WEIBO:
				 String updateTime="�������:" +new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.CHINA).format(new Date()).substring(5, 16);
				 myWeiboListView.onRefreshComplete(updateTime);
				 if(param[1]!=null)
				 {
				    myStatusList=(List<Status>) param[1];
				    if(!myStatusList.isEmpty())
				    {
					 parseStatus(myStatusList,nowPage);
					 myWeiboAdapter=new WeiboListAdapter(this, myStatusList,containList,highlightList,emotionDataList,R.layout.home_list_item);
					 myWeiboListView.setAdapter(myWeiboAdapter);
				    }
				 }
				 break;
			case TaskID.GET_MORE_MYWEIBO:
				 if(param[1]!=null)
				 {
					 List<Status> moreStatusList=(List<Status>) param[1];
					 if(moreStatusList==null||moreStatusList.isEmpty())
					 {
						 myWeiboAdapter.noMore();
					 }
					 else
					 {
					  for(Status status : moreStatusList)
						  myStatusList.add(status);
					  parseStatus(moreStatusList,nowPage);
					  myWeiboAdapter.updateData(myStatusList,containList,highlightList,emotionDataList);
					  moreItemClicked=false;
					 }
				 }
				 break;
			case TaskID.DELETE_MY_WEIBO:
				 boolean success=(Boolean) param[1];
				 Toast.makeText(this, success?"ɾ���ɹ�!��":"ɾ��ʧ�ܣ�", Toast.LENGTH_SHORT).show();
				 if(success)
				    myWeiboAdapter.notifyDataSetChanged();
				 break;
			case TaskID.CREATE_FAVORITES_INUSERWEIBO:
				 Toast.makeText(this, ((Boolean) param[1])?"�ղسɹ���":"�ղ�ʧ�ܣ�", Toast.LENGTH_SHORT).show();
				 break;
		}
	}
	public void parseStatus(List<Status> statusList,int page)//����΢��
	{
		 int i=0;
		 if(page>1)i=(page-1)*20;//page:1[0-19] page:2[20-39] page:3[40-59] page:4[60-79] page:5[80-99].......		   
		 containList.clear();
		 highlightList.clear();
		 emotionDataList.clear();
		 Map<Integer,Boolean> contentPicMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subcontentMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subcontentPicMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> emotionMap=new HashMap<Integer,Boolean>();
		 Map<Integer,Boolean> subemotionMap=new HashMap<Integer,Boolean>();
		 Map<Integer,SpannableString> highlightMap=new HashMap<Integer, SpannableString>();
		 Map<Integer,SpannableString> subhighlightMap=new HashMap<Integer, SpannableString>();
		 Map<Integer,List<HashMap<String,String>>> emotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
		 Map<Integer,List<HashMap<String,String>>> subemotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
		 if(statusList!=null&&!statusList.isEmpty())
		 for (Status status : statusList)
		 {
			String contentPicUrl=status.getBmiddlePic();
			String statusText=status.getText();
			if(contentPicUrl!=null&&!contentPicUrl.equals(""))//΢���������Ƿ���ͼƬ
			   contentPicMap.put(i, true);
			else
			   contentPicMap.put(i, false);
			highlightMap.put(i, new WeiboParseUtil(statusText).getHighLight());//΢�����ĸ�������
			if(EmotionUtil.hasEmotion(statusText))//΢���������Ƿ��б���
			{
				emotionMap.put(i, true);
				emotionDataMap.put(i,EmotionUtil.getEmotionData());
			}
			else
				emotionMap.put(i, false);
			if(status.getRetweetedStatus()!=null)//�Ƿ���ת������
			{
				subcontentMap.put(i, true);
				String subContentPicUrl=status.getRetweetedStatus().getBmiddlePic();
				String subStatusText=status.getRetweetedStatus().getText();
				if(subContentPicUrl!=null&&!subContentPicUrl.equals(""))//ת���������Ƿ���ͼƬ
				   subcontentPicMap.put(i, true);
				else
				   subcontentPicMap.put(i, false);
				subhighlightMap.put(i, new WeiboParseUtil(subStatusText).getHighLight());//ת�����ݸ�������
				if(EmotionUtil.hasEmotion(subStatusText))//ת���������Ƿ��б���
				{
					subemotionMap.put(i, true);
					subemotionDataMap.put(i, EmotionUtil.getEmotionData());
				}
				else
					subemotionMap.put(i, false);
			}
			else
				subcontentMap.put(i, false);
			containList.add(contentPicMap);
			containList.add(subcontentMap);
			containList.add(subcontentPicMap);
			containList.add(emotionMap);
			containList.add(subemotionMap);
			highlightList.add(highlightMap);
			highlightList.add(subhighlightMap);
			emotionDataList.add(emotionDataMap);
			emotionDataList.add(subemotionDataMap);
			i++;
		 }
	}

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo)//���������Ĳ˵�
    {
    	super.onCreateContextMenu(menu, v, menuInfo);
    	AdapterContextMenuInfo weiboInfo=(AdapterContextMenuInfo)menuInfo;
    	if(weiboInfo.id!=-1)
    	{
	    	menu.setHeaderTitle("����");
	    	if(uid.equals(MainService.nowUserId))//�ҵ�΢��
	    	{
	    		menu.add(1, 1, 1, "  �鿴");
	    	    menu.add(1, 2, 2, "  ɾ��");
	    	}
	    	else//�����û���΢��
	    	{
	    		menu.add(1, 1, 1, "  ת��");
		    	menu.add(1, 2, 2, "  ����");
		    	menu.add(1, 3, 3, "  �ղ�");
		    	menu.add(1, 4, 4, "  �鿴");
	    	}
    	}
    }
    
    @Override
    public boolean onContextItemSelected(MenuItem item)//ѡ�������Ĳ˵�
    {
    	AdapterContextMenuInfo weiboInfo=(AdapterContextMenuInfo)item.getMenuInfo();
    	if(uid.equals(MainService.nowUserId))//�ҵ�΢��
    	{
	    	switch (item.getItemId())
			{
				case 1://�鿴
					  Intent intent=new Intent(MyWeiboActivity.this, WeiboInfoActivity.class);
					  intent.putExtra("position", weiboInfo.position-1);
					  intent.putExtra("WeiboID",weiboInfo.id+"");
					  intent.putExtra("StartCode", 1);
					  startActivity(intent);
					  break;
				case 2://ɾ��
					  Map<String, Object> taskParams=new HashMap<String, Object>();
				      taskParams.put("WeiboID", weiboInfo.id+"");
				      MainService.addTask(new Task(TaskID.DELETE_MY_WEIBO, taskParams));
					  break;
			}
    	}
    	else
    	{
    		Intent intent;
        	switch (item.getItemId())
    		{
    			case 1://ת��
    				   intent=new Intent(this, NewWeiboActivity.class);
    				   intent.putExtra("Type", "ת��");
    				   Status status=myStatusList.get(weiboInfo.position-1);
    				   if(status.getRetweetedStatus()!=null)
    				   {
    					   intent.putExtra("hasSub", true);
    					   intent.putExtra("status", status.getText());
    				   }
    				   else
    					   intent.putExtra("hasSub", false);
    				   intent.putExtra("WeiboID", weiboInfo.id+"");
    				   startActivity(intent);//��������΢������
    				   break;
    			case 2://����
    				   intent=new Intent(this, NewWeiboActivity.class);
    				   intent.putExtra("Type", "����");
    				   intent.putExtra("WeiboID", weiboInfo.id+"");
    				   startActivity(intent);
    				   break;
    			case 3://�ղ�
    				   Map<String, Object> taskParams=new HashMap<String, Object>();
    				   taskParams.put("WeiboID", weiboInfo.id+"");
    				   MainService.addTask(new Task(TaskID.CREATE_FAVORITES_INUSERWEIBO, taskParams));
    				   break;
    			case 4://�鿴
    				   intent=new Intent(this, WeiboInfoActivity.class);
    				   intent.putExtra("position", weiboInfo.position-1);
    				   intent.putExtra("WeiboID", weiboInfo.id+"");
    				   intent.putExtra("StartCode", 1);
    				   startActivity(intent);
    				   break;
    		}
    	}
    	return super.onContextItemSelected(item);
    }
	public void getRefreshData()//��ȡˢ������
	{
		nowPage=1;
		Map<String, Object> taskParams=new HashMap<String, Object>();
	    taskParams.put("Paging", new Paging(nowPage, 20));
	    taskParams.put("uid", uid);
	    MainService.addTask(new Task(TaskID.REFRESH_MY_WEIBO, taskParams));
	}
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
    	if(event.getAction()==KeyEvent.ACTION_DOWN)
    	{
    		MainService.removeActivity(MyWeiboActivity.this);
    		finish();
    	}
    	return super.onKeyDown(keyCode, event);
    }
}
