package fly.SinaWeibo.ui;

import java.util.HashMap;
import java.util.Map;

import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class TopicActivity extends Activity
{
	public static final String SCHEMA = "fly://sina_Topic";
	public static final String PARAM_UID = "uid";
	private static final Uri PROFILE_URI = Uri.parse(SCHEMA);
	private String trend;
	private Button okButton;
	private Button cancelButton;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.topic);
    	extractTrendFromUri();
    	okButton=(Button) findViewById(R.id.attention_topic_yes);
		cancelButton=(Button) findViewById(R.id.attention_topic_no);
		okButton.setOnClickListener(new ButtonListener());
		cancelButton.setOnClickListener(new ButtonListener());
    }
	private void extractTrendFromUri()
	{
		Uri uri = getIntent().getData();
		if (uri != null && PROFILE_URI.getScheme().equals(uri.getScheme()))
		{
			trend = uri.getQueryParameter(PARAM_UID);
		}
	}
	class ButtonListener implements OnClickListener
	{
		@Override
		public void onClick(View v)
		{
			switch(v.getId())
			{
				case R.id.attention_topic_yes:
					 if(trend!=null)
					 {
						  Map<String, Object> taskParams=new HashMap<String, Object>();
						  taskParams.put("trend_name", trend);
						  MainService.addTask(new Task(TaskID.CREATE_FOLLOW_TRENDS, taskParams)); 
					 }
					 else
						 Toast.makeText(TopicActivity.this, "��עʧ�ܣ�", Toast.LENGTH_SHORT).show();
					 finish();
					 break;
				case R.id.attention_topic_no:
					 finish();
					 break;
			}
		}
	}
	
}
