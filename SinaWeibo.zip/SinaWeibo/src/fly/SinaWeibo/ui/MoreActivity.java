package fly.SinaWeibo.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import fly.SinaWeibo.logic.MainService;
import fly.SinaWeibo.service.UserPreference;

public class MoreActivity extends Activity implements IWeibo
{
	private View logOut;
	private UserPreference userPreference;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.more);
		MainService.addActivity(this);
		SysApplication.getInstance().addActivity(this);
		init();
	}
	@Override
	public void init()
	{
		logOut=findViewById(R.id.log_out_view);
		logOut.setOnClickListener(clickListener);
	}
	private OnClickListener clickListener =new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
          switch(v.getId())
		 {
			case R.id.log_out_view:
				 userPreference=new UserPreference(MoreActivity.this);
				 String uAccount=userPreference.getUserAccount(MainService.nowUserId);
				 SharedPreferences preferences = MoreActivity.this.getSharedPreferences(uAccount, Context.MODE_PRIVATE);
				 Editor editor = preferences.edit();
				 editor.putBoolean("isAutoLogin", false);
				 editor.commit();
				 MainService.removeActivityByName("MoreActivity");
				 try
				 {
					for (Activity activity : MainService.activityList)
					{
						if (activity != null)
							activity.finish();//�ر����е�Activity
					}
				 }
				 catch (Exception e)
				 {
					e.printStackTrace();
				 }
				 MainService.activityList.clear();
				 MoreActivity.this.stopService(new Intent("fly.SinaWeibo.logic.MainService"));//�ر�������
				 startActivity(new Intent(MoreActivity.this, LoginActivity.class));
				 finish();
				 break;
		 }			
		}
	};
	@Override
	public void refresh(Object... param)
	{
		
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode==KeyEvent.KEYCODE_BACK)
		{
			SysApplication.getInstance().exitConfirmDialog(this);
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
