package fly.SinaWeibo.ui;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;

/**
 * ��ʾ����΢��OAuth2��Ȩҳ��
 */
public class WebViewActivity extends Activity implements IWeibo
{
	private WebView webView;
	private ProgressDialog progressDialog;
	private static final int LOAD_URL_FINISH = 1;
	private String url;
	private boolean f=true;
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
//		DisplayMetrics dm = new DisplayMetrics();
//		getWindowManager().getDefaultDisplay().getMetrics(dm);
//		System.out.println("w>>>>>>>>>"+dm.widthPixels);
//		System.out.println("h>>>>>>>>>"+dm.heightPixels);
//		if(dm.widthPixels>dm.heightPixels)//�ֻ���Ļ��>��,������ʾ
//		   setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
//		else//�ֻ���Ļ��>��,������ʾ
//		   setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		this.setContentView(R.layout.webview);
		init();
	}
	public void init()
	{
		if (progressDialog == null)
		{
			progressDialog = new ProgressDialog(this);
		}
		progressDialog.setMessage(getString(R.string.loading_auth_url));
		progressDialog.show();//��ʾ���ضԻ���
		webView = (WebView) this.findViewById(R.id.oauth_WebView);
		webView.getSettings().setJavaScriptEnabled(true);//��������ִ��JavaScript
		webView.getSettings().setSupportZoom(true);
		webView.getSettings().setBuiltInZoomControls(true);
//		webView.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN); 
//		webView.getSettings().setUseWideViewPort(true); 
//		webView.getSettings().setLoadWithOverviewMode(true); 
		webView.setInitialScale(100);
//		webView.addJavascriptInterface(new JavascriptInterface(), "Methods");//����Ҫ�󶨵�Javascript�Ķ���
		webView.setWebViewClient(new WebViewClient()
		{
			@Override
			public void onLoadResource(WebView view, String url)
			{
				if(url.equals("https://api.weibo.com/oauth2/authorize"))//�����Ȩ��ť��ʼ��Ȩʱ����ظõ�ַ
				{
					progressDialog.setMessage(getString(R.string.please_wait));
					progressDialog.show();//��ʾ�ȴ��Ի���
				}
				super.onLoadResource(view, url);
			}
			public boolean shouldOverrideUrlLoading(WebView view, String url)//������ĳ��������ʱWebViewClient���������������������Ӧurl������ҳ
			{
				load(url);
				return true;
			}
			public void onPageFinished(WebView view, String url)//ҳ�������ɺ����
			{
				if (url.startsWith("http://api.weibo.com/oauth2/default.html?code="))
				{
//					view.loadUrl("javascript:window.Methods.getPin('<head>'+document.getElementsByTagName('html')[0].innerHTML+'</head>');");
					String AuthorizationCode="";
					String[] split=url.split("=");
					if(split.length==2&&split[1]!=null)
					   AuthorizationCode=split[1];
					Map<String, Object> taskParams=new HashMap<String, Object>();
					taskParams.put("AuthorizationCode", AuthorizationCode);
					Task task = new Task(TaskID.GET_ACCESS_TOKEN, taskParams);
					MainService.addTask(task);
					exitWebView();
				}
				super.onPageFinished(view, url);
			}
		});
		webView.setWebChromeClient(new WebChromeClient()
		{
			public void onProgressChanged(WebView view, int newProgress)//��ǰҳ����ؽ���
			{
				if (newProgress == 100)//ҳ��������
				{
					Message msg=handler.obtainMessage();
					msg.what=LOAD_URL_FINISH;
					handler.sendMessage(msg);//������Ϣ
				}
				super.onProgressChanged(view, newProgress);
			}
		});
		webView.requestFocus();
		MainService.addActivity(this);
	}

	public void load(String url)//����url
	{
		if (null == url || "".equals(url))return;
		new LoadUrlThread(url).start();//���������߳�
	}
	class LoadUrlThread extends Thread//����url�߳���
	{
		String url;
		public LoadUrlThread(String url)
		{
			this.url=url;
		}
		public void run()
		{
			webView.loadUrl(url);
		}
	}
	private Handler handler = new Handler()
	{
		public void handleMessage(android.os.Message msg)
		{
			if (msg.what == LOAD_URL_FINISH)
			{
				progressDialog.dismiss();//ȡ�����ȶԻ���
				if(f)
				{
				   Toast.makeText(WebViewActivity.this, "��ʾ�����ҳ����ʾ������,���������������϶�ҳ����߷Ŵ���Сҳ�档", Toast.LENGTH_LONG).show();
				   f=false;
				}
			}
		};
	};
	
	public void exitWebView()
	{
		try
		{
			Thread.sleep(3000);
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		Intent intent = new Intent(this, LoginActivity.class);
		setResult(1, intent);
		url=null;
		webView=null;
		MainService.removeActivityByName("WebViewActivity");
		finish();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if(keyCode==KeyEvent.KEYCODE_BACK)
		{
			Intent intent = new Intent(this, LoginActivity.class);
			setResult(2, intent);
			url=null;
			webView=null;
			MainService.removeActivityByName("WebViewActivity");
			finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	 @Override
	 public void refresh(Object... params)
	 {
		 progressDialog.setMessage(getString(R.string.loading));
		 url = (String) params[0];
		 load(url);
	 }
}
