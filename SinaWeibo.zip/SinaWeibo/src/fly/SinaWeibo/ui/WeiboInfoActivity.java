package fly.SinaWeibo.ui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import weibo4j.model.Comment;
import weibo4j.model.Paging;
import weibo4j.model.Status;
import weibo4j.model.User;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.text.util.Linkify;
import android.text.util.Linkify.TransformFilter;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import fly.SinaWeibo.adapter.AsyncImageLoader;
import fly.SinaWeibo.adapter.AsyncImageLoader.ImageCallback;
import fly.SinaWeibo.adapter.CommentAdapter;
import fly.SinaWeibo.adapter.RepostAdapter;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;
import fly.SinaWeibo.utils.DateUtil;
import fly.SinaWeibo.utils.EmotionUtil;
import fly.SinaWeibo.utils.WeiboParseUtil;
import fly.SinaWeibo.widget.MyListView;

public class WeiboInfoActivity extends Activity implements IWeibo
{
	private Status status;
	private String weiboID;
	private ImageView headView;
	private ImageView vipView;
	private ImageView picView;
	private ImageView subPicView;
	private ImageView leftItemView;
	private ImageView rightItemView;
	private TextView nameText;
	private TextView weiboText;
	private TextView subText;
	private TextView timeText;
	private TextView sourceText;
	private TextView nothingText;
	private TextView reload;
	private TextView comment;
	private TextView repost;
	private TextView favourite;
	private TextView more;
	private MyListView repostListView;
	private MyListView commentListView;
	private View infoView;
	private View subContentView;
	private Button repostButton;
	private Button commentButton;
	private Button backButton;
	private Button homeButton;
	private Dialog progressDialog;
	private AsyncImageLoader imageLoader;
	private int repostCount=0;
	private int commentCount=0;
	private int repostPage=1;
	private int commentPage=1;
	private int repostTotalPage=1;
	private int commentTotalPage=1;
	private int startCode=0;
	private RepostAdapter repostAdapter;
	private CommentAdapter commentAdapter;
	private List<Status> repostStatusList;
	private List<Comment> commentList;
	private Map<Integer,SpannableString> highLightMap;
	private Map<Integer,Boolean> hasEmotionMap;
	private Map<Integer,List<HashMap<String,String>>> emotionDataMap;
	private boolean moreRepostClicked=false;
	private boolean moreCommentClicked=false;
	private User user;
	public static User chosedUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.weibo_detail);
		MainService.addActivity(this);
		init();
	}
	@Override
	public void init()
	{
	  getStatus();
	  headView=(ImageView) findViewById(R.id.img_profile_preview);
	  vipView=(ImageView) findViewById(R.id.img_profile_vip);
	  picView=(ImageView) findViewById(R.id.weibo_detail_item_content_pic);
	  subPicView=(ImageView) findViewById(R.id.weibo_detail_item_subcontent_pic);
	  leftItemView=(ImageView) findViewById(R.id.bg_item_left_imageView);
	  rightItemView=(ImageView) findViewById(R.id.bg_item_right_imageView);
	  nameText=(TextView) findViewById(R.id.txt_profile_name);
	  weiboText=(TextView) findViewById(R.id.weibo_detail_item_content);
	  subText=(TextView) findViewById(R.id.weibo_detail_item_subcontent);
	  timeText=(TextView) findViewById(R.id.weibo_detail_time_view);
	  sourceText=(TextView) findViewById(R.id.weibo_detail_come_from);
	  reload=(TextView) findViewById(R.id.tvReload);
	  comment=(TextView) findViewById(R.id.tvComment);
	  repost=(TextView) findViewById(R.id.tvForward);
	  favourite=(TextView) findViewById(R.id.tvFav);
	  more=(TextView) findViewById(R.id.tvMore);
	  reload.setOnClickListener(FunctionListener);
	  comment.setOnClickListener(FunctionListener);
	  repost.setOnClickListener(FunctionListener);
	  favourite.setOnClickListener(FunctionListener);
	  more.setOnClickListener(FunctionListener);
	  infoView=findViewById(R.id.ly_profile_info);
	  infoView.setOnClickListener(new InfoListener());
	  subContentView=findViewById(R.id.weibo_detail_item_sublayout);
	  nothingText=(TextView) findViewById(R.id.no_one_text);
	  backButton=(Button) findViewById(R.id.btn_weibo_detail_back);
	  homeButton=(Button) findViewById(R.id.btn_weibo_detail_home);
	  backButton.setOnClickListener(BackListener);
	  homeButton.setOnClickListener(BackListener);
	  repostButton=(Button) findViewById(R.id.btn_weibo_detail_redirect);
	  commentButton=(Button) findViewById(R.id.btn_weibo_detail_comment);
	  repostButton.setOnClickListener(new RepostButtonListener());
	  commentButton.setOnClickListener(new CommentButtonListener());
	  repostListView=(MyListView) findViewById(R.id.weibo_detail_reost_listview);
	  commentListView=(MyListView) findViewById(R.id.weibo_detail_comment_listview);
	  repostListView.setOnItemClickListener(new RepostItemListener());
	  commentListView.setOnItemClickListener(new CommentItemListener());
	  imageLoader = new AsyncImageLoader();
	  user=status.getUser();
	  String imageUrl=user.getAvatarLarge();
	  setDrawable(headView, imageUrl, false);//����ͷ��
	  if(user.getVerified())//��֤
		 vipView.setVisibility(View.VISIBLE);
	  nameText.setText(user.getScreenName());//�����ǳ�
	  weiboText.setText(parseEmotion(status.getText()));//����
	  extractMention2Link(weiboText);
	  String contentPicUrl=status.getBmiddlePic();
	  if(contentPicUrl!=null&&!contentPicUrl.equals(""))//������ͼƬ
	  {
		  picView.setVisibility(View.VISIBLE);
		  picView.setOnTouchListener(new OnPictureTouchListener(status.getOriginalPic()));
		  setDrawable(picView, contentPicUrl, true);
	  }
	  Status repostStatus=status.getRetweetedStatus();
	  if(repostStatus!=null)//��ת������
	  {
		  subContentView.setVisibility(View.VISIBLE);
		  subText.setText(parseEmotion(repostStatus.getText()));//ת������
		  extractMention2Link(subText);
		  String subPicUrl=repostStatus.getBmiddlePic();
		  if(subPicUrl!=null&&!subPicUrl.equals(""))//ת���������ͼƬ
		  {
		     subPicView.setVisibility(View.VISIBLE);
		     subPicView.setOnTouchListener(new OnPictureTouchListener(repostStatus.getOriginalPic()));
			 setDrawable(subPicView, subPicUrl, true);
		  }
	  }
	  timeText.setText(DateUtil.getUpdateTime(status.getCreatedAt()));//ʱ��
	  sourceText.setText("����:"+status.getSource().getName());//��Դ
	  repostCount=status.getRepostsCount();
	  commentCount=status.getCommentsCount();
	  if(repostCount>0)
	  {
		 repostButton.setText("ת��"+repostCount);
		 repostTotalPage=repostCount%20==0?repostCount/20:repostCount/20+1;
	  }
	  if(commentCount>0)
	  {
		 commentButton.setText("����"+commentCount);
		 nothingText.setText("���ڼ���......");
		 commentTotalPage=commentCount%20==0?commentCount/20:commentCount/20+1;
		 Map<String, Object> taskParams=new HashMap<String, Object>();
		 taskParams.put("WeiboID", weiboID);
		 taskParams.put("Paging", new Paging(commentPage, 20));
		 MainService.addTask(new Task(TaskID.GET_WEIBO_COMMENT_LIST, taskParams));
	  }
	  else
	  {
		  commentListView.setVisibility(View.GONE);
		  nothingText.setText("��û��������Ӵ");
	  }
	  highLightMap=new HashMap<Integer, SpannableString>();
	  hasEmotionMap=new HashMap<Integer, Boolean>();
	  emotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
	}
    
	private void getStatus()
	{
	  Intent intent=getIntent();
	  weiboID=intent.getStringExtra("WeiboID");
	  int position=intent.getIntExtra("position", -1);
	  startCode=intent.getIntExtra("StartCode", 0);
	  switch(startCode)
	  {
		case 0:status=HomeActivity.statusList.get(position);
			   break;
		case 1:status=MyWeiboActivity.myStatusList.get(position);
			   break;
		case 2:status=FavouritesActivity.myFavsList.get(position);
			   break;
		case 3:status=MSGActivity.atStatusLsit.get(position);
			   break;
		case 4:status=SearchActivity.weiboList.get(position);
		   	   break;
	  }
	}
	protected void setDrawable(ImageView imageView,String url,boolean pic)
	{
		Drawable drawable;
		if (pic)
			drawable = AsyncImageLoader.getDrawable(url);
		else
			drawable = AsyncImageLoader.getUserHead(url);
		if (drawable == null)
			imageLoader.loadDrawable(url, imageView, true, new imageCallback());
		else
			imageView.setImageDrawable(drawable);
	}
	class RepostButtonListener implements OnClickListener//����ת����ť����ʾת��������
	{
		@Override
		public void onClick(View v)
		{
			if(repostCount>0)
			{
				if(repostAdapter==null)
				{
				 showProgressDialog("���ڼ���......");
				 Map<String, Object> taskParams=new HashMap<String, Object>();
				 taskParams.put("WeiboID", weiboID);
				 taskParams.put("Paging", new Paging(repostPage, 20));
				 MainService.addTask(new Task(TaskID.GET_WEIBO_REPOST_LIST, taskParams));
				}
				else
				{
					commentListView.setVisibility(View.GONE);
					rightItemView.setVisibility(View.GONE);
					leftItemView.setVisibility(View.VISIBLE);
					repostListView.setVisibility(View.VISIBLE);
					nothingText.setText("");
				}
			}
			else
			{
				commentListView.setVisibility(View.GONE);
				repostListView.setVisibility(View.GONE);
				rightItemView.setVisibility(View.GONE);
				leftItemView.setVisibility(View.VISIBLE);
				nothingText.setText("��û����ת��Ӵ");
			}
		}
	}
	class CommentButtonListener implements OnClickListener//�������۰�ť����ʾ��������
	{
		@Override
		public void onClick(View v)
		{
			if(commentCount>0)
			{
				if(commentAdapter==null)
				{
				 showProgressDialog("���ڼ���......");
				 Map<String, Object> taskParams=new HashMap<String, Object>();
				 taskParams.put("WeiboID", weiboID);
				 taskParams.put("Paging", new Paging(commentPage, 20));
				 MainService.addTask(new Task(TaskID.GET_WEIBO_COMMENT_LIST, taskParams));
				}
				else
				{
					repostListView.setVisibility(View.GONE);
					leftItemView.setVisibility(View.GONE);
					rightItemView.setVisibility(View.VISIBLE);
					commentListView.setVisibility(View.VISIBLE);
					nothingText.setText("");
				}
			}
			else
			{
				commentListView.setVisibility(View.GONE);
				repostListView.setVisibility(View.GONE);
				leftItemView.setVisibility(View.GONE);
				rightItemView.setVisibility(View.VISIBLE);
				nothingText.setText("��û��������Ӵ");
			}
		}
	}
	class RepostItemListener implements OnItemClickListener
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			if(id==-1&&!moreRepostClicked)//��ȡ����
			{
				repostPage++;
				if(repostPage<=repostTotalPage)
				{
					view.findViewById(R.id.moreText2).setVisibility(View.GONE);
					view.findViewById(R.id.more_weibo_layout2).setVisibility(View.VISIBLE);
					Map<String, Object> taskParams =new HashMap<String, Object>();
					taskParams.put("WeiboID", weiboID);
					taskParams.put("Paging", new Paging(repostPage, 20));
					MainService.addTask(new Task(TaskID.GET_MORE_REPOST_LIST, taskParams));
				}
				else
				{
					repostAdapter.noMore();
				}
				moreRepostClicked=true;
			}
		}
	}
	class CommentItemListener implements OnItemClickListener
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			if(id==-1&&!moreCommentClicked)//��ȡ����
			{
				commentPage++;
				if(commentPage<=commentTotalPage)
				{
					view.findViewById(R.id.moreText2).setVisibility(View.GONE);
					view.findViewById(R.id.more_weibo_layout2).setVisibility(View.VISIBLE);
					Map<String, Object> taskParams =new HashMap<String, Object>();
					taskParams.put("WeiboID", weiboID);
					taskParams.put("Paging", new Paging(commentPage, 20));
					MainService.addTask(new Task(TaskID.GET_MORE_COMMENT_LIST, taskParams));
				}
				else
				{
					commentAdapter.noMore();
				}
				moreCommentClicked=true;
			}
		}
	}
	private OnClickListener FunctionListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			Intent intent;
			switch(v.getId())
			{
				case R.id.tvReload://ˢ��
					 if(commentListView.getVisibility()==View.VISIBLE)
					 {
						 showProgressDialog("���ڸ���......");
						 commentPage=1;
						 Map<String, Object> taskParams=new HashMap<String, Object>();
						 taskParams.put("WeiboID", weiboID);
						 taskParams.put("Paging", new Paging(commentPage, 20));
						 MainService.addTask(new Task(TaskID.GET_WEIBO_COMMENT_LIST, taskParams));
					 }
					 else if(repostListView.getVisibility()==View.VISIBLE)
					 {
						 showProgressDialog("���ڸ���......");
						 repostPage=1;
						 Map<String, Object> taskParams=new HashMap<String, Object>();
						 taskParams.put("WeiboID", weiboID);
						 taskParams.put("Paging", new Paging(repostPage, 20));
						 MainService.addTask(new Task(TaskID.GET_WEIBO_REPOST_LIST, taskParams));
					 }
					 break;
				case R.id.tvComment://����
					 intent=new Intent(WeiboInfoActivity.this, NewWeiboActivity.class);
				     intent.putExtra("Type", "����");
				     intent.putExtra("WeiboID", weiboID+"");
				     startActivity(intent);
					 break;
				case R.id.tvForward://ת��
				     intent=new Intent(WeiboInfoActivity.this, NewWeiboActivity.class);
				     intent.putExtra("Type", "ת��");
				     if(status.getRetweetedStatus()!=null)
				     {
					   intent.putExtra("hasSub", true);
					   intent.putExtra("status", status.getText());
				     }
				     else
					   intent.putExtra("hasSub", false);
				     intent.putExtra("WeiboID", weiboID+"");
				     startActivity(intent);//��������΢������
					 break;
				case R.id.tvFav://�ղ�
					 Map<String, Object> taskParams=new HashMap<String, Object>();
				     taskParams.put("WeiboID", weiboID+"");
				     MainService.addTask(new Task(TaskID.CREATE_FAVORITES_INDETAIL, taskParams));
					 break;
				case R.id.tvMore://����
					 showMoreDialog();
					 break;
			}
		}
	}; 
	private OnClickListener BackListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			switch(v.getId())
			{
				case R.id.btn_weibo_detail_back:
					 MainService.removeActivity(WeiboInfoActivity.this);
					 finish();
					 break;
				case R.id.btn_weibo_detail_home:
					 MainService.removeActivity(WeiboInfoActivity.this);
					 switch(startCode)
					 {
						case 0:
							  finish();
							  break;
						case 1:
							  MainService.removeActivityByName("MyWeiboActivity");
							  MainActivity.homeButton.setChecked(true);
							  startActivity(new Intent(WeiboInfoActivity.this, MainActivity.class));
							  finish();
							  break;
						case 2:
							  MainService.getActivityByName("FavouritesActivity").finish();
							  MainService.removeActivityByName("FavouritesActivity");
							  MainActivity.homeButton.setChecked(true);
							  finish();
							  break;
						case 3:
						case 4:
							  finish();
							  MainActivity.homeButton.setChecked(true);
							  break;
					 }
					 break;
			}
		}
	}; 
	 class OnPictureTouchListener implements OnTouchListener
    {
    	private String url;
		public OnPictureTouchListener(String url)
		{
			this.url = url;
		}
		@Override
		public boolean onTouch(View v, MotionEvent event)
		{
			if(MotionEvent.ACTION_DOWN==event.getAction())
			{
				Intent intent=new Intent(WeiboInfoActivity.this,ImageActivity.class);
				intent.putExtra("Url", url);
				startActivity(intent);
			}
			return true;
		}
    }
	 class InfoListener implements OnClickListener
	 {
		@Override
		public void onClick(View arg0)
		{
			chosedUser=user;
			Intent intent=new Intent(WeiboInfoActivity.this,UserInfoActivity.class);
			intent.putExtra("UID", user.getId());
			intent.putExtra("flg", "fromWeiboInfo");
			startActivity(intent);
		}
	 }
	@SuppressWarnings("unchecked")
	@Override
	public void refresh(Object... param)
	{
	     int taskID=(Integer) param[0];
	     switch(taskID)
		 {
			case TaskID.GET_WEIBO_REPOST_LIST:
				 if(param[1]!=null)
				    repostStatusList=(List<Status>) param[1];
				 parseStatus(repostStatusList, repostPage);
				 repostAdapter=new RepostAdapter(this, repostStatusList, highLightMap,hasEmotionMap,emotionDataMap,R.layout.weibo_detail_repost_item);
				 repostAdapter.setHandler(handler);
				 repostListView.setAdapter(repostAdapter);
				 if(progressDialog!=null)
				   if(progressDialog.isShowing())
				      progressDialog.dismiss();
				 commentListView.setVisibility(View.GONE);
				 rightItemView.setVisibility(View.GONE);
				 leftItemView.setVisibility(View.VISIBLE);
				 repostListView.setVisibility(View.VISIBLE);
				 nothingText.setText("");
				 break;
			case TaskID.GET_MORE_REPOST_LIST:
				 if(param[1]!=null)
				 {
					 List<Status> moreRepostList=(List<Status>) param[1];
					 if(moreRepostList==null||moreRepostList.isEmpty())
					 {
						repostAdapter.noMore();
					 }
					 else
					 {
					  for(Status status : moreRepostList)
						  repostStatusList.add(status);
					  parseStatus(moreRepostList,repostPage);
					  repostAdapter.updateData(repostStatusList, highLightMap,hasEmotionMap,emotionDataMap);
					  moreRepostClicked=false;
					 }
				 }
				 break;
			case TaskID.GET_WEIBO_COMMENT_LIST:
				 if(param[1]!=null)
				 {
					 commentList=(List<Comment>) param[1];
					 parseComment(commentList, commentPage);
					 commentAdapter=new CommentAdapter(this,commentList, highLightMap,hasEmotionMap,emotionDataMap,R.layout.weibo_detail_comment_item);
					 commentAdapter.setHandler(handler);
					 commentListView.setAdapter(commentAdapter);
					 if(progressDialog!=null)
						 if(progressDialog.isShowing())
						    progressDialog.dismiss();
					 nothingText.setText("");
				 }
				 break;
			 case TaskID.GET_MORE_COMMENT_LIST:
			      if(param[1]!=null)
			      {
					 List<Comment> moreCommentList=(List<Comment>) param[1];
					 if(moreCommentList==null||moreCommentList.isEmpty())
					 {
						commentAdapter.noMore();
					 }
					 else
					 {
					  for(Comment comment : moreCommentList)
						  commentList.add(comment);
					  parseComment(moreCommentList,commentPage);
					  commentAdapter.updateData(commentList, highLightMap,hasEmotionMap,emotionDataMap);
					  moreCommentClicked=false;
					 }
				  }
				  break;
			 case TaskID.CREATE_FAVORITES_INDETAIL:
				  boolean success=(Boolean) param[1];
				  Toast.makeText(this, success?"�ղسɹ���":"�ղ�ʧ�ܣ�", Toast.LENGTH_SHORT).show();
				  break;
			 case TaskID.CREATE_FOLLOW_TRENDS:
				  boolean ok=(Boolean) param[1];
				  Toast.makeText(this, ok?"��ע�ɹ���":"��עʧ�ܣ�", Toast.LENGTH_SHORT).show();
				  break;
		}
	}
	private Handler handler=new Handler()
	{
		@Override
		public void handleMessage(Message msg)
		{
			chosedUser=(User) msg.obj;
			Intent intent=new Intent(WeiboInfoActivity.this,UserInfoActivity.class);
			intent.putExtra("UID", chosedUser.getId());
			intent.putExtra("flg", "fromWeiboInfo");
			startActivity(intent);
		}
	};
	public void showMoreDialog()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this); 
		builder.setTitle("����"); 
		final CharSequence[] items = {"����","�ٱ�"};
		builder.setItems(items, new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int item)
			{
				switch (item)
				{
					case 0://����
						   //δ�ҵ���Ӧ�ӿ�......
						   break;
					case 1://�ٱ�
						  //δ�ҵ���Ӧ�ӿ�......
						   break;
				}
			}
		}); 
		builder.create().show();
	}
	protected void parseStatus(List<Status> statusList,int page)
	{
		int i=0;
		if(page>1)i=(page-1)*20;
		highLightMap.clear();
		hasEmotionMap.clear();
		emotionDataMap.clear();
		if(statusList!=null&&!statusList.isEmpty())
		for (Status status : statusList)
		{
			String statusText=status.getText();
			highLightMap.put(i,  new WeiboParseUtil(statusText).getHighLight());
			if(EmotionUtil.hasEmotion(statusText))
			{
				hasEmotionMap.put(i, true);
				emotionDataMap.put(i, EmotionUtil.getEmotionData());
			}
			else
				hasEmotionMap.put(i, false);
			i++;
		}
	}
	private void parseComment(List<Comment> commentList, int page)
	{
		int i=0;
		if(page>1)i=(page-1)*20;
		highLightMap.clear();
		hasEmotionMap.clear();
		emotionDataMap.clear();
		if(commentList!=null&&!commentList.isEmpty())
		for (Comment comment : commentList)
		{
			String commentText=comment.getText();
			highLightMap.put(i,  new WeiboParseUtil(commentText).getHighLight());
			if(EmotionUtil.hasEmotion(commentText))
			{
				hasEmotionMap.put(i, true);
				emotionDataMap.put(i, EmotionUtil.getEmotionData());
			}
			else
				hasEmotionMap.put(i, false);
			i++;
		}
	}
	private SpannableString parseEmotion(String text)
	{
		List<HashMap<String, String>> list;
		SpannableString spannableString=new SpannableString(text);
		int id=0;
		if(EmotionUtil.hasEmotion(text))
		{
			list=EmotionUtil.getEmotionData();
			if(list!=null&&!list.isEmpty())
			for (HashMap<String, String> map : list)
			{
				String idStr=map.get(EmotionUtil.ID);
				if(idStr.equals("")||idStr.equals("0"))
					id=0;
				else
				    id=Integer.parseInt(idStr);
				if(id!=0)
				{
					Drawable drawable = getResources().getDrawable(id);
					if(drawable!=null)
					{
						drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
						ImageSpan imgSpan = new ImageSpan(drawable);
						spannableString.setSpan(imgSpan, Integer.parseInt(map.get(EmotionUtil.START)), Integer.parseInt(map.get(EmotionUtil.END)), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					}
				}
			}
		}
		return spannableString;
	}
	public void showProgressDialog(String info)//��ʾ�Զ��������
	{
        View digView = getLayoutInflater().inflate(R.layout.progress_load_translucent, null);
        TextView textView=(TextView) digView.findViewById(R.id.progress_load_text);
        textView.setText(info);
        progressDialog = new Dialog(this, R.style.dialog_style2);
		progressDialog.setContentView(digView);
        progressDialog.show();
	}
	class imageCallback implements ImageCallback
	{
		@Override
		public void imageLoaded(ImageView imageView, Drawable imageDrawable)
		{
		  if(imageDrawable!=null)
		   {
			 imageView.setImageDrawable(imageDrawable);
		   }
		}
	}
	public static void extractMention2Link(TextView textView)
	{
		textView.setAutoLinkMask(0);
		Pattern unamePattern = Pattern.compile("@([0-9a-zA-Z\u4e00-\u9fa5_-]+)");
		Pattern trendPattern= Pattern.compile("#(\\w+?)#");
		String unameScheme = String.format("%s/?%s=", UserInfoActivity.SCHEMA, UserInfoActivity.PARAM_UID);
		String trendScheme = String.format("%s/?%s=", TopicActivity.SCHEMA,TopicActivity.PARAM_UID);
		Linkify.addLinks(textView, unamePattern, unameScheme, null, new TransformFilter()
		{
			@Override
			public String transformUrl(Matcher match,String url)
			{
				return match.group(1);
			}
		});
		Linkify.addLinks(textView, trendPattern, trendScheme, null, new TransformFilter()
		{
			@Override
			public String transformUrl(Matcher match, String url)
			{
				return match.group(1); 
			}
		});
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode==KeyEvent.KEYCODE_BACK)
		{
			 MainService.removeActivity(WeiboInfoActivity.this);
			 finish();
			 return false;
		}
		return super.onKeyDown(keyCode, event);
	}
}
