package fly.SinaWeibo.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;

public class WelcomeActivity extends Activity
{
	private ImageView welcomeView;
	private AlphaAnimationListener alphaAnimationListener;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);//�ޱ���
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);//ȫ��
		setContentView(R.layout.welcome);
		welcomeView = (ImageView) findViewById(R.id.welcomeImageView);
		AlphaAnimation alpha = new AlphaAnimation(1.0f,0.7f);
		alpha.setDuration(3000);
		alpha.setFillAfter(true);
		welcomeView.startAnimation(alpha);
		alphaAnimationListener = new AlphaAnimationListener();
		alpha.setAnimationListener(alphaAnimationListener);
	}

	class AlphaAnimationListener implements AnimationListener
	{
		@Override
		public void onAnimationEnd(Animation animation)
		{
			startActivity(new Intent(WelcomeActivity.this, LoginActivity.class));
			finish();
		}
		@Override
		public void onAnimationRepeat(Animation animation){}
		@Override
		public void onAnimationStart(Animation animation){}
	}
}
