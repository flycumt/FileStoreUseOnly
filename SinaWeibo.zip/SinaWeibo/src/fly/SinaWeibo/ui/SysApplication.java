package fly.SinaWeibo.ui;

import java.util.LinkedList;
import java.util.List;

import fly.SinaWeibo.logic.MainService;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;

public class SysApplication extends Application
{
	private List<Activity> activityList = new LinkedList<Activity>();
	private static SysApplication instance;
	
	private SysApplication()
	{
	}
	
	public synchronized static SysApplication getInstance()
	{
		if (null == instance)
		{
			instance = new SysApplication();
		}
		return instance;
	}

	public void addActivity(Activity activity)
	{
		activityList.add(activity);
	}
	/**
	 * �˳�����Ӧ��
	 * @param con
	 */
	public void exitApp(Context context)
	{
		MainService.activityList.clear();
		context.stopService(new Intent("fly.SinaWeibo.logic.MainService"));//�ر�������
		try
		{
			for (Activity activity : activityList)
			{
				if (activity != null)
					activity.finish();//�ر����е�Activity
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			ActivityManager manager = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
			manager.killBackgroundProcesses("fly.SinaWeibo.ui");
			android.os.Process.killProcess(android.os.Process.myPid());
			System.exit(0);
		}
	}
	/**
	 * ȷ���˳��Ի���
	 * @param con
	 */
	public  void exitConfirmDialog(final Context context)
	{
		LayoutInflater inflater = LayoutInflater.from(context);
		View exitView = inflater.inflate(R.layout.exitdialog, null);
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setView(exitView);// �趨�Ի�����ʾ��View����
		builder.setPositiveButton(R.string.exit, new OnClickListener()
		{
			public void onClick(DialogInterface arg0, int arg1)
			{
				exitApp(context);
			}
		});
		builder.setNegativeButton(R.string.cancel, null);
		AlertDialog alertDialog=builder.create();
		alertDialog.show();// ��ʾ�Ի���
	}
	
	@Override
	public void onLowMemory()
	{
		super.onLowMemory();
		System.gc();
	}
}
