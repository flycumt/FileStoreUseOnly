package fly.SinaWeibo.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import weibo4j.http.AccessToken;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.text.style.URLSpan;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import fly.SinaWeibo.adapter.PopMenuAdapter;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.bean.UserInfo;
import fly.SinaWeibo.logic.MainService;
import fly.SinaWeibo.service.UserDBService;
import fly.SinaWeibo.service.UserPreference;
import fly.SinaWeibo.utils.GetIconUtil;
import fly.SinaWeibo.utils.NetUtil;
import fly.SinaWeibo.utils.WebViewDBUtil;

public class LoginActivity extends Activity implements IWeibo
{
    private Button loginButton;
    private ImageButton okButton;
    private ImageButton popButton;
    private Dialog Authdialog;
    private ProgressDialog progressDialog;
    private AlertDialog alertDialog;
    private EditText userAccountText;
    private TextView registerText;
    private ImageView userHead;
    private CheckBox autoLogin;
    private CheckBox rememberMe;
    private String userAccount;
    private String lastUser;
    private boolean login=false;
    private boolean isConnected=false;
    private boolean isRememberMe=false;
    private boolean isAuthrized=false;
    private boolean isAutoLogin=false;
    private static final int REQUEST_ACCESSTOKEN_CODE=1;
    private UserDBService userService;
    private UserPreference userPreference;
    private AccessToken accessToken;
    private UserInfo user;
    private Map<String, Object> userSetting;
    private List<Map<String, Object>> userlist;
    private PopupWindow popupWindow;
    private PopMenuAdapter popMenuAdapter;
    
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);// �ޱ���
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);// ȫ��
		setContentView(R.layout.login);
		init();
	}
	@Override
	public void init()
	{
		Intent service=new Intent(this, MainService.class);
		startService(service);//����MainService����
		MainService.addActivity(this);//���ӵ�Activity��������
		SysApplication.getInstance().addActivity(this);
		userService = new UserDBService(this);
		userPreference=new UserPreference(this);
		loginButton = (Button) findViewById(R.id.loginButton);
		loginButton.setOnClickListener(new LoginListener());
		popButton=(ImageButton) findViewById(R.id.popButton);
		popButton.setOnClickListener(new PopMenuListener());
		registerText = (TextView) findViewById(R.id.register);
		userAccountText =(EditText) findViewById(R.id.count);
		userHead=(ImageView) findViewById(R.id.user_head);
		rememberMe=(CheckBox) findViewById(R.id.rememberme);
		autoLogin=(CheckBox) findViewById(R.id.autologin);
		rememberMe.setOnCheckedChangeListener(CheckBoxChangedListeber);
		autoLogin.setOnCheckedChangeListener(CheckBoxChangedListeber);
		progressDialog=new ProgressDialog(this);
		String register = getString(R.string.register);
		registerText.setText(setSpannableString(register));//���ø�����ʾ"ע��"�������ı� 
		registerText.setMovementMethod(LinkMovementMethod.getInstance());
		checkConnection();//�����������
		lastUser=userPreference.getLastUser();
		if(!"".equals(lastUser)&&lastUser!=null)
		{
			userSetting=userPreference.getPreferences(lastUser);//��ȡ�ϴε�¼����
			if((Boolean)userSetting.get("isRememberMe"))
			{
				userAccountText.setText(lastUser);
				rememberMe.setChecked(true);
				String userIconSDPath=userPreference.getUserIconSDPath((String)userSetting.get("userId"));
				if(userIconSDPath!=null)
				{
					Drawable drawable=GetIconUtil.getDrawImageFromSD(userIconSDPath);
				    if(drawable!=null)
				       userHead.setImageDrawable(drawable);
				    else
				       userHead.setImageDrawable(getResources().getDrawable(R.drawable.user_default_head));
				}
				else
				{
					userHead.setImageDrawable(getResources().getDrawable(R.drawable.user_default_head));
				}
			}
			else
				userHead.setImageDrawable(getResources().getDrawable(R.drawable.user_default_head));
		}
		autoLogin();//�Ƿ��Զ���¼
	}
	
	@Override
	protected void onResume()
	{
		checkConnection();//�ٴη��ص�½����ʱ�����������
		if(!login)
		   autoLogin();
		super.onResume();
	}
	
	/**
	 * �����������ı�
	 * @param register
	 * @return SpannableString
	 */
	public SpannableString setSpannableString(String register)
    {
        String registerURL = getString(R.string.registerURL);
        URLSpan urlSpan=new URLSpan(registerURL);
        int start=register.indexOf("ע��");
        int end=start+2;
        SpannableString sp = new SpannableString(register);//����һ�� SpannableString����
        sp.setSpan(urlSpan, start,end,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//���ó����� 
        sp.setSpan(new ForegroundColorSpan(Color.YELLOW),start,end,Spannable.SPAN_EXCLUSIVE_INCLUSIVE);//������ɫ
        return sp;
    }
	
	/**
	 * �����û������þ����Ƿ��Զ���¼
	 */
	public void autoLogin()
	{
		if(isConnected)//������������
		{
			if(!"".equals(lastUser)&&lastUser!=null)
			{
				if((Boolean) userSetting.get("isAutoLogin")&&(Boolean) userSetting.get("isAuthrized"))//�û���Ȩ�������ϴ�ѡ�����Զ���¼
				{
					autoLogin.setChecked(true);
					String userId=(String)userSetting.get("userId");
					String userExpireIn=userService.getUserExpireInById(userId);//ȡ���û�AccessToken����Ч��
					long authrizedTime=Long.parseLong(userPreference.getUserAuthrizedTime(userId))/1000;//ȡ����Ȩʱ��ʱ��
					long currentTime=System.currentTimeMillis()/1000;//ȡ�õ�ǰʱ��
					int time=(int)(currentTime-authrizedTime);
					if(time<Integer.parseInt(userExpireIn))//���AccessTokenδ����
					{
						MainService.nowUserId=(String)userSetting.get("userId");
						startActivity(new Intent(this, MainActivity.class));//������ҳ�� 
						Toast.makeText(this, R.string.login_success, Toast.LENGTH_SHORT).show();
						MainService.removeActivityByName("LoginActivity");
					    finish();
					}
				}
			}
		}
		else //���������쳣
		{
			showNetErrorDialog(this); // ���������쳣�Ի���
		}
	}
	
	/**
	 * ��ʾ�������Ӵ���Ի���
	 * @param context
	 */
	private void showNetErrorDialog(final Context context)
	{
		AlertDialog.Builder builder=new AlertDialog.Builder(context);
		builder.setTitle(R.string.NetConnectError);
		builder.setMessage(R.string.CanNotConnect);
		builder.setNegativeButton(R.string.exit, new DialogInterface.OnClickListener()
		{			
			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				dialog.cancel();
				SysApplication.getInstance().exitConfirmDialog(context);
			}
		});
		builder.setPositiveButton(R.string.setNet,new DialogInterface.OnClickListener()
		{
			@Override
			public void onClick(DialogInterface dialog, int which)
			{
                dialog.dismiss();
                context.startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS));				
			}
		});
		if(alertDialog==null)
		   alertDialog=builder.create();
		if(!alertDialog.isShowing())
		    alertDialog.show();		
	}
	
	/**
	 * ������¼��ť
	 */
	class LoginListener implements OnClickListener
	{
		@Override
		public void onClick(View v)
		{	
			userAccount=userAccountText.getText().toString().trim();
			if(isConnected)//������������
			{
				if(userAccount!=null&&!"".equals(userAccount))
				{
					userSetting=userPreference.getPreferences(userAccount);
					boolean hasAuthrized=(Boolean) userSetting.get("isAuthrized");
					if(!hasAuthrized)//���û����֤������ʾ��֤��Ϣ
					{
						showAuthrizeDialog();
					}
				   else //�����֤����
				   {
					    String userId=(String)userSetting.get("userId");
					    String userExpireIn=userService.getUserExpireInById(userId);//ȡ���û�AccessToken����Ч��
						long authrizedTime=Long.parseLong(userPreference.getUserAuthrizedTime(userId))/1000;//ȡ����Ȩʱ��ʱ��
						long currentTime=System.currentTimeMillis()/1000;//ȡ�õ�ǰʱ��
						int time=(int)(currentTime-authrizedTime);
						if(time<Integer.parseInt(userExpireIn))//���AccessTokenδ���ڣ�ֱ�ӵ�¼
						{
							MainService.nowUserId=(String)userSetting.get("userId");
						    startActivity(new Intent(LoginActivity.this, MainActivity.class));//������ҳ�� 
							Toast.makeText(LoginActivity.this, R.string.login_success, Toast.LENGTH_SHORT).show();
						    userPreference.savePreferences(userAccount, (String) userSetting.get("userId"), hasAuthrized, isAutoLogin,isRememberMe);//�������ò���
							userPreference.saveLastUser(userAccount);//���汾�ε�¼�û�
							userPreference.saveUserDel(userAccount, false);
							MainService.removeActivityByName("LoginActivity");
						    finish();
						}
						else//���AccessToken���ڣ���ʾ��֤��Ϣ
						{
							showAuthrizeDialog();
						}
				   }
				}
				else
				{
				  Toast.makeText(LoginActivity.this, R.string.please_input_account, Toast.LENGTH_SHORT).show();
				}
			}
			else //���������쳣
			{
				showNetErrorDialog(LoginActivity.this); // ���������쳣�Ի���
			}	
		}
   }
	/**
	 * ��ʾ��֤��Ϣ�Ի���
	 */
	public void showAuthrizeDialog()
	{
		View digView = LayoutInflater.from(LoginActivity.this).inflate(R.layout.authorize_dialog, null);
		Authdialog = new  Dialog(LoginActivity.this, R.style.dialog_style);
		Authdialog.setContentView(digView);
//		Window window = Authdialog.getWindow();
//		WindowManager.LayoutParams lp = window.getAttributes();    
//		lp.alpha = 0.9f;//����͸����  
//		window.setAttributes(lp); 
		Authdialog.show();//��ʾ��Ȩ��ʾ�Ի���
		okButton = (ImageButton) digView.findViewById(R.id.btn_auth_begin);
		okButton.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				Authdialog.dismiss();
				Intent intent = new Intent(LoginActivity.this, WebViewActivity.class);
				startActivityForResult(intent, REQUEST_ACCESSTOKEN_CODE);//������Ȩ����
				Task task=new Task(TaskID.GET_AUTHORIZ_URL, null);
				MainService.addTask(task);
			}
		});
	}		
	@Override
	public void refresh(Object... param)
	{   
		int taskID=(Integer) param[0];
		if(taskID==TaskID.GET_ACCESS_TOKEN)
		{
			 if(!login)
			 {
				if(param[1]!=null)
				   accessToken=(AccessToken)param[1];
				if(accessToken!=null)
				{
					login();
				}
				else
				{
				  login=false;
				  isAuthrized=false;
				  if(progressDialog.isShowing())
					 progressDialog.dismiss();
				  Toast.makeText(this, R.string.Authorize_failed, Toast.LENGTH_LONG).show();
				}
			 }
		}
	}
	
	/**
	 * ��Ȩ������ĵ�¼
	 */
	public void login()
	{
	  login=true;
	  isAuthrized=true;
	  user = new UserInfo(accessToken.getUid()+"",accessToken.getAccessToken(),accessToken.getExpireIn());
	  UserInfo dbuser=userService.getUserInfoByUserId(String.valueOf(accessToken.getUid()));
	  if(dbuser==null||dbuser.getToken()==null)//��������ݿ��в����ڸ��û�����û�δ��Ȩ
	  {
		userService.insertUserInfo(user);//������Ȩ�û�
	  }
	  else 
	  {
		userService.updateUserInfo(user);//������Ȩ�û���Ϣ
	  }	  
	  String useraccount=WebViewDBUtil.getUserAccount(this);//��WebView�����ݿ���ȡ����
	  if(useraccount!=null&&!"".equals(useraccount))
	  {
	    if(!userAccount.equals(useraccount))//����û���¼�ı�����д���˺�����Ȩ��֤ʱ��д���˺Ų�һ�£�������Ȩ��֤ʱ���˺�Ϊ׼
		    userAccount=useraccount;
	  }
	  userPreference.savePreferences(userAccount, user.getUserId(), isAuthrized, isAutoLogin,isRememberMe);//�������ò���
	  userPreference.saveLastUser(userAccount);//���汾�ε�¼�û�
	  userPreference.saveUserAuthrizedTime(user.getUserId(), userAccount,String.valueOf(System.currentTimeMillis()));//�����û���Ȩʱ��ʱ��
	  userPreference.saveUserDel(userAccount, false);
	  MainService.addTask(new Task(TaskID.CLEAR_WEBVIEW_CACHE,null));//���WebView���ݿ⻺������
	  if(progressDialog.isShowing())
		 progressDialog.dismiss();
	  Toast.makeText(this, R.string.Authorize_success, Toast.LENGTH_SHORT).show();
	  Toast.makeText(this, R.string.login_success, Toast.LENGTH_SHORT).show();
	  MainService.nowUserId=user.getUserId();
	  startActivity(new Intent(LoginActivity.this, MainActivity.class));//������ҳ��
	  MainService.removeActivityByName("LoginActivity");
	  finish();
	}
	
	/**
	 * �����������
	 */
	public void checkConnection()
	{
		isConnected=NetUtil.checkNet(this);
	}
	
	/**
	 * �����û���CheckBox��ѡ��
	 */
	private OnCheckedChangeListener CheckBoxChangedListeber = new OnCheckedChangeListener()
	{
		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
		{
			if(isChecked)
			{
				if(buttonView==autoLogin)
				   isAutoLogin=true;
				if(buttonView==rememberMe)
				   isRememberMe=true;
			}	
			else
			{
				if(buttonView==autoLogin)
				   isAutoLogin=false;
				if(buttonView==rememberMe)
				   isRememberMe=false;
			}
		}
	};
	/**
	 * ��������ѡ���б�
	 */
	class PopMenuListener implements OnClickListener
	{
		@Override
		public void onClick(View v)
		{
			if(popupWindow==null)
			{
				getPopUserList();//��ȡ�����б���������
				popMenuAdapter=new PopMenuAdapter(LoginActivity.this, handler, userlist, R.layout.pop_item);
				ListView listView=new ListView(LoginActivity.this);
				listView.setAdapter(popMenuAdapter);
				popupWindow = new PopupWindow(listView, userAccountText.getWidth()-5, LayoutParams.WRAP_CONTENT);
				popupWindow.setFocusable(true);
				popupWindow.setBackgroundDrawable(new BitmapDrawable());//���õ����Ļ��������ʱȡ��PopupWindow��ʾ���������һ����벻�Ӳ�������
				popupWindow.showAsDropDown(userAccountText,3,-4);	
			}
			else
			{
				if(!popupWindow.isShowing())
					popupWindow.showAsDropDown(userAccountText,3,-4);
			}
		}
    }
	
	/**
	 * ��ȡ�����б���������
	 */
	public void getPopUserList()
	{
		userlist=new ArrayList<Map<String, Object>>();
		List<UserInfo> userInfoList=userService.getAllUsers();
		if(userInfoList!=null)
		{
			if(!userInfoList.isEmpty())
			{
				for (UserInfo userInfo : userInfoList)
				{
					Map<String, Object> userMap=new HashMap<String, Object>();
					String userId=userInfo.getUserId();
					String userIconSDPath=userPreference.getUserIconSDPath(userId);
					if(userIconSDPath!=null)
					{
						Drawable drawable=GetIconUtil.getDrawImageFromSD(userIconSDPath);
					    if(drawable!=null)
					    {
					    	userMap.put("userHead",drawable);
					    }
					}
					userMap.put("userAccount",userPreference.getUserAccount(userId));
					userlist.add(userMap);
				}
			}
		}
		if(!userlist.isEmpty())
		{
			for (int i = 0; i < userlist.size(); i++)
			{
				if(userPreference.getUserDelList((String) userlist.get(i).get("userAccount")))
				{
					userlist.remove(i);
				}
			}
		}
	}
	/**
	 * ���������б��ĵ���¼�
	 */
	public Handler handler=new Handler()
	{
		@Override
		public void handleMessage(Message msg)
		{
			switch (msg.what)
			{
				case 1:                         //��������˺ŵ��¼�
					   int location=msg.arg1;
					   userAccountText.setText((String)userlist.get(location).get("userAccount"));
					   if(userlist.get(location).get("userHead")!=null)
					      userHead.setImageDrawable((Drawable)userlist.get(location).get("userHead"));
					   else
						  userHead.setImageDrawable(getResources().getDrawable(R.drawable.user_default_head));
					   popupWindow.dismiss();
					   break;
				case 2:                         //����ɾ����ť����¼�
					   int position=msg.arg1;
					   String userAccount=(String) userlist.get(position).get("userAccount");
					   if(userAccountText.getText().toString().trim().equals(userAccount))
						  userHead.setImageDrawable(getResources().getDrawable(R.drawable.user_default_head));
					   userlist.remove(position);
					   popMenuAdapter.notifyDataSetChanged();
					   userPreference.saveUserDel(userAccount, true);
					   break;
			}
			super.handleMessage(msg);
		}
	};
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		checkConnection();//�ٴη��ص�½����ʱ�����������
		if(!isConnected) //���������쳣
			showNetErrorDialog(LoginActivity.this); // ���������쳣�Ի���
		else
		{
			if(requestCode==REQUEST_ACCESSTOKEN_CODE)
			{
				if(!login)
				{
					if(accessToken==null)
					{
					  if(resultCode==1)
					  {
						  progressDialog.setMessage(getString(R.string.loging));
						  progressDialog.show();
					  }
					  else
					  {
						  Toast.makeText(this, R.string.Authorize_failed, Toast.LENGTH_LONG).show();
					  }
					}
				}
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode==KeyEvent.KEYCODE_BACK)//�����ؼ��˳�����
		{
			SysApplication.getInstance().exitConfirmDialog(this);
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
