package fly.SinaWeibo.ui;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import weibo4j.model.Paging;
import weibo4j.model.User;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import fly.SinaWeibo.adapter.FollowersAdapter;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;
import fly.SinaWeibo.widget.PullToRefreshListView;
import fly.SinaWeibo.widget.PullToRefreshListView.OnRefreshListener;

public class FollowersActivity extends Activity implements IWeibo
{
	private int totalPage=1;
	private int nowPage=1;
	private View progressView;
	private Button backButton;
	private Button homeButton;
	private TextView titleText;
	private List<User> followersList;
	private FollowersAdapter followerAdapter;
	private PullToRefreshListView followersListView;
	private boolean moreItemClicked=false;
	private int position;
	private String uid;
	public static User checkedUser;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.friends);
		progressView=findViewById(R.id.progress_friends_load);
		MainService.addActivity(this);
		totalPage=getIntent().getIntExtra("totalPage", 1);
		uid=getIntent().getStringExtra("uid");
	    Map<String, Object> taskParams=new HashMap<String, Object>();
	    taskParams.put("Paging", new Paging(nowPage, 50));
	    taskParams.put("uid", uid);
	    MainService.addTask(new Task(TaskID.GET_USER_FOLLOWERS, taskParams));
		init();
	}
	@Override
	public void init()
	{
		followersListView=(PullToRefreshListView) findViewById(R.id.friends_listview);
		followersListView.setOnItemClickListener(new ListItemClickListener());
		followersListView.setOnRefreshListener(new PullRefreshListener());
		backButton=(Button) findViewById(R.id.btn_friends_back);
		homeButton=(Button) findViewById(R.id.btn_friends_home);
		titleText=(TextView) findViewById(R.id.txt_friends_title);
		if(uid.equals(MainService.nowUserId))
		   titleText.setText("�ҵķ�˿");
		else
		   titleText.setText("��˿�б�");
		backButton.setOnClickListener(buttonListener);
		homeButton.setOnClickListener(buttonListener);

	}
	@SuppressWarnings("unchecked")
	@Override
	public void refresh(Object... param)
	{
		int taskId=(Integer) param[0];
		switch(taskId)
		{
			case TaskID.GET_USER_FOLLOWERS://��÷�˿�б�
				 if(nowPage==1)
				 {
				     progressView.setVisibility(View.GONE);
				     if(param[1]!=null)
				        followersList=(List<User>) param[1];
					 followerAdapter=new FollowersAdapter(this, followersList, handler, R.layout.friends_list_item);
					 followersListView.setAdapter(followerAdapter);
				 }
				 else
				 {
					 if(param[1]!=null)
					 {
						 List<User> list=(List<User>) param[1];
						 if(list!=null&&!list.isEmpty())
						 {
							 for (User user : list)
							 {
								 followersList.add(user);
							 }
							 followerAdapter.updateData(followersList);
						 }
					 }
				 }
				 moreItemClicked=false;
				 break;
			case TaskID.REFRESH_USER_FOLLOWERS://ˢ�·�˿�б�
				 String updateTime="�������:" +new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.CHINA).format(new Date()).substring(5, 16);
				 followersListView.onRefreshComplete(updateTime);
				 if(param[1]!=null)
				    followersList=(List<User>) param[1];
				 followerAdapter=new FollowersAdapter(this, followersList, handler, R.layout.friends_list_item);
				 followersListView.setAdapter(followerAdapter);
				 break;
			case TaskID.CREATE_FRIENDS_TASK://��ע
				 boolean ok=(Boolean) param[1];
				 Toast.makeText(this,ok?"��ע�ɹ���":"��עʧ�ܣ�", Toast.LENGTH_SHORT).show();
				 if(ok)
				 {
					 FollowersAdapter.attentionButtonCache.get(position).setVisibility(View.GONE);
					 FollowersAdapter.unAttentionButtonCache.get(position).setVisibility(View.VISIBLE);
				 }
				 break;
			case TaskID.DELETE_FRIENDS_TASK://ȡ����ע
				 boolean success=(Boolean) param[1];
				 Toast.makeText(this, success?"ȡ����ע�ɹ���":"����ʧ�ܣ�", Toast.LENGTH_SHORT).show();
				 if(success)
				 {
					 FollowersAdapter.unAttentionButtonCache.get(position).setVisibility(View.GONE);
					 FollowersAdapter.attentionButtonCache.get(position).setVisibility(View.VISIBLE);
				 }
				 break;
		}
	}
	private Handler handler=new Handler()
	{
		@Override
		public void handleMessage(Message msg)
		{
			String uid=(String) msg.obj;
			Map<String, Object> taskParams=new HashMap<String, Object>();
			position=msg.arg1;
			switch(msg.what)
			{
				case 1://��ע
				      taskParams.put("uid", uid);
				      MainService.addTask(new Task(TaskID.CREATE_FRIENDS_TASK, taskParams));
					  break;
				case 2://ȡ����ע
					  taskParams.put("uid", uid);
				      MainService.addTask(new Task(TaskID.DELETE_FRIENDS_TASK, taskParams));
					  break;
			}
		}
	};
	private OnClickListener buttonListener =new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			switch(v.getId())
			{
				case R.id.btn_friends_back://����
					 MainService.removeActivity(FollowersActivity.this);
					 FollowersActivity.this.finish();
					 break;
				case R.id.btn_friends_home://������ҳ
					 MainService.removeActivityByName("FollowersActivity");
					 MainActivity.homeButton.setChecked(true);
					 startActivity(new Intent(FollowersActivity.this, MainActivity.class));
					 FollowersActivity.this.finish();
					 break;
			}
		}
	};
	class ListItemClickListener implements OnItemClickListener
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			if(id==-1&&!moreItemClicked)//��ȡ����
			{
				nowPage++;
				if(nowPage<=totalPage)
				{
					view.findViewById(R.id.moreText3).setVisibility(View.GONE);
					view.findViewById(R.id.more_friends_layout).setVisibility(View.VISIBLE);
					Map<String, Object> taskParams=new HashMap<String, Object>();
			        taskParams.put("Paging", new Paging(nowPage, 50));
			        taskParams.put("uid", uid);
				    MainService.addTask(new Task(TaskID.GET_USER_FOLLOWERS, taskParams));
				}
				else
				{
					followerAdapter.noMore();
				}
				moreItemClicked=true;
			}
			else
			{
				checkedUser=followersList.get(position-1);
				Intent intent=new Intent(FollowersActivity.this,UserInfoActivity.class);
				intent.putExtra("UID", checkedUser.getId());
				intent.putExtra("flg", "fromFollowers");
				startActivity(intent);
			}
		}
	}
	class PullRefreshListener implements OnRefreshListener
	{
		@Override
		public void onRefresh()
		{
			refresh();//����ˢ��
		}
	}
    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if(event.getAction()==KeyEvent.ACTION_DOWN)
		{
			MainService.removeActivity(FollowersActivity.this);
			finish();
		}
		return super.onKeyDown(keyCode, event);
	}
	protected void refresh()//ˢ��
	{
		nowPage=1;
		Map<String, Object> taskParams=new HashMap<String, Object>();
        taskParams.put("Paging", new Paging(nowPage, 50));
        taskParams.put("uid", uid);
	    MainService.addTask(new Task(TaskID.REFRESH_USER_FOLLOWERS, taskParams));
	}
}
