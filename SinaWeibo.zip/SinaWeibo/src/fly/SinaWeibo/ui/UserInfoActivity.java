package fly.SinaWeibo.ui;

import java.util.HashMap;
import java.util.Map;

import weibo4j.model.User;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import fly.SinaWeibo.adapter.AsyncImageLoader;
import fly.SinaWeibo.adapter.AsyncImageLoader.ImageCallback;
import fly.SinaWeibo.bean.Task;
import fly.SinaWeibo.bean.TaskID;
import fly.SinaWeibo.logic.MainService;

public class UserInfoActivity extends Activity implements IWeibo
{
	public static final String SCHEMA = "fly://sina_UserInfo";
	public static final String PARAM_UID = "uid";
	private static final Uri PROFILE_URI = Uri.parse(SCHEMA);
	private String userName;
	private String uid;
	private Dialog progressDialog;
	private User user;
	private Button backButton;
	private Button attentionButton;
	private Button unAttentionButton;
	private Button refreshButton;
	private Button atButton;
	private Button sendMSGButton;
	private Button addToBlackButton;
	private ImageView userIcon;
	private ImageView maleImage;
	private ImageView femaleImage;
	private ImageView vipImage;
	private TextView nameText;
	private TextView vipText;
	private TextView addressText;
	private TextView introText;
	private TextView attentionText;
	private TextView weiboText;
	private TextView fansText;
	private TextView topicText;
	private View attentionView;
	private View weiboView;
	private View fansView;
	private View topicView;
	private AsyncImageLoader asyncImageLoader;
	private int code=-1;
	private String flg;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_info);
		MainService.addActivity(this);
		extractUnameFromUri();
		uid=getIntent().getStringExtra("UID");
		flg=getIntent().getStringExtra("flg");
		init();
	}
	@Override
	public void init()
	{
		showProgressDialog("���ڼ���......");
		attentionView=findViewById(R.id.userinfo_attention_layout);
		weiboView=findViewById(R.id.userinfo_weibo_layout);
		fansView=findViewById(R.id.userinfo_fans_layout);
		topicView=findViewById(R.id.userinfo_topic_layout);
		backButton=(Button) findViewById(R.id.btn_userinfo_back);
		attentionButton=(Button) findViewById(R.id.userinfo_attention_bt);
		unAttentionButton=(Button) findViewById(R.id.userinfo_unattention_bt);
		refreshButton=(Button) findViewById(R.id.userinfo_refresh);
		atButton=(Button) findViewById(R.id.userinfo_atElse);
		sendMSGButton=(Button) findViewById(R.id.userinfo_senMsg);
		addToBlackButton=(Button) findViewById(R.id.userinfo_addToBlacklist);
		backButton.setOnClickListener(ButtonListener);
		attentionButton.setOnClickListener(ButtonListener);
		unAttentionButton.setOnClickListener(ButtonListener);
		refreshButton.setOnClickListener(ButtonListener);
		atButton.setOnClickListener(ButtonListener);
		sendMSGButton.setOnClickListener(ButtonListener);
		addToBlackButton.setOnClickListener(ButtonListener);
		attentionView.setOnClickListener(ButtonListener);
		weiboView.setOnClickListener(ButtonListener);
		fansView.setOnClickListener(ButtonListener);
		topicView.setOnClickListener(ButtonListener);
		userIcon=(ImageView) findViewById(R.id.userinfo_icon);
		maleImage=(ImageView) findViewById(R.id.user_sex_male_image);
		femaleImage=(ImageView) findViewById(R.id.user_sex_female_image);
		vipImage=(ImageView) findViewById(R.id.userinfo_v);
		nameText=(TextView) findViewById(R.id.user_info_name);
		vipText=(TextView) findViewById(R.id.userinfo_vip);
		addressText=(TextView) findViewById(R.id.userinfo_address);
		introText=(TextView) findViewById(R.id.userinfo_intro);
		attentionText=(TextView) findViewById(R.id.userinfo_attention);
		weiboText=(TextView) findViewById(R.id.userinfo_weibo);
		fansText=(TextView) findViewById(R.id.userinfo_fans);
		topicText=(TextView) findViewById(R.id.userinfo_topic);
		asyncImageLoader=new AsyncImageLoader();
		Map<String, Object> taskParams=new HashMap<String, Object>();
		if (userName!=null)
		{
			code=0;
			taskParams.put("code", code);
			taskParams.put("userName", userName);
			MainService.addTask(new Task(TaskID.GET_OTHER_USERINFO, taskParams));
		}
		else if(uid!=null)
		{
			code=1;
			taskParams.put("code", code);
			taskParams.put("uid", uid);
			MainService.addTask(new Task(TaskID.GET_OTHER_USERINFO, taskParams));
			if(flg.equals("fromWeiboInfo"))
			   user=WeiboInfoActivity.chosedUser;
			else if(flg.equals("fromFriends"))
			   user=FriendsActivity.checkedUser;
			else if(flg.equals("fromFollowers"))
			   user=FollowersActivity.checkedUser;
			else if(flg.equals("fromSearch"))
			   user=SearchActivity.searchedUser;
			else if(flg.equals("fromMSG"))
			   user=MSGActivity.commentUser;
			setInfo();
		}
		if(code==-1)
		   progressDialog.dismiss();
	}
	public void setInfo()
	{
		if(user!=null)
		{
			nameText.setText(user.getScreenName());
			String url=user.getAvatarLarge();
			if(url!=null)
			{
				Drawable drawable=AsyncImageLoader.getUserHead(url);
				if(drawable!=null)
			      userIcon.setImageDrawable(drawable);
				else
					asyncImageLoader.loadDrawable(url, userIcon, false, new imageCallback());
			}
		   if(user.getVerified())
			  vipImage.setVisibility(View.VISIBLE);
		   if(user.getGender().equals("f"))
		   {
			   maleImage.setVisibility(View.GONE);
			   femaleImage.setVisibility(View.VISIBLE);
		   }
		   vipText.setText(user.getVerifiedReason());
		   addressText.setText(user.getLocation());
		   introText.setText(user.getDescription());
		   attentionText.setText(user.getFriendsCount()+"");
		   weiboText.setText(user.getStatusesCount()+"");
		   fansText.setText(user.getFollowersCount()+"");
		   if (user.isFollowing())
		   {
			   attentionButton.setVisibility(View.GONE);
			   unAttentionButton.setVisibility(View.VISIBLE);
		   }
       }
   }
	private void extractUnameFromUri()
	{
		Uri uri = getIntent().getData();
		if (uri != null && PROFILE_URI.getScheme().equals(uri.getScheme()))
		{
			userName = uri.getQueryParameter(PARAM_UID);
		}
	}
	@Override
	public void refresh(Object... param)
	{
	  int taskID=(Integer) param[0];
      switch(taskID)
	  {
		case TaskID.GET_OTHER_USERINFO://��ȡ�û���Ϣ
			 progressDialog.dismiss();
			 if(code==0)
			 {
				 if(param[1]!=null)
				    user=(User) param[1];
				 int trendsNum=(Integer) param[2];
				 setInfo();
				 topicText.setText(trendsNum+"");
			 }
			 else if(code==1)
			 {
				int trendsNum=(Integer) param[1];
				topicText.setText(trendsNum+"");
			 }
			 break;
		case TaskID.REFRESH_OTHER_USERINFO://ˢ��
			 progressDialog.dismiss();
			 if(param[1]!=null)
			    user=(User) param[1];
			 int trendsNum=(Integer) param[2];
			 setInfo();
			 topicText.setText(trendsNum+"");
			 break;
		case TaskID.CREATE_FRIENDS_TASK://��ע
			 boolean ok=(Boolean) param[1];
			 Toast.makeText(this,ok?"��ע�ɹ���":"��עʧ�ܣ�", Toast.LENGTH_SHORT).show();
			 attentionButton.setVisibility(View.GONE);
			 unAttentionButton.setVisibility(View.VISIBLE);
			 break;
		case TaskID.DELETE_FRIENDS_TASK://ȡ����ע
			 boolean success=(Boolean) param[1];
			 Toast.makeText(this, success?"ȡ����ע�ɹ���":"����ʧ�ܣ�", Toast.LENGTH_SHORT).show();
			 unAttentionButton.setVisibility(View.GONE);
			 attentionButton.setVisibility(View.VISIBLE);
			 break;
	  }
	}
	private OnClickListener ButtonListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			Map<String, Object> taskParams=new HashMap<String, Object>();
			switch(v.getId())
			{
				case R.id.btn_userinfo_back://����
					 MainService.removeActivity(UserInfoActivity.this);
					 finish();
					 break;
				case R.id.userinfo_attention_bt://��ע
					 if(uid!=null)
					   taskParams.put("uid", uid);
					 else if (userName!=null)
					   taskParams.put("uname", userName);
				     MainService.addTask(new Task(TaskID.CREATE_FRIENDS_TASK, taskParams));
					 break;
				case R.id.userinfo_unattention_bt://ȡ����ע
					 if(uid!=null)
						 taskParams.put("uid", uid);
					 else if (userName!=null)
						 taskParams.put("uname", userName);
				     MainService.addTask(new Task(TaskID.DELETE_FRIENDS_TASK, taskParams));
					 break;
				case R.id.userinfo_refresh://ˢ��
					 if(user!=null)
					 {
					  showProgressDialog("���ڸ���......");
					  taskParams.put("uid", user.getId());
					  MainService.addTask(new Task(TaskID.REFRESH_OTHER_USERINFO, taskParams));
					 }
					 break;
				case R.id.userinfo_atElse://@��
					 if(user!=null)
					 {
						 Intent intent=new Intent(UserInfoActivity.this, NewWeiboActivity.class);
					     intent.putExtra("Type", "����");
					     intent.putExtra("uname", user.getScreenName());
						 startActivity(intent);
					 }
					 break;
				case R.id.userinfo_senMsg://��˽��
					 //δ�ҵ���Ӧ�ӿ�....�ݲ�֧��...
					 Toast.makeText(UserInfoActivity.this, "�ݲ�֧��...", Toast.LENGTH_SHORT).show();
					 break;
				case R.id.userinfo_addToBlacklist://���������
					 //δ�ҵ���Ӧ�ӿ�....�ݲ�֧��...
					 Toast.makeText(UserInfoActivity.this, "�ݲ�֧��...", Toast.LENGTH_SHORT).show();
					 break;
				case R.id.userinfo_attention_layout://��ע�б�
					 if(user!=null&&user.getFriendsCount()>0)
					 {
						 Intent intent=new Intent(UserInfoActivity.this, FriendsActivity.class);
						 int totalAttentionNum=user.getFriendsCount();
						 int totalAttentionPage=totalAttentionNum%20==0?totalAttentionNum/20:totalAttentionNum/20+1;
						 intent.putExtra("totalPage", totalAttentionPage);
					     intent.putExtra("uid",user.getId());
						 startActivity(intent);
					 }
					 break;
				case R.id.userinfo_weibo_layout://΢���б�
					 if(user!=null&&user.getStatusesCount()>0)
					 {
						 Intent intent=new Intent(UserInfoActivity.this, MyWeiboActivity.class);
						 int totalWeiboNum=user.getStatusesCount();
						 int totalWeiboPage=totalWeiboNum%20==0?totalWeiboNum/20:totalWeiboNum/20+1;
					     intent.putExtra("totalWeiboPage", totalWeiboPage);
					     intent.putExtra("uid",user.getId());
						 startActivity(intent);
					 } 
					 break;
				case R.id.userinfo_fans_layout://��˿�б�
					 if(user!=null&&user.getFollowersCount()>0)
					 {
						 Intent intent=new Intent(UserInfoActivity.this, FollowersActivity.class);
					     int totalFollowersNum=user.getFollowersCount();
						 int totalFollowersPage=totalFollowersNum%50==0?totalFollowersNum/50:totalFollowersNum/50+1;
					     intent.putExtra("totalPage", totalFollowersPage);
					     intent.putExtra("uid",user.getId());
						 startActivity(intent);
					 }
					 break;
				case R.id.userinfo_topic_layout://�����б�
					 if(user!=null&&MainService.otherUserTrendsList!=null&&MainService.otherUserTrendsList.size()>0)
					 {
						 Intent intent=new Intent(UserInfoActivity.this, TrendsActivity.class);
						 int totalTrendsNum=MainService.otherUserTrendsList.size();
						 int totalTrendsPage=totalTrendsNum%20==0?totalTrendsNum/20:totalTrendsNum/20+1;
						 intent.putExtra("totalPage", totalTrendsPage);
						 intent.putExtra("uid",user.getId());
						 startActivity(intent);
					 }
					 break;
			}
		}
	}; 
	class imageCallback implements ImageCallback
	{
		@Override
		public void imageLoaded(ImageView imageView, Drawable imageDrawable)
		{
		  if(imageDrawable!=null)
		   {
			 imageView.setImageDrawable(imageDrawable);
		   }
		}
	}
	public void showProgressDialog(String info)//��ʾ�Զ��������
	{
        View digView = getLayoutInflater().inflate(R.layout.progress_load_translucent, null);
        TextView textView=(TextView) digView.findViewById(R.id.progress_load_text);
        textView.setText(info);
        progressDialog = new Dialog(this, R.style.dialog_style2);
		progressDialog.setContentView(digView);
        progressDialog.show();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode==KeyEvent.KEYCODE_BACK)
		{
			 MainService.removeActivity(UserInfoActivity.this);
			 finish();
			 return false;
		}
		return super.onKeyDown(keyCode, event);
	}
}
