package fly.SinaWeibo.ui;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TabHost;
import fly.SinaWeibo.logic.MainService;

public class MainActivity extends TabActivity
{
	public static TabHost tabHost;
	public RadioGroup radioGroup;
	public static final String TAB_HOME="home"; 
	public static final String TAB_MSG="message"; 
	public static final String TAB_INFO="info";
	public static final String TAB_SEARCH="search"; 
	public static final String TAB_MORE="more"; 
	public static RadioButton homeButton;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		MainService.addActivity(this);
		SysApplication.getInstance().addActivity(this);
		homeButton=(RadioButton) findViewById(R.id.radio_button0);
		radioGroup=(RadioGroup) findViewById(R.id.main_radio);
		radioGroup.setOnCheckedChangeListener(new CheckListener());
		tabHost=getTabHost();//���TabHost����������ҳ��ÿ����ҳ��Ӧһ��Activity
		tabHost.addTab(tabHost.newTabSpec(TAB_HOME).setIndicator(TAB_HOME).setContent(new Intent(this,HomeActivity.class)));
		tabHost.addTab(tabHost.newTabSpec(TAB_MSG).setIndicator(TAB_MSG).setContent(new Intent(this,MSGActivity.class)));
		tabHost.addTab(tabHost.newTabSpec(TAB_INFO).setIndicator(TAB_INFO).setContent(new Intent(this,InfoActivity.class)));
		tabHost.addTab(tabHost.newTabSpec(TAB_SEARCH).setIndicator(TAB_SEARCH).setContent(new Intent(this,SearchActivity.class)));
		tabHost.addTab(tabHost.newTabSpec(TAB_MORE).setIndicator(TAB_MORE).setContent(new Intent(this,MoreActivity.class)));
	}
	
	class CheckListener implements OnCheckedChangeListener
	{
		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId)
		{
			switch(checkedId)
			{
				case R.id.radio_button0:
					 tabHost.setCurrentTabByTag(TAB_HOME);//��ҳ
					 break;
				case R.id.radio_button1:
					 tabHost.setCurrentTabByTag(TAB_MSG);//��Ϣ
					 break;
				case R.id.radio_button2:
					 tabHost.setCurrentTabByTag(TAB_INFO);//�û�����
					 break;
				case R.id.radio_button3:
					 tabHost.setCurrentTabByTag(TAB_SEARCH);//����
					 break;
				case R.id.radio_button4:
					 tabHost.setCurrentTabByTag(TAB_MORE);//����
					 break;
			}
		}
	}
}
