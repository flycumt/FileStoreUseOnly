package fly.SinaWeibo.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import weibo4j.model.Status;
import weibo4j.model.User;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import fly.SinaWeibo.adapter.AsyncImageLoader.ImageCallback;
import fly.SinaWeibo.ui.ImageActivity;
import fly.SinaWeibo.ui.R;
import fly.SinaWeibo.utils.DateUtil;
import fly.SinaWeibo.utils.EmotionUtil;

public class WeiboListAdapter extends BaseAdapter
{
	private int resource;
	private LayoutInflater inflater;
	private List<Status> statusList;
	private View moreItemView;
    private Context context;
    private AsyncImageLoader asyncImageLoader;
    private Map<Integer,View> viewCache=new HashMap<Integer, View>();
    private Map<Integer,Boolean> contentPicMap=new HashMap<Integer,Boolean>();
    private Map<Integer,Boolean> subcontentMap=new HashMap<Integer,Boolean>();
    private Map<Integer,Boolean> subcontentPicMap=new HashMap<Integer,Boolean>();
    private Map<Integer,Boolean> emotionMap=new HashMap<Integer,Boolean>();
    private Map<Integer,Boolean> subemotionMap=new HashMap<Integer,Boolean>();
    private Map<Integer,SpannableString> highlightMap=new HashMap<Integer, SpannableString>();
    private Map<Integer,SpannableString> subhighlightMap=new HashMap<Integer, SpannableString>();
    private Map<Integer,List<HashMap<String, String>>> emotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
    private Map<Integer,List<HashMap<String,String>>> subemotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
    
	public WeiboListAdapter(Context context, List<Status> statusList,List<Map<Integer,Boolean>> containList, List<Map<Integer,SpannableString>> highlightList,List<Map<Integer,List<HashMap<String, String>>>> emotionDataList,int resource)
	{
		this.statusList = statusList;
		this.resource = resource;
		this.context = context;
		inflater = LayoutInflater.from(context);
		contentPicMap=containList.get(0);
		subcontentMap=containList.get(1);
		subcontentPicMap=containList.get(2);
		emotionMap=containList.get(3);
		subemotionMap=containList.get(4);
		highlightMap=highlightList.get(0);
		subhighlightMap=highlightList.get(1);
		emotionDataMap=emotionDataList.get(0);
		subemotionDataMap=emotionDataList.get(1);
		asyncImageLoader=new AsyncImageLoader();
	}

	@Override
	public int getCount()
	{
		return statusList == null ? 0 : statusList.size()+1;
	}

	@Override
	public Object getItem(int position)
	{
		if(position<this.getCount()-1)
		{
		   return statusList == null ? null : (statusList.isEmpty() ? null : statusList.get(position));
		}
		else//����
		   return null;
	}

	@Override
	public long getItemId(int position)
	{
		if(position == this.getCount() - 1)// ѡ�����һ��
			return -1;
		else
			return statusList==null?null:(statusList.isEmpty()?null:Long.parseLong(statusList.get(position).getId()));
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(viewCache.get(position)==null)
		{
		  if(position == this.getCount() - 1)// ����
		  {
			  if(moreItemView==null)
			  {
			   convertView = LayoutInflater.from(context).inflate(R.layout.more_weibo_item, null);
			   moreItemView=convertView;
			  }
			  else
				convertView=moreItemView;
		  }
		  else
		  {
			  convertView=inflater.inflate(resource, null);
			  ViewHolder holder=new ViewHolder();
	          holder.weiboHeadView=(ImageView) convertView.findViewById(R.id.weibo_user_headView);
			  holder.nickName=(TextView) convertView.findViewById(R.id.weibo_item_uname);
			  holder.vipView=(ImageView) convertView.findViewById(R.id.weibo_sina_v);
			  holder.weiboTime=(TextView) convertView.findViewById(R.id.weibo_time_view);
			  holder.weiboContent=(TextView) convertView.findViewById(R.id.weibo_item_content);
			  holder.weiboContentPic=(ImageView) convertView.findViewById(R.id.weibo_item_content_pic);
			  holder.subContent=(TextView) convertView.findViewById(R.id.weibo_item_subcontent);
			  holder.subContentPic=(ImageView) convertView.findViewById(R.id.weibo_item_subcontent_pic);
			  holder.weiboSource=(TextView) convertView.findViewById(R.id.weibo_come_from);
			  holder.repost=(TextView) convertView.findViewById(R.id.weibo_item_repost);
			  holder.comment=(TextView) convertView.findViewById(R.id.weibo_item_comment);
			  holder.subLayout=convertView.findViewById(R.id.weibo_item_sublayout);
			  viewCache.put(position, convertView);
			  if(statusList!=null)
			  {
				if(!statusList.isEmpty())
				{
					Status status=statusList.get(position);
					if(status!=null)
					{
						User user=status.getUser();
						if(user!=null)
						{
							String headUrl=user.getAvatarLarge();
		    				if(headUrl!=null&&!headUrl.equals(""))//ͷ��
		    				   setDrawable(holder.weiboHeadView, headUrl, false);
							else
							   holder.weiboHeadView.setImageDrawable(context.getResources().getDrawable(R.drawable.user_default_head));
							holder.nickName.setText(user.getScreenName());//�ǳ�
							if(user.getVerified())//��֤�û�
							   holder.vipView.setVisibility(View.VISIBLE);
							else
							   holder.vipView.setVisibility(View.GONE);
						}
						holder.weiboTime.setText(DateUtil.getUpdateTime(status.getCreatedAt()));//����ʱ��
						if(!emotionMap.get(position))//΢�������Ƿ��б���
						    holder.weiboContent.setText(highlightMap.get(position));//΢�����ĸ�������
						else//����΢�������еı���
							holder.weiboContent.setText(parseEmotion(emotionDataMap.get(position),highlightMap.get(position)));
					    if(contentPicMap.get(position))//΢���������Ƿ���ͼƬ
						{
						   String contentPicUrl=status.getBmiddlePic();
						   setDrawable(holder.weiboContentPic, contentPicUrl, true);
						   holder.weiboContentPic.setVisibility(View.VISIBLE);
						   holder.weiboContentPic.setOnTouchListener(new OnPictureTouchListener(status.getOriginalPic()));
						}
						else
						  holder.weiboContentPic.setVisibility(View.GONE);
						if(subcontentMap.get(position))//�Ƿ���ת������
						{
						  holder.subLayout.setVisibility(View.VISIBLE);
						  if(!subemotionMap.get(position))//ת�������Ƿ��б���
						     holder.subContent.setText(subhighlightMap.get(position));//ת�����ݸ�������
						  else//����ת�������еı���
							  holder.subContent.setText(parseEmotion(subemotionDataMap.get(position), subhighlightMap.get(position)));
						  if(subcontentPicMap.get(position))//ת���������Ƿ���ͼƬ
						  {
							  String subContentPicUrl=status.getRetweetedStatus().getBmiddlePic();
							  setDrawable(holder.subContentPic, subContentPicUrl, true);
							  holder.subContentPic.setVisibility(View.VISIBLE);
							  holder.subContentPic.setOnTouchListener(new OnPictureTouchListener(status.getRetweetedStatus().getOriginalPic()));
						  }
						  else
							  holder.weiboContentPic.setVisibility(View.GONE);
						}
						else
							holder.subLayout.setVisibility(View.GONE);
						if(status.getSource()!=null)
						   holder.weiboSource.setText("����:"+status.getSource().getName());//��Դ
						if(status.getRepostsCount()>0)//ת������
						{
						   holder.repost.setText(status.getRepostsCount()+"");
						   holder.repost.setVisibility(View.VISIBLE);
						}
						else
							holder.repost.setVisibility(View.GONE);
						if(status.getCommentsCount()>0)//���۴���
						{
						   holder.comment.setText(status.getCommentsCount()+"");
						   holder.comment.setVisibility(View.VISIBLE);
						}
						else
						   holder.comment.setVisibility(View.GONE);
					}
				  }
			   }
		  }
		}
		else
		{
			return (View)viewCache.get(position);
		}
		return convertView;
	}
	private class ViewHolder
	{
		ImageView weiboHeadView;// ͷ��
		TextView nickName;// �ǳ�
		ImageView vipView;// ��֤ͼ��
		TextView weiboTime;// ʱ��
		TextView weiboContent;// ��������
		ImageView weiboContentPic;// �����������ͼƬ
		TextView subContent;// ת������
		ImageView subContentPic;//  ת���������ͼƬ
		TextView weiboSource;// ΢����Դ
		TextView repost;// ת������
		TextView comment;// ���۴���
		View subLayout;//ת�����ݲ���
	}
	public void setDrawable(ImageView imageView,String url,boolean pic)
	{
		Drawable drawable;
		if (pic)
			drawable = AsyncImageLoader.getDrawable(url);
		else
			drawable = AsyncImageLoader.getUserHead(url);
		if (drawable == null)
		{
			asyncImageLoader = new AsyncImageLoader();
			asyncImageLoader.loadDrawable(url, imageView, true, new imageCallback());
		}
		else
			imageView.setImageDrawable(drawable);
	}
	/**
	 *  ͼƬ�첽����
	 */
	class imageCallback implements ImageCallback
	{
		@Override
		public void imageLoaded(ImageView imageView, Drawable imageDrawable)
		{
		  if(imageDrawable!=null)
		   {
			 imageView.setImageDrawable(imageDrawable);
		   }
		}
	}
	/**
	 * ����΢������
	 * @param list
	 * @param spannableString
	 * @return SpannableString
	 */
	public SpannableString parseEmotion(List<HashMap<String, String>> list,SpannableString spannableString)
	{
		int id=0;
		for (HashMap<String, String> map : list)
		{
			String idStr=map.get(EmotionUtil.ID);
			if(idStr.equals("")||idStr.equals("0"))
				id=0;
			else
			    id=Integer.parseInt(idStr);
			if(id!=0)
			{
				Drawable drawable = context.getResources().getDrawable(id);
				if(drawable!=null)
				{
					drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
					ImageSpan imgSpan = new ImageSpan(drawable);
					spannableString.setSpan(imgSpan, Integer.parseInt(map.get(EmotionUtil.START)), Integer.parseInt(map.get(EmotionUtil.END)), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
			}
		}
		return spannableString;
      }
    //���¸���
    public void updateData(List<Status> statusList,List<Map<Integer,Boolean>> containList, List<Map<Integer,SpannableString>> highlightList,List<Map<Integer,List<HashMap<String, String>>>> emotionDataList)
    {
    	this.statusList=statusList;
    	contentPicMap=containList.get(0);
		subcontentMap=containList.get(1);
		subcontentPicMap=containList.get(2);
		emotionMap=containList.get(3);
		subemotionMap=containList.get(4);
		highlightMap=highlightList.get(0);
		subhighlightMap=highlightList.get(1);
		emotionDataMap=emotionDataList.get(0);
		subemotionDataMap=emotionDataList.get(1);
		moreItemView=null;
    	notifyDataSetChanged();
    }
    public void noMore()
    {
    	 moreItemView.findViewById(R.id.more_weibo_layout).setVisibility(View.GONE);
    	 TextView moreText=(TextView) moreItemView.findViewById(R.id.moreText);
		 moreText.setText("û�и�����");
		 moreText.setVisibility(View.VISIBLE);
		 notifyDataSetChanged();
    }
    class OnPictureTouchListener implements OnTouchListener
    {
    	private String url;
		public OnPictureTouchListener(String url)
		{
			this.url = url;
		}
		@Override
		public boolean onTouch(View v, MotionEvent event)
		{
			if(MotionEvent.ACTION_DOWN==event.getAction())
			{
				Intent intent=new Intent(context,ImageActivity.class);
				intent.putExtra("Url", url);
				context.startActivity(intent);
			}
			return true;
		}
    }
}
