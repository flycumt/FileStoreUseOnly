package fly.SinaWeibo.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import fly.SinaWeibo.ui.R;

public class PopMenuAdapter extends BaseAdapter
{
    private List<Map<String,Object>> userlist;
    private Handler handler;
    private int resource;
    private LayoutInflater inflater;
	
	public PopMenuAdapter(Context context, Handler handler,List<Map<String,Object>> userlist, int resource)
	{
		this.handler = handler;
		this.userlist = userlist;
		this.resource = resource;
		inflater=LayoutInflater.from(context);
	}

	@Override
	public int getCount()
	{
		return userlist.size();
	}

	@Override
	public Object getItem(int position)
	{
		return userlist.get(position);
	}

	@Override
	public long getItemId(int position)
	{
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent)
	{
		ViewHolder holder;
		if(convertView == null)
		{
			convertView=inflater.inflate(resource, null);
			holder = new ViewHolder();
			holder.userHeadView=(ImageView) convertView.findViewById(R.id.user_list_head);
			holder.userAccountView=(TextView) convertView.findViewById(R.id.user_list_account);
			holder.deleteButton=(ImageButton) convertView.findViewById(R.id.delete_list_button);
			convertView.setTag(holder);
		}
		else
		{
			holder=(ViewHolder) convertView.getTag();
		}
		Map<String, Object> userMap=new HashMap<String, Object>();
		if(!userlist.isEmpty())
		{
			userMap=userlist.get(position);
			if(userMap.get("userHead")!=null)
			   holder.userHeadView.setImageDrawable((Drawable) userMap.get("userHead"));
		    holder.userAccountView.setText((String)userMap.get("userAccount"));
		}
		holder.userAccountView.setOnClickListener(new OnClickListener()  //���������˺�
		{
			@Override
			public void onClick(View v)
			{
				Message msg=Message.obtain();
				msg.arg1=position;
				msg.what=1;
				handler.sendMessage(msg);
			}
		});
		holder.deleteButton.setOnClickListener(new OnClickListener() //����ɾ����ť
		{
			@Override
			public void onClick(View v)
			{
				Message msg=Message.obtain();
				msg.arg1=position;
				msg.what=2;
				handler.sendMessage(msg);
			}
		});
		return convertView;
	}
	private class ViewHolder
	{ 
		ImageView userHeadView; 
	    TextView userAccountView;
	    ImageButton deleteButton;
	} 

}
