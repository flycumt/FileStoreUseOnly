package fly.SinaWeibo.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import fly.SinaWeibo.ui.R;

public class TopicAdapter extends BaseAdapter
{
    private List<String> topiclist;
    private int resource;
    private LayoutInflater inflater;
    private Map<Integer,View> viewCache=new HashMap<Integer, View>();
    
	public TopicAdapter(Context context, List<String> topiclist,int resource)
	{
		this.topiclist = topiclist;
		this.resource = resource;
		inflater=LayoutInflater.from(context);
	}

	@Override
	public int getCount()
	{
		return topiclist.size();
	}

	@Override
	public Object getItem(int position)
	{
		return topiclist.get(position);
	}

	@Override
	public long getItemId(int position)
	{
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent)
	{
		if(viewCache.get(position)==null)
		{
			convertView=inflater.inflate(resource, null);
			TextView nameView=(TextView) convertView.findViewById(R.id.weibo_topic_at_name);
			if(position==0)
			{
			 TextView titleView=(TextView) convertView.findViewById(R.id.weibo_topic_at_title);
			 titleView.setText("���Ż���");
			 titleView.setVisibility(View.VISIBLE);
			}
			nameView.setText(topiclist.get(position));
			viewCache.put(position, convertView);
			return convertView;
		}
		return viewCache.get(position);
	}
}
