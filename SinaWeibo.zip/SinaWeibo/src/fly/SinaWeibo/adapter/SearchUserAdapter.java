package fly.SinaWeibo.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import weibo4j.model.User;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import fly.SinaWeibo.adapter.AsyncImageLoader.ImageCallback;
import fly.SinaWeibo.ui.R;

public class SearchUserAdapter extends BaseAdapter
{
   private List<User> userlist;
   private int resource;
   private LayoutInflater inflater;
   private Map<Integer,View> viewCache=new HashMap<Integer, View>();
   private Handler handler;
   private AsyncImageLoader asyncImageLoader;
   public static Map<Integer,Button> attentionButtonCache=new HashMap<Integer, Button>();
   public static Map<Integer,Button> unAttentionButtonCache=new HashMap<Integer, Button>();
   
	public SearchUserAdapter(Context context, List<User> userlist, Handler handler,int resource)
    {
		this.userlist = userlist;
		this.resource = resource;
		this.handler=handler;
		inflater=LayoutInflater.from(context);
		asyncImageLoader=new AsyncImageLoader();
    }

	@Override
	public int getCount()
	{
		return  userlist == null ? 0 : userlist.size();
	}

	@Override
	public Object getItem(int position)
	{
	   return userlist == null ? null : (userlist.isEmpty() ? null : userlist.get(position));
	}

	@Override
	public long getItemId(int position)
	{
	  return userlist==null?null:(userlist.isEmpty()?null:Long.parseLong(userlist.get(position).getId()));
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(viewCache.get(position)==null)
		{
			 convertView=inflater.inflate(resource, null);
			 ViewHolder holder=new ViewHolder();
			 holder.weiboHeadView=(ImageView) convertView.findViewById(R.id.search_user_head_view);
			 holder.nickName=(TextView) convertView.findViewById(R.id.search_uname);
			 holder.followerCount=(TextView) convertView.findViewById(R.id.search_follow_count);
			 holder.addressText=(TextView) convertView.findViewById(R.id.search_user_address);
			 holder.vipView=(ImageView) convertView.findViewById(R.id.search_vip);
			 holder.attentionButton=(Button) convertView.findViewById(R.id.search_attention_bt);
			 holder.unAttentionButton=(Button) convertView.findViewById(R.id.search_unattention_bt);
			 attentionButtonCache.put(position, holder.attentionButton);
			 unAttentionButtonCache.put(position, holder.unAttentionButton);
			 viewCache.put(position, convertView);
			 if(userlist!=null)
			  {
				if(!userlist.isEmpty())
				{
					User user=userlist.get(position);
					if(user!=null)
					{
						String url=user.getAvatarLarge();
						if(url!=null&&!url.equals(""))
						{
							Drawable drawable=AsyncImageLoader.getDrawable(url);
							if(drawable==null)
								asyncImageLoader.loadDrawable(url, holder.weiboHeadView, false, new imageCallback());
						}
						holder.nickName.setText(user.getScreenName());
						holder.followerCount.setText("��˿"+user.getFollowersCount()+"");
						holder.addressText.setText(user.getLocation());
						if(user.getVerified())
							holder.vipView.setVisibility(View.VISIBLE);
						else
							holder.vipView.setVisibility(View.GONE);
						if(user.isFollowing())
						{
							holder.attentionButton.setVisibility(View.GONE);
							holder.unAttentionButton.setVisibility(View.VISIBLE);
						}
						holder.attentionButton.setOnTouchListener(new AttentionButtonListener(user.getId(),position));
						holder.unAttentionButton.setOnTouchListener(new UnAttentionButtonListener(user.getId(),position));
					}
				}
			  }
		}
		else
			return (View)viewCache.get(position);
		return convertView;
	}
	private class AttentionButtonListener implements OnTouchListener
	{
		private String uid;
		private int position;
		public AttentionButtonListener(String uid,int position)
		{
			this.uid=uid;
			this.position=position;
		}
		@Override
		public boolean onTouch(View v, MotionEvent event)
		{
			if(MotionEvent.ACTION_DOWN==event.getAction())
			{
			    Message msg=handler.obtainMessage();
			    msg.what=1;
			    msg.obj=uid;
			    msg.arg1=position;
			    handler.sendMessage(msg);
			}
			return false;
		}
	}
	private class UnAttentionButtonListener implements OnTouchListener
	{
		private String uid;
		private int position;
		public UnAttentionButtonListener(String uid,int position)
		{
			this.uid=uid;
			this.position=position;
		}
		@Override
		public boolean onTouch(View v, MotionEvent event)
		{
			if(MotionEvent.ACTION_DOWN==event.getAction())
			{
				Message msg=handler.obtainMessage();
				msg.what=2;
				msg.obj=uid;
				msg.arg1=position;
				handler.sendMessage(msg);
			}
			return false;
		}
	}
	private static class ViewHolder
	{
		ImageView weiboHeadView;// ͷ��
		TextView nickName;// �ǳ�
		ImageView vipView;// ��֤ͼ��
		TextView followerCount;// ��˿
		TextView addressText;//��ַ
		Button attentionButton;//��ע��ť
		Button unAttentionButton;//ȡ����ע��ť
	}
	class imageCallback implements ImageCallback
	{
		@Override
		public void imageLoaded(ImageView imageView, Drawable imageDrawable)
		{
		  if(imageDrawable!=null)
		   {
			 imageView.setImageDrawable(imageDrawable);
		   }
		}
	}
}
