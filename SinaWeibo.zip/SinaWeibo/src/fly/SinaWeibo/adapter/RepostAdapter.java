package fly.SinaWeibo.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import weibo4j.model.Status;
import weibo4j.model.User;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import fly.SinaWeibo.adapter.AsyncImageLoader.ImageCallback;
import fly.SinaWeibo.ui.R;
import fly.SinaWeibo.ui.WeiboInfoActivity;
import fly.SinaWeibo.utils.DateUtil;
import fly.SinaWeibo.utils.EmotionUtil;

public class RepostAdapter extends BaseAdapter
{
	private  List<Status> statusList;
	private int resource;
	private View moreItemView;
	private LayoutInflater inflater;
	private Context context;
	private Handler handler;
	private Map<Integer,View> viewCache=new HashMap<Integer, View>();
	private Map<Integer, SpannableString> highLight=new HashMap<Integer, SpannableString>(); 
	private Map<Integer, Boolean> hasEmotionMap=new HashMap<Integer, Boolean>();
	private Map<Integer, List<HashMap<String, String>>> emotionDataMap=new HashMap<Integer, List<HashMap<String,String>>>();
	private AsyncImageLoader asyncImageLoader;
	
	public RepostAdapter(Context context, List<Status> statusList, Map<Integer, SpannableString> highLight, Map<Integer, Boolean> hasEmotionMap, Map<Integer, List<HashMap<String, String>>> emotionDataMap,int resource)
	{
		this.context = context;
		this.statusList = statusList;
		this.resource = resource;
		this.highLight=highLight;
		this.hasEmotionMap=hasEmotionMap;
		this.emotionDataMap=emotionDataMap;
		inflater=LayoutInflater.from(context);
		asyncImageLoader=new AsyncImageLoader();
	}

	@Override
	public int getCount()
	{
		return statusList == null ? 0 : statusList.size()+1;
	}

	@Override
	public Object getItem(int position)
	{
		if(position<this.getCount()-1)
		{
		   return statusList == null ? null : (statusList.isEmpty() ? null : statusList.get(position));
		}
		else//����
		   return null;
	}

	@Override
	public long getItemId(int position)
	{
		if(position == this.getCount() - 1)// ѡ�����һ��
			return -1;
		else
			return statusList==null?null:(statusList.isEmpty()?null:Long.parseLong(statusList.get(position).getId()));
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(viewCache.get(position)==null)
		{
			 if(position == this.getCount() - 1)// ����
			 {
				  if(moreItemView==null)
				  {
				   convertView = LayoutInflater.from(context).inflate(R.layout.more_weibo_item2, null);
				   moreItemView=convertView;
				  }
				  else
					convertView=moreItemView;
			 }
			 else
			 {
				 convertView=inflater.inflate(resource, null);
				 ViewHolder holder=new ViewHolder();
				 holder.weiboHeadView=(ImageView)convertView.findViewById(R.id.weibo_detail_repost_user_head);
				 holder.vipView=(ImageView)convertView.findViewById(R.id.weibo_detail_repost_vip);
				 holder.nickName=(TextView) convertView.findViewById(R.id.weibo_detail_repost_uname);
				 holder.weiboTime=(TextView) convertView.findViewById(R.id.weibo_detail_repost_time_view);
				 holder.weiboText=(TextView) convertView.findViewById(R.id.weibo_detail_repost_content);
				 viewCache.put(position, convertView);
				if (statusList != null)
				{
					if (!statusList.isEmpty())
					{
						Status status = statusList.get(position);
						if (status != null)
						{
							User user=status.getUser();
							String headUrl=user.getAvatarLarge();
		    				if(headUrl!=null&&!headUrl.equals(""))//ͷ��
		    				   setDrawable(holder.weiboHeadView, headUrl, false);
							else
							   holder.weiboHeadView.setImageDrawable(context.getResources().getDrawable(R.drawable.user_default_head));
							holder.nickName.setText(user.getScreenName());//�ǳ�
							if(user.getVerified())//��֤�û�
							   holder.vipView.setVisibility(View.VISIBLE);
							else
							   holder.vipView.setVisibility(View.GONE);
							holder.weiboTime.setText(DateUtil.getUpdateTime(status.getCreatedAt()));//����ʱ��
							if(!hasEmotionMap.get(position))//΢�������Ƿ��б���
							    holder.weiboText.setText(highLight.get(position));//΢�����ĸ�������
							else//����΢�������еı���
								holder.weiboText.setText(parseEmotion(emotionDataMap.get(position),highLight.get(position)));
							WeiboInfoActivity.extractMention2Link(holder.weiboText);
							holder.weiboHeadView.setOnTouchListener(new HeadViewHeadView(user));
						}
					}
				}
			 }
		}
		else
		{
			return (View)viewCache.get(position);
		}
		return convertView;
	}
	public void setDrawable(ImageView imageView,String url,boolean pic)
	{
		Drawable drawable;
		if (pic)
			drawable = AsyncImageLoader.getDrawable(url);
		else
			drawable = AsyncImageLoader.getUserHead(url);
		if (drawable == null)
		{
			asyncImageLoader = new AsyncImageLoader();
			asyncImageLoader.loadDrawable(url, imageView, true, new imageCallback());
		}
		else
			imageView.setImageDrawable(drawable);
	}
	private static class ViewHolder
	{
		ImageView weiboHeadView;// ͷ��
		TextView nickName;// �ǳ�
		ImageView vipView;// ��֤ͼ��
		TextView weiboTime;// ʱ��
		TextView weiboText;// ��������
	}
	/**
	 * ����΢������
	 * @param list
	 * @param spannableString
	 * @return SpannableString
	 */
	public SpannableString parseEmotion(List<HashMap<String, String>> list,SpannableString spannableString)
	{
		int id=0;
		for (HashMap<String, String> map : list)
		{
			String idStr=map.get(EmotionUtil.ID);
			if(idStr.equals("")||idStr.equals("0"))
				id=0;
			else
			    id=Integer.parseInt(idStr);
			if(id!=0)
			{
				Drawable drawable = context.getResources().getDrawable(id);
				if(drawable!=null)
				{
					drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
					ImageSpan imgSpan = new ImageSpan(drawable);
					spannableString.setSpan(imgSpan, Integer.parseInt(map.get(EmotionUtil.START)), Integer.parseInt(map.get(EmotionUtil.END)), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
			}
		}
		return spannableString;
      }
	public void noMore()
    {
    	 moreItemView.findViewById(R.id.more_weibo_layout2).setVisibility(View.GONE);
    	 TextView moreText=(TextView) moreItemView.findViewById(R.id.moreText2);
		 moreText.setText("û�и�����");
		 moreText.setVisibility(View.VISIBLE);
		 notifyDataSetChanged();
    }
	 //���¸���
    public void updateData(List<Status> statusList,Map<Integer, SpannableString> highLight, Map<Integer, Boolean> hasEmotionMap, Map<Integer, List<HashMap<String, String>>> emotionDataMap)
    {
    	this.statusList=statusList;
		this.highLight=highLight;
		this.hasEmotionMap=hasEmotionMap;
		this.emotionDataMap=emotionDataMap;
		moreItemView=null;
    	notifyDataSetChanged();
    }
	/**
	 *  ͼƬ�첽����
	 */
	class imageCallback implements ImageCallback
	{
		@Override
		public void imageLoaded(ImageView imageView, Drawable imageDrawable)
		{
		  if(imageDrawable!=null)
		   {
			 imageView.setImageDrawable(imageDrawable);
		   }
		}
	}
	class HeadViewHeadView implements OnTouchListener//OnClickListener
	{
		private User user;
		public HeadViewHeadView(User user)
		{
			this.user = user;
		}
//		@Override
//		public void onClick(View v)
//		{
//			Message msg=handler.obtainMessage();
//			msg.obj=user;
//			handler.sendMessage(msg);
//		}
		@Override
		public boolean onTouch(View v, MotionEvent event)
		{
			if(MotionEvent.ACTION_DOWN==event.getAction())
			{
				Message msg=handler.obtainMessage();
				msg.obj=user;
				handler.sendMessage(msg);
			}
			return false;
		}
	}
	public void setHandler(Handler handler)
	{
		this.handler=handler;
	}
}
