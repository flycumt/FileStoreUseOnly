package fly.SinaWeibo.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import weibo4j.model.User;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import fly.SinaWeibo.adapter.AsyncImageLoader.ImageCallback;
import fly.SinaWeibo.ui.R;

public class FollowersAdapter extends BaseAdapter
{
   private List<User> followerslist;
   private Context context;
   private int resource;
   private LayoutInflater inflater;
   private Map<Integer,View> viewCache=new HashMap<Integer, View>();
   private View moreItemView;
   private Handler handler;
   private AsyncImageLoader asyncImageLoader;
   public static Map<Integer,Button> attentionButtonCache=new HashMap<Integer, Button>();
   public static Map<Integer,Button> unAttentionButtonCache=new HashMap<Integer, Button>();
   
	public FollowersAdapter(Context context, List<User> followerslist, Handler handler,int resource)
    {
		this.context = context;
		this.followerslist = followerslist;
		this.resource = resource;
		this.handler=handler;
		inflater=LayoutInflater.from(context);
		asyncImageLoader=new AsyncImageLoader();
    }

	@Override
	public int getCount()
	{
		return  followerslist == null ? 0 : followerslist.size()+1;
	}

	@Override
	public Object getItem(int position)
	{
		if(position<this.getCount()-1)
		{
		   return followerslist == null ? null : (followerslist.isEmpty() ? null : followerslist.get(position));
		}
		else//����
		   return null;
	}

	@Override
	public long getItemId(int position)
	{
		if(position == this.getCount() - 1)// ѡ�����һ��
			return -1;
		else
			return followerslist==null?null:(followerslist.isEmpty()?null:Long.parseLong(followerslist.get(position).getId()));
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(viewCache.get(position)==null)
		{
			 if(position == this.getCount() - 1)// ����
			 {
				  if(moreItemView==null)
				  {
				   convertView = LayoutInflater.from(context).inflate(R.layout.more_friends_item, null);
				   moreItemView=convertView;
				  }
				  else
					convertView=moreItemView;
			 }
			 else
			 {
				 convertView=inflater.inflate(resource, null);
				 ViewHolder holder=new ViewHolder();
				 holder.weiboHeadView=(ImageView) convertView.findViewById(R.id.friends_user_head);
				 holder.nickName=(TextView) convertView.findViewById(R.id.friends_uname);
				 holder.vipView=(ImageView) convertView.findViewById(R.id.friends_vip);
				 holder.attentionButton=(Button) convertView.findViewById(R.id.friends_attention_bt);
				 holder.unAttentionButton=(Button) convertView.findViewById(R.id.friends_unattention_bt);
				 attentionButtonCache.put(position, holder.attentionButton);
				 unAttentionButtonCache.put(position, holder.unAttentionButton);
				 viewCache.put(position, convertView);
				 if(followerslist!=null)
				  {
					if(!followerslist.isEmpty())
					{
						User user=followerslist.get(position);
						if(user!=null)
						{
							String url=user.getAvatarLarge();
							if(url!=null&&!url.equals(""))
							{
								Drawable drawable=AsyncImageLoader.getDrawable(url);
								if(drawable==null)
									asyncImageLoader.loadDrawable(url, holder.weiboHeadView, false, new imageCallback());
							}
							holder.nickName.setText(user.getScreenName());
							if(user.getVerified())
								holder.vipView.setVisibility(View.VISIBLE);
							else
								holder.vipView.setVisibility(View.GONE);
							if(!user.isFollowing())
							{
								holder.unAttentionButton.setVisibility(View.GONE);
								holder.attentionButton.setVisibility(View.VISIBLE);
							}
							holder.attentionButton.setOnTouchListener(new AttentionButtonListener(user.getId(),position));
							holder.unAttentionButton.setOnTouchListener(new UnAttentionButtonListener(user.getId(),position));
						}
					}
				  }
				
			 }
		}
		else
			return (View)viewCache.get(position);
		return convertView;
	}
	private class AttentionButtonListener implements OnTouchListener
	{
		private String uid;
		private int position;
		public AttentionButtonListener(String uid,int position)
		{
			this.uid=uid;
			this.position=position;
		}
		@Override
		public boolean onTouch(View v, MotionEvent event)
		{
			if(MotionEvent.ACTION_DOWN==event.getAction())
			{
			    Message msg=handler.obtainMessage();
			    msg.what=1;
			    msg.obj=uid;
			    msg.arg1=position;
			    handler.sendMessage(msg);
			}
			return false;
		}
	}
	private class UnAttentionButtonListener implements OnTouchListener
	{
		private String uid;
		private int position;
		public UnAttentionButtonListener(String uid,int position)
		{
			this.uid=uid;
			this.position=position;
		}
		@Override
		public boolean onTouch(View v, MotionEvent event)
		{
			if(MotionEvent.ACTION_DOWN==event.getAction())
			{
				Message msg=handler.obtainMessage();
				msg.what=2;
				msg.obj=uid;
				msg.arg1=position;
				handler.sendMessage(msg);
			}
			return false;
		}
	}
	private static class ViewHolder
	{
		ImageView weiboHeadView;// ͷ��
		TextView nickName;// �ǳ�
		ImageView vipView;// ��֤ͼ��
		Button attentionButton;//��ע��ť
		Button unAttentionButton;//ȡ����ע��ť
	}
	class imageCallback implements ImageCallback
	{
		@Override
		public void imageLoaded(ImageView imageView, Drawable imageDrawable)
		{
		  if(imageDrawable!=null)
		   {
			 imageView.setImageDrawable(imageDrawable);
		   }
		}
	}
	 //���¸���
    public void updateData(List<User> friendsList)
    {
    	this.followerslist=friendsList;
		moreItemView=null;
    	notifyDataSetChanged();
    }
    public void noMore()
    {
    	 moreItemView.findViewById(R.id.more_friends_layout).setVisibility(View.GONE);
    	 TextView moreText=(TextView) moreItemView.findViewById(R.id.moreText3);
		 moreText.setText("û�и�����");
		 moreText.setVisibility(View.VISIBLE);
		 notifyDataSetChanged();
    }
}
