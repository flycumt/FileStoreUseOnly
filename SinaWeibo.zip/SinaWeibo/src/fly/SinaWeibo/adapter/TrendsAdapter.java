package fly.SinaWeibo.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import weibo4j.model.UserTrend;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import fly.SinaWeibo.ui.R;

public class TrendsAdapter extends BaseAdapter
{
   private List<UserTrend> trendslist;
   private Context context;
   private int resource;
   private LayoutInflater inflater;
   private Map<Integer,View> viewCache=new HashMap<Integer, View>();
   private View moreItemView;
   private TextView trendsText;
	public TrendsAdapter(Context context, List<UserTrend> trendslist,int resource)
    {
		this.context = context;
		this.trendslist = trendslist;
		this.resource = resource;
		inflater=LayoutInflater.from(context);
    }

	@Override
	public int getCount()
	{
		return  trendslist == null ? 0 : trendslist.size()+1;
	}

	@Override
	public Object getItem(int position)
	{
		if(position<this.getCount()-1)
		{
		   return trendslist == null ? null : (trendslist.isEmpty() ? null : trendslist.get(position));
		}
		else//����
		   return null;
	}

	@Override
	public long getItemId(int position)
	{
		if(position == this.getCount() - 1)// ѡ�����һ��
			return -1;
		else
			return trendslist==null?null:(trendslist.isEmpty()?null:Long.parseLong(trendslist.get(position).gettrendId()));
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		if(viewCache.get(position)==null)
		{
			 if(position == this.getCount() - 1)// ����
			 {
				  if(moreItemView==null)
				  {
				   convertView = LayoutInflater.from(context).inflate(R.layout.more_friends_item, null);
				   moreItemView=convertView;
				  }
				  else
					convertView=moreItemView;
			 }
			 else
			 {
				 convertView=inflater.inflate(resource, null);
				 trendsText=(TextView) convertView.findViewById(R.id.myinfo_trends_item_txt);
				 viewCache.put(position, convertView);
				 if(trendslist!=null)
				  {
					if(!trendslist.isEmpty())
					{
						UserTrend userTrend=trendslist.get(position);
						if(userTrend!=null)
						   trendsText.setText(userTrend.getHotword());
					}
				  }
			 }
		}
		else
			return (View)viewCache.get(position);
		return convertView;
	}
	 //���¸���
    public void updateData(List<UserTrend> trendslist)
    {
    	this.trendslist=trendslist;
		moreItemView=null;
    	notifyDataSetChanged();
    }
    public void noMore()
    {
    	 moreItemView.findViewById(R.id.more_friends_layout).setVisibility(View.GONE);
    	 TextView moreText=(TextView) moreItemView.findViewById(R.id.moreText3);
		 moreText.setText("û�и�����");
		 moreText.setVisibility(View.VISIBLE);
		 notifyDataSetChanged();
    }
}
