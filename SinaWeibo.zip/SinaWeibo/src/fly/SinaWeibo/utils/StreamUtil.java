package fly.SinaWeibo.utils;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class StreamUtil
{
	/**
	 * ��ȡ���е�����
	 * @param inputStream
	 * @return byte[]
	 * @throws Exception
	 */
	public static byte[] read(InputStream inputStream) throws Exception
	{
		ByteArrayOutputStream outstream = new ByteArrayOutputStream();
		byte[] buffer = new byte[1024];
		int len = 0;
		while ((len = inputStream.read(buffer)) != -1)
		{
			outstream.write(buffer, 0, len);
		}
		inputStream.close();
		return outstream.toByteArray();
	}

	public static byte[] readFileImage(String path) throws IOException
	{
		BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(new File(path)));
		int len = bufferedInputStream.available();
		byte[] bytes = new byte[len];
		int r = bufferedInputStream.read(bytes);
		if (len != r)
		{
			bytes = null;
			throw new IOException("��ȡ�ļ�����ȷ");
		}
		bufferedInputStream.close();
		return bytes;
	}
}
