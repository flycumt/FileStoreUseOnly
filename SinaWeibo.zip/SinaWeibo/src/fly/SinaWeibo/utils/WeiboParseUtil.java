package fly.SinaWeibo.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;

public class WeiboParseUtil
{
	private String parseStr;
	private SpannableString spannableString;
	private static final String START = "start";
	private static final String END = "end";
	private static final String PHRASE = "phrase";
	private static final String TOPIC="#.+?#";//ƥ�仰����������ʽ
	private static final String NAME="@([\u4e00-\u9fa5A-Za-z0-9_-]*)";//ƥ���ǳƵ��������ʽ//@([0-9a-zA-Z\u4e00-\u9fa5_-]+)
	private static final String URL="http://([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&=]*)?";//ƥ��http��ַ���������ʽ
	
	public WeiboParseUtil(String parseStr)
	{
		this.parseStr=parseStr;
		spannableString = new SpannableString(parseStr);
	}
	public SpannableString getHighLight()//ȡ�ø������ú��SpannableString
	{
		highLight(Pattern.compile(TOPIC));//��������
		highLight(Pattern.compile(NAME));//�����ǳ�
		highLight(Pattern.compile(URL));//������ַ
		return spannableString;
	}
	public void highLight(Pattern pattern)
	{
		List<HashMap<String, String>> list = getStartAndEnd(pattern);
		for (HashMap<String, String> map : list)
		{
			ForegroundColorSpan span = new ForegroundColorSpan(Color.BLUE);
			spannableString.setSpan(span, Integer.parseInt(map.get(START)), Integer.parseInt(map.get(END)), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		}
	}

	public List<HashMap<String, String>>  getStartAndEnd(Pattern pattern)
	{
		List<HashMap<String, String>> list = new ArrayList<HashMap<String,String>>();
		Matcher matcher = pattern.matcher(parseStr);
		while(matcher.find())
		{
			HashMap<String, String> map = new HashMap<String, String>();
			map.put(PHRASE, matcher.group());
			map.put(START, matcher.start()+"");
			map.put(END, matcher.end()+"");
			list.add(map);
		}
		return list;
	}
}
