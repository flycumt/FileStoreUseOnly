package fly.SinaWeibo.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;

import android.graphics.Bitmap;
import android.os.Environment;

public class FileUtils 
{
	private String SDRootPath;

	public String getSDRootPath() 
	{
		return SDRootPath;
	}
	public FileUtils() 
	{
		SDRootPath = Environment.getExternalStorageDirectory().getAbsolutePath()+File.separator;//�õ���ǰ�ⲿ�洢�豸�ĸ�Ŀ¼
	}
	/**
	 * ��SD���ϴ����ļ�
	 * @throws IOException
	 */
	public File creatFileInSDCard(String fileName,String dir) throws IOException 
	{
		File file = new File(SDRootPath +dir+File.separator+fileName);
		boolean f=file.createNewFile();
		System.out.println("creatFileInSDCard>>>>>>>>>>>>>"+f);
		return file;
	}
	
	/**
	 * ��SD���ϴ���Ŀ¼
	 * @param dirName
	 */
	public File creatSDDir(String dirName) 
	{
		File dir = new File(SDRootPath + dirName+File.separator);
		dir.mkdirs();
		return dir;
	}

	/**
	 *  �ж�SD���ϵ��ļ����Ƿ����
	 * @param fileName
	 * @param parth
	 * @return boolean
	 */
	public boolean isFileExist(String fileName,String path)
	{
		File file = new File(SDRootPath+path+File.separator+fileName);
		return file.exists();
	}
	
	/**
	 *  ��һ��InputStream���������д�뵽SD����
	 * @param path
	 * @param fileName
	 * @param input
	 * @return File
	 */
	public File save2SD(String relativePath,String fileName,InputStream input)
	{
		File file = null;
		OutputStream output = null;
		int temp;
		try
		{
			creatSDDir(relativePath); //��SD���ϴ���Ŀ¼
			file = creatFileInSDCard(fileName,relativePath);//��SD����ָ��Ŀ¼�´����ļ�
			output = new FileOutputStream(file);
			byte buffer [] = new byte[4 * 1024];			
			while((temp=input.read(buffer)) != -1)
			{
				output.write(buffer,0,temp);
			}
			output.flush();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				output.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return file;
	}
	/**
	 * ��һ��byte[]��������д��SD����
	 * @param path
	 * @param fileName
	 * @param input
	 * @return File
	 */
	public File save2SD(String relativePath,String fileName, byte[] data)
	{
		File file = null;
		OutputStream output = null;
		try
		{
			creatSDDir(relativePath); //��SD���ϴ���Ŀ¼
			file = creatFileInSDCard(fileName,relativePath);//��SD����ָ��Ŀ¼�´����ļ�
			output = new FileOutputStream(file);
			output.write(data);
			output.flush();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				output.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return file;
	}

	public String saveImage2SD(Bitmap bitmap,String relativePath,String fileName)
	{
		if (bitmap == null)
		{
			return null;
		}
		File file = null;
		ByteArrayOutputStream outputStream=null;
		RandomAccessFile accessFile = null;
		try
		{
			creatSDDir(relativePath); 
			file = creatFileInSDCard(fileName,relativePath);
			outputStream = new ByteArrayOutputStream();
			bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
			byte[] buffer = outputStream.toByteArray();
			accessFile = new RandomAccessFile(file, "rw");
			accessFile.write(buffer);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
		finally
		{
			try
			{
				outputStream.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return file.getAbsolutePath();
	}

}