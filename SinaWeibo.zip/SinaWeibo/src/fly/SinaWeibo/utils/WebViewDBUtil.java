package fly.SinaWeibo.utils;

import java.io.File;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class WebViewDBUtil
{
	private static String webviewfile="/data/data/fly.SinaWeibo.ui/databases/webview.db";
	private static String webviewCachefile="/data/data/fly.SinaWeibo.ui/databases/webviewCache.db";
	/**
	 * ��WebView���������ݿ�����ȡ�û��ύ�����е��˺�
	 * @param context
	 * @return String
	 */
    public static String getUserAccount(Context context)
    {
    	String userAccount="";
	    File file=new File(webviewfile);
	    try
	    {
		    if(file.exists())
		    {
			    SQLiteDatabase db = context.openOrCreateDatabase(webviewfile,Context.MODE_PRIVATE, null);
			    Cursor cursor=db.rawQuery("select value from formdata where name=?", new String[]{"userId"});
			    if(cursor.moveToFirst())
			    {
			      userAccount=cursor.getString(cursor.getColumnIndex("value"));
			    }
			    cursor.close();
				db.close();
		    }
	    }
	    catch (Exception e) 
	    {
			e.printStackTrace();
		}
	    return userAccount;
    }
    
    /**
     * ���WebView�����ݿ⻺��
     */
    public static void clearWebCache()
    {
    	File[] webfile=new File[]{new File(webviewfile),new File(webviewCachefile)};
    	if(webfile!=null)
    	for(File file:webfile)
    	{
	     if(file.exists())
	      {
	        file.delete();
	      }
    	}
    }
}
