package fly.SinaWeibo.utils;

import weibo4j.Oauth;
import weibo4j.http.AccessToken;
import weibo4j.model.WeiboException;



/**
 * �û�OAuth��Ȩ������
 */
public class OAuthUtil
{
	private static Oauth oauth;
	private static AccessToken accessToken;
	private static String authorizationURL;
	static
	{
		oauth = new Oauth();
	}
	/**
	 * ��ȡ��ȨURL
	 * @return String
	 */
	public static String getAuthorizationURL()
	{
		try
		{
			authorizationURL=oauth.authorize("code");
			if(authorizationURL!=null)
			  return authorizationURL;
		}
		catch (WeiboException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * ��ȡAccess Token��Ϣ
	 * @param pin
	 * @return
	 */
	public static AccessToken getAccessToken(String code)
	{
		try
		{
			accessToken = oauth.getAccessTokenByCode(code);
			return accessToken;
		}
		catch (WeiboException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	public static AccessToken getAccessToken()
	{
		return accessToken;
	}
}
