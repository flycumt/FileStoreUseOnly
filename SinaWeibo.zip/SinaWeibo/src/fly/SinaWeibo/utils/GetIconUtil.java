package fly.SinaWeibo.utils;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;

public class GetIconUtil 
{
    /**
     * ��ȡ����ͼƬ������
     * @param path
     * @return byte[]
     */
	public static byte[] getImage(URL url) throws Exception
	{
		HttpURLConnection conn=(HttpURLConnection) url.openConnection();
		conn.setConnectTimeout(5000);
		conn.setRequestMethod("GET");
		if(conn.getResponseCode()==200)
		{
			InputStream inputStream=conn.getInputStream();
			return StreamUtil.read(inputStream);
		}
		return null;
	}
	public static Drawable getPic(URL url)
	{
		try
		{
			HttpURLConnection conn=(HttpURLConnection) url.openConnection();
			Drawable drawable=Drawable.createFromStream(conn.getInputStream(),"picture");
			conn.disconnect();
			return drawable;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * ��ȡSD���ϵ�ͼƬ
	 * @param path
	 * @return Bitmap
	 */
	public static Bitmap getImageFromSD(String path)
	{
		File file=new File(path);
		if(file.exists())
		{
	        Bitmap bm = BitmapFactory.decodeFile(path);
	        if(bm!=null)
	           return bm;
	        return null;
		}
		return null;
	}
	public static Drawable getDrawImageFromSD(String path)
	{
		File file=new File(path);
		if(file.exists())
		{
			return Drawable.createFromPath(path);
		}
		return null;
	}
}
