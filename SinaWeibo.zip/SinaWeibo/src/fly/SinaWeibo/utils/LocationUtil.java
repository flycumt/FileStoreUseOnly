package fly.SinaWeibo.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.telephony.NeighboringCellInfo;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;

import com.google.gson.Gson;

import fly.SinaWeibo.bean.TestResult;

public class LocationUtil
{
	public static String[] baseURL = { "http://maps.google.com/maps/api/geocode/json?latlng=", ",", "&sensor=false&language=zh-CN" };
	/**
	 * ���ݾ�γ�Ȼ�ȡ��ַ
	 * @param latitude
	 * @param longitude
	 * @return String
	 */
	public static String getAddress(double latitude, double longitude)
	{
		String url = baseURL[0] + latitude + baseURL[1] + longitude + baseURL[2];
		String resonseData = HttpDownloadUtil.download(url);
		Gson gson = new Gson();
		TestResult testResult = gson.fromJson(resonseData, TestResult.class);
		
		String address = testResult.getResults().get(0).getFormatted_address();
		if (address != null&&!address.equals(""))
		{
			if(address.contains("�й�")&&address.length()>2)
			   return address.substring(2, address.length());
			else
			   return address;
		}
		else
			return null;
	}
	/**
	 * ͨ��cell����λ�ö�λ
	 */
	public static String requestTelLocation(Context context)
	{
		TelephonyManager mTelMan = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		// MCC+MNC. Unreliable on CDMA networks
		String operator = mTelMan.getNetworkOperator();
		String mcc = operator.substring(0, 3);
		String mnc = operator.substring(3);
		GsmCellLocation location = (GsmCellLocation) mTelMan.getCellLocation();
		int cid = location.getCid();
		int lac = location.getLac();
		JSONObject tower = new JSONObject();
		try
		{
			tower.put("cell_id", cid);
			tower.put("location_area_code", lac);
			tower.put("mobile_country_code", mcc);
			tower.put("mobile_network_code", mnc);
		}
		catch (JSONException e)
		{
			Log.e("LocationUtil", "call JSONObject's put failed", e);
		}
		JSONArray array = new JSONArray();
		array.put(tower);

		List<NeighboringCellInfo> list = mTelMan.getNeighboringCellInfo();
		Iterator<NeighboringCellInfo> iter = list.iterator();
		NeighboringCellInfo cellInfo;
		JSONObject tempTower;
		while (iter.hasNext())
		{
			cellInfo = iter.next();
			tempTower = new JSONObject();
			try
			{
				tempTower.put("cell_id", cellInfo.getCid());
				tempTower.put("location_area_code", cellInfo.getLac());
				tempTower.put("mobile_country_code", mcc);
				tempTower.put("mobile_network_code", mnc);
			}
			catch (JSONException e)
			{
				Log.e("LocationUtil", "call JSONObject's put failed", e);
			}
			array.put(tempTower);
		}

		JSONObject object = createJSONObject("cell_towers", array);
		return requestLocation(object);
	}
	public static String requestLocation(JSONObject object)
	{
		Log.d("LocationUtil", "requestLocation: " + object.toString());
		HttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost("http://www.google.com/loc/json");
		StringBuffer buffer = new StringBuffer();
		try
		{
			StringEntity entity = new StringEntity(object.toString());
			post.setEntity(entity);
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		try
		{
			HttpResponse resp = client.execute(post);
			HttpEntity entity = resp.getEntity();
			BufferedReader br = new BufferedReader(new InputStreamReader(entity.getContent()));
			String result = br.readLine();
			while (result != null)
			{
				buffer.append(result);
				result = br.readLine();
			}
			Log.d("LocationUtil", buffer.toString());//�����ʽ{"latitude":34.2116669,"longitude":117.1334408,"accuracy":3875.0},"access_token":"2:iLIc7680L-jbOcyI:UrOOuoB4KVwh_zFg"}
		}
		catch (ClientProtocolException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return buffer.toString();
	}

	public static  JSONObject createJSONObject(String arrayName, JSONArray array)
	{
		JSONObject object = new JSONObject();
		try
		{
			object.put("version", "1.1.0");
			object.put("host", "maps.google.com");
			object.put(arrayName, array);
		}
		catch (JSONException e)
		{
			Log.e("LocationUtil", "call JSONObject's put failed", e);
		}
		return object;
	}
}
