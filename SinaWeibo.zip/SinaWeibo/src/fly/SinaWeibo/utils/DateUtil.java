package fly.SinaWeibo.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateUtil
{
	public static String getUpdateTime(Date date)
	{
		Calendar currentDate = Calendar.getInstance();
		Calendar weiboDate = Calendar.getInstance();
		if(date==null)return "";
		weiboDate.setTime(date);
		String updateTime = "";
		int year = currentDate.get(Calendar.YEAR) - weiboDate.get(Calendar.YEAR);
		int day = currentDate.get(Calendar.DAY_OF_YEAR) - weiboDate.get(Calendar.DAY_OF_YEAR);
		String formDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.CHINA).format(date);
		if (year > 0)// һ������
		{
			updateTime = formDate.substring(0, 10);
			return updateTime;
		}
		else // һ������
		{
			if (day > 7)// 7������
			{
				updateTime = formDate.substring(5, 16);
				return updateTime;
			}
			else // 7������
			{
				int hour=(currentDate.get(Calendar.DAY_OF_YEAR)-1)*24+currentDate.get(Calendar.HOUR_OF_DAY)- ((weiboDate.get(Calendar.DAY_OF_YEAR)-1)*24+weiboDate.get(Calendar.HOUR_OF_DAY));
				if(hour>24)// 1������
				{
				  updateTime = day + "��ǰ";
				}
				else // 1������
				{
					if (hour >=12)// 12Сʱ����
					{
						updateTime = hour + "Сʱǰ";
					}
					else // 12Сʱ����
					{
						int minute=((currentDate.get(Calendar.DAY_OF_YEAR)-1)*24+currentDate.get(Calendar.HOUR_OF_DAY)-1)*60+currentDate.get(Calendar.MINUTE)
								- (((weiboDate.get(Calendar.DAY_OF_YEAR)-1)*24+weiboDate.get(Calendar.HOUR_OF_DAY)-1)*60+weiboDate.get(Calendar.MINUTE));
						if (minute / 60 > 0)//1Сʱ����
						{
							if (minute % 60 > 0)
								updateTime = minute / 60 + "Сʱ" + minute % 60 + "����ǰ";
							else
								updateTime = minute / 60 + "Сʱǰ";
						}
						else // 1Сʱ����
						{
							if(minute>=5)
							  updateTime = minute + "����ǰ";
							else
							{
							  int second=(int) ((currentDate.getTimeInMillis()-weiboDate.getTimeInMillis())/1000);
							  if(second>60)
							  {
								  if(second%60>0)
								    updateTime = second/60 + "��"+ second%60 +"��ǰ";
								  else
									updateTime = second/60 + "����ǰ";
							  }
							  else
							     updateTime= second + "��ǰ";
							}
						}
					}
				}
				return updateTime;
			}
		}
	}
}
