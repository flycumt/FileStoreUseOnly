package weibo4j.http;

import weibo4j.model.Constants;
import weibo4j.model.WeiboException;

/**
 * ��ʱ�洢�ϴ�ͼƬ�����ݣ���ʽ���ļ���Ϣ��
 * 
 */
public class ImageItem
{
	private byte[] content;
	private String name;
	private String contentType;

	public ImageItem(byte[] content) throws WeiboException
	{
		this(Constants.UPLOAD_MODE, content);
	}

	public ImageItem(String name, byte[] content) throws WeiboException
	{
		String imgtype = getImageType(content);
		if (imgtype != null && (imgtype.equalsIgnoreCase("image/gif") || imgtype.equalsIgnoreCase("image/png") || imgtype.equalsIgnoreCase("image/jpeg")))
		{
			this.content = content;
			this.name = name;
			this.contentType = imgtype;
		}
		else
		{
			throw new WeiboException("Unsupported image type, Only Suport JPG ,GIF,PNG!");
		}
	}

	public byte[] getContent()
	{
		return content;
	}

	public String getName()
	{
		return name;
	}

	public String getContentType()
	{
		return contentType;
	}

	public static String getImageType(byte[] bytes)
	{
		if (isJPEG(bytes))
		{
			return "image/jpeg";
		}
		if (isGIF(bytes))
		{
			return "image/gif";
		}
		if (isPNG(bytes))
		{
			return "image/png";
		}
		if (isBMP(bytes))
		{
			return "application/x-bmp";
		}
		return null;
	}

	private static boolean isJPEG(byte[] b)
	{
		if (b.length < 2)
		{
			return false;
		}
		return (b[0] == (byte) 0xFF) && (b[1] == (byte) 0xD8);
	}

	private static boolean isGIF(byte[] b)
	{
		if (b.length < 6)
		{
			return false;
		}
		return b[0] == 'G' && b[1] == 'I' && b[2] == 'F' && b[3] == '8' && (b[4] == '7' || b[4] == '9') && b[5] == 'a';
	}

	private static boolean isPNG(byte[] b)
	{
		if (b.length < 8)
		{
			return false;
		}
		return (b[0] == (byte) 137 && b[1] == (byte) 80 && b[2] == (byte) 78 && b[3] == (byte) 71 && b[4] == (byte) 13 && b[5] == (byte) 10 && b[6] == (byte) 26 && b[7] == (byte) 10);
	}

	private static boolean isBMP(byte[] b)
	{
		if (b.length < 2)
		{
			return false;
		}
		return (b[0] == 0x42) && (b[1] == 0x4d);
	}
}


